<?php
/**
 * Enrollment Security & Validation Helper
 * Prevents duplicate enrollments and time conflicts
 */

require_once __DIR__ . '/../includes/db.php';

class EnrollmentSecurity {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    /**
     * Check if student is already enrolled in this course
     */
    public function isDuplicateEnrollment($student_id, $course_id) {
        $stmt = $this->pdo->prepare("
            SELECT id FROM enrollments 
            WHERE student_id = ? AND course_id = ? AND status IN ('active', 'pending')
        ");
        $stmt->execute([$student_id, $course_id]);
        return $stmt->fetch() !== false;
    }
    
    /**
     * Check if course timing conflicts with student's existing enrollments
     */
    public function hasTimeConflict($student_id, $new_course_id) {
        // Get new course schedule
        $stmt = $this->pdo->prepare("
            SELECT schedule_days, schedule_time 
            FROM courses 
            WHERE id = ?
        ");
        $stmt->execute([$new_course_id]);
        $new_course = $stmt->fetch();
        
        if (!$new_course) {
            return ['conflict' => false, 'message' => 'Course not found'];
        }
        
        // Get student's existing enrollments with course schedules
        $stmt = $this->pdo->prepare("
            SELECT c.id, c.title, c.schedule_days, c.schedule_time
            FROM enrollments e
            JOIN courses c ON e.course_id = c.id
            WHERE e.student_id = ? AND e.status = 'active' AND c.id != ?
        ");
        $stmt->execute([$student_id, $new_course_id]);
        $existing_courses = $stmt->fetchAll();
        
        // Check for time conflicts
        foreach ($existing_courses as $course) {
            if ($this->isScheduleConflict($new_course, $course)) {
                return [
                    'conflict' => true,
                    'message' => "Time conflict with '{$course['title']}' - Both courses are scheduled on {$course['schedule_days']} at {$course['schedule_time']}",
                    'conflicting_course' => $course
                ];
            }
        }
        
        return ['conflict' => false, 'message' => 'No time conflicts'];
    }
    
    /**
     * Check if two course schedules conflict
     */
    private function isScheduleConflict($course1, $course2) {
        $days1 = array_map('trim', explode(',', $course1['schedule_days']));
        $days2 = array_map('trim', explode(',', $course2['schedule_days']));
        
        // Find common days
        $common_days = array_intersect($days1, $days2);
        
        if (empty($common_days)) {
            return false;
        }
        
        // Check if times overlap
        $time1_str = str_replace(' ', '', $course1['schedule_time']);
        $time2_str = str_replace(' ', '', $course2['schedule_time']);
        
        // If times are exactly same, it's a conflict
        if ($time1_str === $time2_str) {
            return true;
        }
        
        $time1 = strtotime($course1['schedule_time']);
        $time2 = strtotime($course2['schedule_time']);
        
        if (!$time1 || !$time2) return false;

        // If times are within 50 minutes of each other (typical class duration), consider it a conflict
        $time_diff = abs($time1 - $time2);
        return $time_diff < (50 * 60); // 50 minutes
    }
    
    /**
     * Validate enrollment with all security checks
     */
    public function validateEnrollment($student_id, $course_id) {
        $errors = [];
        
        // Check 1: Duplicate enrollment
        if ($this->isDuplicateEnrollment($student_id, $course_id)) {
            $errors[] = "You are already enrolled in this course.";
        }
        
        // Check 2: Time conflict
        $conflict_check = $this->hasTimeConflict($student_id, $course_id);
        if ($conflict_check['conflict']) {
            $errors[] = $conflict_check['message'];
        }
        
        // Check 3: Verify student exists
        $stmt = $this->pdo->prepare("SELECT id FROM students WHERE id = ?");
        $stmt->execute([$student_id]);
        if (!$stmt->fetch()) {
            $errors[] = "Invalid student ID.";
        }
        
        // Check 4: Verify course exists and is approved
        $stmt = $this->pdo->prepare("SELECT id, status FROM courses WHERE id = ?");
        $stmt->execute([$course_id]);
        $course = $stmt->fetch();
        if (!$course) {
            $errors[] = "Course not found.";
        } elseif ($course['status'] !== 'approved') {
            $errors[] = "This course is not currently available for enrollment.";
        }
        
        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }
    
    /**
     * Create enrollment with security checks
     */
    public function createEnrollment($student_id, $course_id, $payment_status = 'pending', $transaction_id = null) {
        // Validate first
        $validation = $this->validateEnrollment($student_id, $course_id);
        
        if (!$validation['valid']) {
            return [
                'success' => false,
                'errors' => $validation['errors']
            ];
        }

        // Check for tutor referral in session
        $assigned_tutor_id = $_SESSION['referred_by_tutor_id'] ?? null;
        
        // Ensure the referred tutor actually exists and is active
        if ($assigned_tutor_id) {
            $chk = $this->pdo->prepare("SELECT id FROM tutors WHERE id = ? AND is_active = 1");
            $chk->execute([$assigned_tutor_id]);
            if (!$chk->fetch()) {
                $assigned_tutor_id = null;
            }
        }
        
        // Create enrollment
        try {
            $stmt = $this->pdo->prepare("
                INSERT INTO enrollments 
                (student_id, course_id, payment_status, transaction_id, status, assigned_tutor_id, enrolled_at) 
                VALUES (?, ?, ?, ?, 'pending', ?, NOW())
            ");
            $stmt->execute([$student_id, $course_id, $payment_status, $transaction_id, $assigned_tutor_id]);
            
            // Clear referral session after successful creation
            unset($_SESSION['referred_by_tutor_id']);

            return [
                'success' => true,
                'enrollment_id' => $this->pdo->lastInsertId(),
                'message' => 'Enrollment successful!'
            ];
        } catch (PDOException $e) {
            return [
                'success' => false,
                'errors' => ['Database error: ' . $e->getMessage()]
            ];
        }
    }
    
    /**
     * Get student's enrolled courses with schedule info
     */
    public function getStudentEnrollments($student_id) {
        $stmt = $this->pdo->prepare("
            SELECT 
                e.id as enrollment_id,
                e.enrolled_at,
                e.payment_status,
                c.id as course_id,
                c.title,
                c.description,
                c.schedule_days,
                c.schedule_time,
                c.price,
                t.name as tutor_name
            FROM enrollments e
            JOIN courses c ON e.course_id = c.id
            LEFT JOIN tutors t ON c.tutor_id = t.id
            WHERE e.student_id = ? AND e.status = 'active'
            ORDER BY c.schedule_days, c.schedule_time
        ");
        $stmt->execute([$student_id]);
        return $stmt->fetchAll();
    }
}
?>
