<?php 
include 'includes/db.php';
include 'includes/header.php'; 

// Fetch Tutors with Filter Logic
$where_clauses = ["status = 'approved'"];
$params = [];

// Name Search
if (!empty($_GET['search'])) {
    $where_clauses[] = "name LIKE ?";
    $params[] = "%" . $_GET['search'] . "%";
}

// Gender
if (!empty($_GET['gender'])) {
    $where_clauses[] = "gender = ?";
    $params[] = $_GET['gender'];
}

// Status (Mock Logic as DB column might not exist yet, assuming 'status' column or just ignore for now)
// if (!empty($_GET['status'])) { ... }

// Subject (Specialty) - simplistic LIKE check
if (!empty($_GET['subject']) && is_array($_GET['subject'])) {
    $subject_clauses = [];
    foreach($_GET['subject'] as $subj) {
        $subject_clauses[] = "specialty LIKE ?";
        $params[] = "%" . $subj . "%";
    }
    if(!empty($subject_clauses)) {
        $where_clauses[] = "(" . implode(" OR ", $subject_clauses) . ")";
    }
}

// Country
if (!empty($_GET['country'])) {
    $where_clauses[] = "country = ?";
    $params[] = $_GET['country'];
}

// Hourly Rate
if (!empty($_GET['price_max'])) {
    $where_clauses[] = "price_hourly <= ?";
    $params[] = $_GET['price_max'];
}

// Build Query
$sql = "SELECT * FROM tutors";
if (!empty($where_clauses)) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}

// Execution
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $tutors = $stmt->fetchAll();
} catch(PDOException $e) {
    $tutors = [];
    $error = "Database Error.";
}
?>

<!-- Page Header -->
<section style="background: linear-gradient(rgba(13, 56, 35, 0.9), rgba(13, 56, 35, 0.8)), url('assets/images/page_header_bg.png') no-repeat center center/cover; padding: 100px 0 60px; text-align: center; position: relative;">
    <div class="container" style="position: relative; z-index: 2;">
        <h1 data-aos="fade-up" style="font-size: 2.8rem; color: white; margin-bottom: 15px; font-weight: 800;">Find Best Quran Teachers</h1>
        <p data-aos="fade-up" data-aos-delay="100" style="color: #d1d5db; font-size: 1.1rem; max-width: 700px; margin: 0 auto;">
            Choose from our qualified and certified private quran teachers.
        </p>
    </div>
</section>

<!-- Main Content Section -->
<section class="section-padding" style="background: #fdfdfd;">
    <div class="container">
        <div class="row">
            <!-- Mobile Filter Toggle -->
            <div class="col-12 d-lg-none mb-4">
                <button class="btn btn-primary w-100" type="button" onclick="document.querySelector('.sidebar-box').classList.toggle('active')">
                    <i class="fas fa-filter me-2"></i> Show Filters
                </button>
            </div>
            
            <!-- SIDEBAR FILTERS (Sticky & Independent Scroll) -->
            <div class="col-lg-3 mb-5 mb-lg-0">
                <style>
                    /* Custom Sidebar Styles */
                    .sidebar-box {
                        background: white;
                        padding: 25px 20px;
                        border-radius: 12px;
                        border: 1px solid #e1e1e1;
                        box-shadow: 0 4px 15px rgba(0,0,0,0.03);
                        /* Sticky Behavior */
                        position: sticky;
                        top: 120px; 
                        max-height: calc(100vh - 140px); 
                        overflow-y: auto; 
                        scrollbar-width: thin;
                        transition: 0.3s ease;
                    }
                    
                    @media (max-width: 991px) {
                        .sidebar-box {
                            position: fixed;
                            top: 0;
                            left: -100%;
                            width: 280px;
                            height: 100vh;
                            max-height: 100vh;
                            z-index: 2000;
                            border-radius: 0;
                            box-shadow: 10px 0 30px rgba(0,0,0,0.1);
                        }
                        .sidebar-box.active {
                            left: 0;
                        }
                    }
                    
                    .sidebar-header {
                        display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid #f0f0f0;
                    }
                    .sidebar-title { font-size: 1rem; font-weight: 800; color: var(--primary); margin: 0; text-transform: uppercase; }
                    .clear-link { font-size: 0.8rem; color: #999; font-weight: 600; cursor: pointer; border: none; background: none; }
                    .clear-link:hover { color: var(--accent); text-decoration: underline; }
                    
                    .filter-group { margin-bottom: 25px; }
                    .filter-label { font-size: 0.85rem; font-weight: 700; color: #374151; margin-bottom: 10px; display: block; }
                    
                    .custom-search { position: relative; }
                    .custom-search input { width: 100%; padding: 10px 10px 10px 35px; border: 1px solid #e5e7eb; border-radius: 6px; font-size: 0.9rem; background: #f9fafb; }
                    .custom-search i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #9ca3af; }

                    .custom-check { display: flex; align-items: center; margin-bottom: 8px; cursor: pointer; width: 100%; }
                    .custom-check input { display: none; }
                    .check-box { width: 18px; height: 18px; border: 2px solid #d1d5db; border-radius: 4px; margin-right: 10px; display: flex; align-items: center; justify-content: center; background: white; flex-shrink: 0; }
                    .custom-check input:checked + .check-box { background: var(--accent); border-color: var(--accent); }
                    .custom-check input:checked + .check-box::after { content: '\f00c'; font-family: 'Font Awesome 5 Free'; font-weight: 900; color: white; font-size: 0.7rem; }
                    .check-text { font-size: 0.9rem; color: #4b5563; }
                    
                    .price-slider-wrapper { padding: 5px 0; }
                    input[type=range] { width: 100%; }

                    /* Tutor Card Styles */
                    .q-tutor-card { background: white; border: 1px solid #e5e7eb; border-radius: 12px; margin-bottom: 25px; padding: 25px; display: flex; gap: 25px; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); position: relative; overflow: hidden; }
                    .q-tutor-card:hover { box-shadow: 0 15px 35px rgba(0,0,0,0.08); border-color: var(--accent); transform: translateY(-3px); }
                    .qt-avatar { width: 100px; height: 100px; border-radius: 50%; object-fit: cover; border: 4px solid #fff; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
                    .qt-stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px 10px; margin-top: 20px; border-top: 1px solid #f1f5f9; padding-top: 20px; }
                    .qt-actions { display: flex; flex-direction: column; justify-content: center; gap: 12px; min-width: 180px; border-left: 1px solid #f1f5f9; padding-left: 25px; }
                    
                    @media(max-width: 991px) { 
                        .q-tutor-card { flex-direction: column; gap: 20px; } 
                        .qt-stats-grid { grid-template-columns: repeat(2, 1fr); } 
                        .qt-actions { border-left: none; border-top: 1px solid #f1f5f9; padding-left: 0; padding-top: 20px; flex-direction: row; }
                    }
                    @media(max-width: 576px) {
                        .qt-actions { flex-direction: column; }
                    }
                </style>

                <form method="GET" action="tutors.php" class="sidebar-box">
                    <div class="sidebar-header">
                        <h4 class="sidebar-title">Search By</h4>
                        <a href="tutors.php" class="clear-link">Clear All</a>
                    </div>

                    <!-- Search Name -->
                    <div class="filter-group">
                        <label class="filter-label">Name</label>
                        <div class="custom-search">
                            <input type="text" name="search" value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>" placeholder="Enter name...">
                            <i class="fas fa-search"></i>
                        </div>
                    </div>

                    <!-- Subject -->
                    <div class="filter-group">
                        <label class="filter-label">Subject</label>
                        <?php 
                        $subjects = ['Recitation', 'Tajweed', 'Hifz', 'Arabic'];
                        $sel_sub = isset($_GET['subject']) ? (is_array($_GET['subject']) ? $_GET['subject'] : [$_GET['subject']]) : [];
                        foreach($subjects as $subj): 
                        ?>
                        <label class="custom-check">
                            <input type="checkbox" name="subject[]" value="<?php echo $subj; ?>" <?php echo in_array($subj, $sel_sub) ? 'checked' : ''; ?>>
                            <span class="check-box"></span>
                            <span class="check-text"><?php echo $subj; ?></span>
                        </label>
                        <?php endforeach; ?>
                    </div>

                    <!-- Gender -->
                    <div class="filter-group">
                        <label class="filter-label">Gender</label>
                        <div style="display: flex; gap: 15px;">
                            <label class="custom-check">
                                <input type="radio" name="gender" value="Male" <?php echo (isset($_GET['gender']) && $_GET['gender'] == 'Male') ? 'checked' : ''; ?>>
                                <span class="check-box" style="border-radius: 50%;"></span>
                                <span class="check-text">Male</span>
                            </label>
                            <label class="custom-check">
                                <input type="radio" name="gender" value="Female" <?php echo (isset($_GET['gender']) && $_GET['gender'] == 'Female') ? 'checked' : ''; ?>>
                                <span class="check-box" style="border-radius: 50%;"></span>
                                <span class="check-text">Female</span>
                            </label>
                        </div>
                    </div>

                    <!-- Hourly Rate -->
                    <div class="filter-group">
                        <label class="filter-label">Max Hourly Rate ($)</label>
                        <div class="price-slider-wrapper">
                            <input type="range" name="price_max" min="0" max="50" step="5" value="<?php echo htmlspecialchars($_GET['price_max'] ?? '50'); ?>" oninput="document.getElementById('priceVal').innerText = '$' + this.value">
                            <div style="display: flex; justify-content: space-between; font-size: 0.8rem; color: #777; margin-top: 8px;">
                                <span>$0</span>
                                <span style="font-weight: 700; color: var(--accent);" id="priceVal">$<?php echo htmlspecialchars($_GET['price_max'] ?? '50'); ?></span>
                                <span>$50</span>
                            </div>
                        </div>
                    </div>

                    <!-- Country -->
                    <div class="filter-group">
                        <label class="filter-label">Country</label>
                        <select name="country" class="form-control" style="font-size: 0.9rem;">
                            <option value="">Select Country</option>
                            <option value="Egypt" <?php echo (isset($_GET['country']) && $_GET['country'] == 'Egypt') ? 'selected' : ''; ?>>Egypt</option>
                            <option value="Pakistan" <?php echo (isset($_GET['country']) && $_GET['country'] == 'Pakistan') ? 'selected' : ''; ?>>Pakistan</option>
                            <option value="United Kingdom" <?php echo (isset($_GET['country']) && $_GET['country'] == 'United Kingdom') ? 'selected' : ''; ?>>UK</option>
                             <option value="United States" <?php echo (isset($_GET['country']) && $_GET['country'] == 'United States') ? 'selected' : ''; ?>>USA</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary" style="width: 100%; border-radius: 6px;">Apply Filters</button>
                </form>
            </div>

            <!-- TUTOR LISTINGS -->
            <div class="col-lg-9">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px;">
                    <h5 style="margin: 0; color: #444; font-weight: 600;"><?php echo count($tutors); ?> Tutors Found</h5>
                </div>

                <?php if(!empty($tutors)): ?>
                    <div class="tutors-list">
                        <?php foreach($tutors as $tutor): 
                            // Mock Data
                            $sessions = rand(100, 5000);
                            $students = rand(10, 200);
                            $last_active = rand(1, 59) . " minutes ago";
                            
                            // Image Override for Founder
                            $tutor_image = $tutor['image'] ?? 'assets/images/default_avatar.png';
                            if(stripos($tutor['name'], 'Abdullah Nasir Rehmani') !== false) {
                                $tutor_image = 'assets/images/sheikh_abdullah.png';
                            }
                        ?>
                        <div class="q-tutor-card" data-aos="fade-up">
                            
                            <!-- Avatar -->
                            <div style="text-align: center; flex-shrink: 0; width: 100px;">
                                <img src="<?php echo htmlspecialchars($tutor_image); ?>" class="qt-avatar">
                                <div style="font-size: 0.75rem; color: #10b981; font-weight: 700; margin-top: 5px;"><i class="fas fa-check-circle"></i> VERIFIED</div>
                            </div>

                            <!-- Content -->
                            <div style="flex: 1;">
                                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                                    <h4 style="margin: 0;"><a href="tutor_profile.php?id=<?php echo $tutor['id']; ?>" style="color: #1a202c;"><?php echo htmlspecialchars($tutor['name']); ?></a></h4>
                                    <div style="color: #F59E0B;"><i class="fas fa-star"></i> <?php echo number_format($tutor['rating'], 1); ?></div>
                                </div>
                                <div style="color: #666; font-size: 0.9rem; margin-bottom: 10px;"><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($tutor['country']); ?></div>
                                <p style="font-size: 0.9rem; color: #555; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                                    <?php echo htmlspecialchars($tutor['bio']); ?>
                                </p>
                                
                                <div class="qt-stats-grid">
                                    <div><small style="color: #999;">Languages</small><div style="font-weight: 600;">English, Arabic</div></div>
                                    <div><small style="color: #999;">Hourly Rate</small><div style="font-weight: 800; color: var(--accent);">$<?php echo number_format($tutor['price_hourly'], 2); ?></div></div>
                                    <div><small style="color: #999;">Sessions</small><div style="font-weight: 600;"><?php echo $sessions; ?></div></div>
                                    <div><small style="color: #999;">Active</small><div style="font-weight: 600;"><?php echo $last_active; ?></div></div>
                                </div>
                            </div>

                            <!-- Actions -->
                            <div class="qt-actions">
                                <a href="tutor_profile.php?id=<?php echo $tutor['id']; ?>" class="btn btn-primary" style="border-radius: 50px;">View Profile</a>
                                <a href="contact.php" class="btn btn-outline-secondary" style="border-radius: 50px; font-size: 0.9rem; text-align: center; border: 1px solid #ddd;">Message</a>
                            </div>

                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div style="text-align: center; padding: 50px; border: 1px solid #eee; background: white; border-radius: 8px;">
                        <i class="fas fa-search" style="font-size: 3rem; color: #eee; margin-bottom: 20px;"></i>
                        <p class="text-muted">No tutors found matching your criteria.</p>
                        <a href="tutors.php" class="btn btn-primary btn-sm">Clear Filters</a>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
