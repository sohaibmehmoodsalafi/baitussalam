<?php 
include 'includes/db.php';
include 'includes/header.php'; 
?>

<!-- Cookie Banner -->
<div id="cookie-banner" style="position: fixed; bottom: -100px; left: 0; width: 100%; z-index: 2000; padding: 15px 20px; display: flex; justify-content: center; align-items: center; gap: 20px; transition: bottom 0.5s ease; background: var(--primary-dark); color: white; box-shadow: 0 -2px 10px rgba(0,0,0,0.1);">
    <div style="font-size: 0.95rem;">
        This website uses cookies to improve your experience and track ad conversion. <a href="#" style="color: var(--accent); text-decoration: underline;">Learn more</a>
    </div>
    <button onclick="document.getElementById('cookie-banner').style.bottom = '-100px'" class="btn" style="background: var(--accent); color: white; padding: 8px 25px; border-radius: 4px; font-size: 0.9rem;">Got it!</button>
</div>

<script>
    setTimeout(() => { document.getElementById('cookie-banner').style.bottom = '0'; }, 2000);
</script>

<!-- Premium Hero Section (Restored Laptop Layout) -->
<section class="hero-premium" style="background: linear-gradient(to right, rgba(0, 33, 71, 0.95) 40%, rgba(0, 33, 71, 0.4) 100%), url('assets/images/peace_hero_laptop_ayat.png'); background-size: cover; background-position: center right; position: relative; color: white; padding: 160px 0 140px; min-height: 85vh; display: flex; align-items: center;">
    <div style="position: absolute; top:0; left:0; width:100%; height:100%; background-image: url('assets/images/hero_pattern.png'); background-size: 300px; opacity: 0.05; pointer-events: none;"></div>
    
    <div class="container" style="position: relative; z-index: 5;">
        <div class="row">
            <div class="col-lg-8" data-aos="fade-right">
                <div class="hero-content">
                    <h4 class="hero-tagline" style="color: var(--accent); font-weight: 700; text-transform: uppercase; letter-spacing: 3px; font-size: 1.1rem; margin-bottom: 25px;">PROUDLY SERVING OVER 1500+ STUDENTS</h4>
                    <h1 class="hero-title" style="font-family: 'Outfit', sans-serif; font-weight: 800; line-height: 1.1; margin-bottom: 25px; font-size: 4rem; text-shadow: 0 4px 15px rgba(0,0,0,0.3);">World's Best Virtual Platform for<br><span style="color: var(--accent);">Online Quran Learning</span></h1>
                    <p class="hero-subtitle" style="margin-bottom: 45px; color: rgba(255,255,255,0.95); line-height: 1.6; font-size: 1.25rem; max-width: 800px;">Experience the convenience of learning the Holy Quran and Islamic sciences from the comfort of your home with our certified scholars.</p>
                    <div style="display: flex; gap: 20px; flex-wrap: wrap;" class="hero-btns">
                        <a href="register.php" class="btn-premium-gold" style="text-decoration: none; padding: 18px 45px; border-radius: 50px; font-weight: 800;">GET STARTED NOW</a>
                        <a href="tutors.php" class="btn-premium-outline" style="text-decoration: none; padding: 18px 45px; border-radius: 50px; border: 2px solid white; color: white; font-weight: 700;">BROWSE TUTORS</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
</section>

<style>
@media (max-width: 991px) {
    .hero-premium { text-align: center; padding: 120px 0 80px; }
    .hero-title { font-size: 2.8rem !important; }
    .hero-btns { justify-content: center; }
    .hero-image-wrapper img { width: 100% !important; transform: none !important; margin-top: 40px; }
}
</style>

<!-- About Us Section Moved Below Offering if needed, but subagent said it's above. I will remove the old one. -->

<!-- About Us Section (Refined 2-column) -->
<section class="section-padding" style="background: white;">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-7" data-aos="fade-right">
                <h4 style="color: var(--accent); font-weight: 700; text-transform: uppercase; letter-spacing: 2px; font-size: 1.1rem; margin-bottom: 20px;">Welcome to Baitul Islam</h4>
                <h2 style="font-family: 'Outfit', sans-serif; font-weight: 800; color: var(--primary); margin-bottom: 25px; line-height: 1.2;">Baitul Islam Open University</h2>
                <div style="width: 80px; height: 3px; background: var(--accent); margin-bottom: 30px;"></div>
                <p style="font-size: 1.1rem; color: #555; line-height: 1.8; margin-bottom: 25px;">
                    To spread the knowledge of Qur’an and Sunnah to all through the use of latest technology, according to Baitul Islam Online Institute and Revival of Islamic Heritage Society joint venture, Our mission is to provide authentic knowledge of Deen (that is based on Qur’an and Sunnah alone) to those individuals who are unable to acquire it due to personal commitment or reason.
                </p>
                <p style="font-size: 1.1rem; color: #555; line-height: 1.8; margin-bottom: 35px;">
                    Our goal is to provide high standard of education in the comfort of their homes with the use of the latest methods in technology.
                </p>
                <a href="about.php" class="btn" style="background: var(--primary); color: white; padding: 15px 40px; border-radius: 4px; font-weight: 700;">READ MORE</a>
            </div>
            <div class="col-lg-5" data-aos="fade-left">
                <div style="position: relative; padding: 20px;" class="mobile-mt-40">
                    <div style="position: absolute; top:0; right:0; width: 100px; height: 100px; background: var(--accent); opacity: 0.1; border-radius: 50%; z-index: 1;"></div>
                    <!-- Putting Sheikh Abdullah Nasir Rehmani pic here in About section -->
                    <img src="assets/images/sheikh_abdullah.png" alt="Sheikh Abdullah Nasir Rehmani" style="width: 100%; border-radius: 30px; box-shadow: 0 25px 50px rgba(0,0,0,0.25); position: relative; z-index: 2; border: 5px solid white;">
                    <div style="position: absolute; bottom: 30px; left: 0; background: var(--accent); color: #031b4e; padding: 10px 20px; border-radius: 0 10px 10px 0; font-weight: 800; z-index: 3;">Founder: Sh. Abdullah Nasir Rehmani</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- What We Are Offering Section (Refined with Premium Icons and Layout) -->
<section id="what-we-offer" style="background: linear-gradient(rgba(3, 27, 78, 0.95), rgba(3, 27, 78, 0.95)), url('https://hijraonline.com/wp-content/uploads/2021/11/bg-1-copy.png?id=2784'); background-size: cover; background-position: center; background-attachment: fixed; padding: 120px 0; color: white; position: relative; overflow: hidden;">
    <!-- Abstract Design Elements -->
    <div style="position: absolute; top: -50px; left: -50px; width: 200px; height: 200px; background: var(--accent); opacity: 0.05; border-radius: 50%; filter: blur(50px);"></div>
    <div style="position: absolute; bottom: -50px; right: -50px; width: 300px; height: 300px; background: var(--accent); opacity: 0.05; border-radius: 50%; filter: blur(80px);"></div>
    
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-down">
            <h4 style="color: var(--accent); font-weight: 700; text-transform: uppercase; letter-spacing: 2px; font-size: 1rem; margin-bottom: 15px;">Our Features</h4>
            <h2 class="section-title" style="color: white; margin-bottom: 20px;">What We Are Offering</h2>
            <div style="width: 80px; height: 3px; background: var(--accent); margin: 0 auto;"></div>
        </div>
        <div class="row g-4 justify-content-center">
            <!-- Item 1 -->
            <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="100">
                <div class="offering-card-premium">
                    <div class="offering-icon-box">
                        <i class="fas fa-video"></i>
                        <span class="hd-badge">HD</span>
                    </div>
                    <h4 class="offering-title">Quality video lectures</h4>
                    <p style="color: rgba(255,255,255,0.7); font-size: 0.9rem; margin-top: 10px;">Crystal clear HD recorded lectures for flexible learning anywhere.</p>
                </div>
            </div>
            <!-- Item 2 -->
            <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="200">
                <div class="offering-card-premium">
                    <div class="offering-icon-box">
                        <i class="fas fa-photo-video"></i>
                    </div>
                    <h4 class="offering-title">Multimedia Classes</h4>
                    <p style="color: rgba(255,255,255,0.7); font-size: 0.9rem; margin-top: 10px;">Interactive presentations and visual aids to enhance understanding.</p>
                </div>
            </div>
            <!-- Item 3 -->
            <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="300">
                <div class="offering-card-premium">
                    <div class="offering-icon-box">
                        <i class="fas fa-desktop"></i>
                    </div>
                    <h4 class="offering-title">Digital Ecosystem</h4>
                    <p style="color: rgba(255,255,255,0.7); font-size: 0.9rem; margin-top: 10px;">A complete modern LMS for tracking progress and assessments.</p>
                </div>
            </div>
            <!-- Item 4 -->
            <div class="col-lg-3 col-md-6" data-aos="zoom-in" data-aos-delay="400">
                <div class="offering-card-premium">
                    <div class="offering-icon-box">
                        <i class="fas fa-file-invoice"></i>
                    </div>
                    <h4 class="offering-title">Syllabus Oriented</h4>
                    <p style="color: rgba(255,255,255,0.7); font-size: 0.9rem; margin-top: 10px;">Carefully curated curriculum from the world's leading scholars.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
    .offering-card-premium {
        background: rgba(255,255,255,0.05);
        padding: 40px 20px;
        border-radius: 20px;
        border: 1px solid rgba(255,255,255,0.1);
        backdrop-filter: blur(10px);
        transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        height: 100%;
        text-align: center;
    }
    .offering-card-premium:hover {
        background: rgba(255,255,255,0.1);
        transform: translateY(-10px);
        border-color: var(--accent);
        box-shadow: 0 20px 40px rgba(0,0,0,0.3);
    }
    .offering-icon-box {
        width: 100px; 
        height: 100px; 
        background: #031b4e; 
        border-radius: 50%; 
        display: flex; 
        align-items: center; 
        justify-content: center; 
        margin: 0 auto 25px; 
        border: 3px solid var(--accent); 
        position: relative;
        transition: 0.3s;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    }
    .offering-card-premium:hover .offering-icon-box {
        background: var(--accent);
        transform: scale(1.1);
    }
    .offering-icon-box i {
        font-size: 2.8rem; 
        color: var(--accent);
        transition: 0.3s;
    }
    .offering-card-premium:hover .offering-icon-box i {
        color: white;
    }
    .hd-badge {
        position: absolute;
        top: -5px;
        right: -5px;
        background: #ef4444;
        color: white;
        font-size: 0.6rem;
        font-weight: 900;
        padding: 3px 6px;
        border-radius: 4px;
        box-shadow: 0 4px 10px rgba(239, 68, 68, 0.3);
    }
    .offering-title {
        color: white; 
        font-weight: 800; 
        font-size: 1.25rem;
        line-height: 1.3;
        margin-bottom: 10px;
    }
</style>

<!-- How to Enroll Section (1:1 Hijra Visual Match) -->
<section id="how-to-enroll" style="background: url('https://hijraonline.com/wp-content/uploads/2021/09/bg-2.png?id=2705'); background-size: cover; background-position: center; padding: 120px 0;">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-up">
            <h2 class="section-title" style="color: #222; margin-bottom: 15px;">How to Enroll?</h2>
            <div style="width: 60px; height: 3px; background: var(--accent); margin: 0 auto;"></div>
        </div>
        <div class="row align-items-center g-5">
            <div class="col-lg-6" data-aos="fade-right">
                <div style="background: #000; border-radius: 12px; overflow: hidden; box-shadow: 0 25px 60px rgba(0,0,0,0.25); position: relative; padding-top: 56.25%;">
                    <iframe style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;" src="https://www.youtube.com/embed/RUwZ20JJTXo" title="How to Enroll" frameborder="0" allowfullscreen></iframe>
                </div>
            </div>
            <div class="col-lg-6" data-aos="fade-left">
                <div style="padding-left: 20px;">
                    <div style="display: flex; gap: 20px; margin-bottom: 40px;">
                        <div style="width: 60px; height: 60px; background: var(--primary); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-weight: 800; font-size: 1.5rem; border: 4px solid var(--accent);">01</div>
                        <div>
                            <h3 style="color: var(--primary); font-weight: 800; font-size: 1.6rem; margin-bottom: 8px;">Register as Student</h3>
                            <p style="color: #666; line-height: 1.7;">Click on the register button and provide your basic details to create your secure scholarship account.</p>
                        </div>
                    </div>
                    <div style="display: flex; gap: 20px; margin-bottom: 40px;">
                        <div style="width: 60px; height: 60px; background: var(--primary); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-weight: 800; font-size: 1.5rem; border: 4px solid var(--accent);">02</div>
                        <div>
                            <h3 style="color: var(--primary); font-weight: 800; font-size: 1.6rem; margin-bottom: 8px;">Find Your Course</h3>
                            <p style="color: #666; line-height: 1.7;">Browse through our Online Aalim/Aalimah or Short course categories to find the best fit for your spiritual journey.</p>
                        </div>
                    </div>
                    <div style="display: flex; gap: 20px;">
                        <div style="width: 60px; height: 60px; background: var(--primary); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-weight: 800; font-size: 1.5rem; border: 4px solid var(--accent);">03</div>
                        <div>
                            <h3 style="color: var(--primary); font-weight: 800; font-size: 1.6rem; margin-bottom: 8px;">Start Learning</h3>
                            <p style="color: #666; line-height: 1.7;">Join the virtual class and start your classes under the supervision of world-renowned scholars.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
// Dummy Courses Data (No Backend)
$dummy_courses = [
    ['title' => 'Aalim / Aalimah Course', 'tutor' => 'Shaykh Abdullah Nasir', 'price' => 150, 'img' => 'assets/images/course-1.png', 'desc' => 'Comprehensive Aalim/Aalimah program for dedicated students.'],
    ['title' => 'Tajweed-ul-Quran', 'tutor' => 'Shaykh Kamran Yaseen', 'price' => 80, 'img' => 'assets/images/course-2.png', 'desc' => 'Master the rules of recitation with expert guidance.'],
    ['title' => 'Hifz-e-Quran', 'tutor' => 'Shaykh Jamshed Sultan', 'price' => 100, 'img' => 'assets/images/course-3.png', 'desc' => 'Structured memorization program with weekly tracking.'],
    ['title' => 'Arabic Language', 'tutor' => 'Shaykh Usman Safder', 'price' => 90, 'img' => 'https://hijraonline.com/wp-content/uploads/2021/09/arabic-language-360x240.jpg', 'desc' => 'Learn to understand the language of the Holy Quran.'],
    ['title' => 'Islamic Studies', 'tutor' => 'Shaykh Abdullah Shamim', 'price' => 70, 'img' => 'https://hijraonline.com/wp-content/uploads/2021/09/islamic-studies-360x240.jpg', 'desc' => 'Deep dive into Fiqh, Hadith, and Seerah of the Prophet.'],
    ['title' => 'Quran Translation', 'tutor' => 'Shaykh Younus Rabbani', 'price' => 85, 'img' => 'assets/images/course-1.png', 'desc' => 'Understand the meanings and context of the Ayats.']
];
?>

<!-- Popular Courses Section (Dummy Slider) -->
<section class="section-padding" style="background: #fdfdfd; padding: 100px 0; overflow: hidden;">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-5">
            <div>
                <h2 class="section-title" style="color: var(--primary); margin-bottom: 10px;">Popular Courses</h2>
                <div style="width: 80px; height: 4px; background: var(--accent);"></div>
            </div>
            <div class="slider-controls-top d-none d-md-flex">
                <button class="slider-btn" onclick="document.getElementById('course-slider-home').scrollBy({left: -350, behavior: 'smooth'})"><i class="fas fa-chevron-left"></i></button>
                <button class="slider-btn" onclick="document.getElementById('course-slider-home').scrollBy({left: 350, behavior: 'smooth'})"><i class="fas fa-chevron-right"></i></button>
            </div>
        </div>

        <div id="course-slider-home" style="display: flex; gap: 25px; overflow-x: auto; scroll-behavior: smooth; padding: 10px 5px 30px; scrollbar-width: none; -ms-overflow-style: none;">
            <?php foreach($dummy_courses as $course): ?>
                <div style="min-width: 320px; flex: 0 0 320px;" data-aos="fade-up">
                    <div class="course-card-hijra">
                        <div class="course-img-box">
                            <img src="<?php echo $course['img']; ?>" alt="Course Banner" onerror="this.src='assets/images/default_course.jpg'">
                            <div class="course-price-tag">$<?php echo $course['price']; ?></div>
                        </div>
                        <div class="course-content-box">
                            <div class="course-instructor-hijra">
                                <i class="fas fa-user"></i> <?php echo $course['tutor']; ?>
                            </div>
                            <a href="#" class="course-title-hijra"><?php echo $course['title']; ?></a>
                            <p class="course-desc-hijra"><?php echo $course['desc']; ?></p>
                            <a href="#" class="btn-enroll-hijra">ENROLL NOW</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<style>
    #course-slider-home::-webkit-scrollbar { display: none; }
</style>



<!-- Features Grid (Trusted Platform) -->
<section class="section-padding" style="background: #f9fafb;">
    <div class="container">
        <div class="text-center" style="margin-bottom: 60px;">
             <h2 class="section-title">Most Trusted Platform to Learn Quran</h2>
             <div style="width: 60px; height: 3px; background: var(--accent); margin: 20px auto;"></div>
        </div>

        <div class="responsive-grid" style="gap: 30px;">
             <!-- Feature Item -->
            <div data-aos="fade-up" class="glass-card" style="display: flex; gap: 20px; background: white; padding: 35px; border-radius: 12px; border: 1px solid rgba(0,0,0,0.05); transition: all 0.3s ease; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
                <div style="width: 70px; height: 70px; background: var(--primary-light); border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                    <img src="assets/images/feature_class.png" alt="Classroom" style="height: 45px; width: auto;">
                </div>
                <div>
                     <h3 style="font-size: 1.25rem; margin-bottom: 10px; color: var(--primary); font-weight: 700;">Advanced Classroom</h3>
                     <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6;">Like sitting next to a teacher. Interactive video, audio and whiteboard.</p>
                </div>
            </div>
             <!-- Feature Item -->
            <div data-aos="fade-up" data-aos-delay="100" class="glass-card" style="display: flex; gap: 20px; background: white; padding: 35px; border-radius: 12px; border: 1px solid rgba(0,0,0,0.05); transition: all 0.3s ease; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
                <div style="width: 70px; height: 70px; background: var(--primary-light); border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                    <img src="assets/images/feature_lang.png" alt="Language" style="height: 45px; width: auto;">
                </div>
                <div>
                     <h3 style="font-size: 1.25rem; margin-bottom: 10px; color: var(--primary); font-weight: 700;">Learn in your Native Language</h3>
                     <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6;">Find tutors who speak your language for better understanding.</p>
                </div>
            </div>
             <!-- Feature Item -->
            <div data-aos="fade-up" data-aos-delay="200" class="glass-card" style="display: flex; gap: 20px; background: white; padding: 35px; border-radius: 12px; border: 1px solid rgba(0,0,0,0.05); transition: all 0.3s ease; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
                <div style="width: 70px; height: 70px; background: var(--primary-light); border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                    <img src="assets/images/course-1.png" alt="Multiple Tutors" style="height: 45px; width: auto;">
                </div>
                <div>
                     <h3 style="font-size: 1.25rem; margin-bottom: 10px; color: var(--primary); font-weight: 700;">Hire Multiple Tutors</h3>
                     <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6;">One for Tajweed, one for Hifz, or different tutors for different children.</p>
                </div>
            </div>
             <!-- Feature Item -->
            <div data-aos="fade-up" class="glass-card" style="display: flex; gap: 20px; background: white; padding: 35px; border-radius: 12px; border: 1px solid rgba(0,0,0,0.05); transition: all 0.3s ease; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
                <div style="width: 70px; height: 70px; background: var(--primary-light); border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                    <img src="assets/images/feature_female.png" alt="Female Tutors" style="height: 45px; width: auto;">
                </div>
                <div>
                     <h3 style="font-size: 1.25rem; margin-bottom: 10px; color: var(--primary); font-weight: 700;">Female Quran Tutors</h3>
                     <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6;">Qualified Female Quran Teachers available for sisters.</p>
                </div>
            </div>
             <!-- Feature Item -->
            <div data-aos="fade-up" data-aos-delay="100" class="glass-card" style="display: flex; gap: 20px; background: white; padding: 35px; border-radius: 12px; border: 1px solid rgba(0,0,0,0.05); transition: all 0.3s ease; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
                <div style="width: 70px; height: 70px; background: var(--primary-light); border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                    <img src="assets/images/hero-badge.png" alt="Verified" style="height: 45px; width: auto;">
                </div>
                <div>
                     <h3 style="font-size: 1.25rem; margin-bottom: 10px; color: var(--primary); font-weight: 700;">Hand-picked Tutors</h3>
                     <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6;">Choose from thousands of verified and hand-picked Quran Tutors.</p>
                </div>
            </div>
             <!-- Feature Item -->
            <div data-aos="fade-up" data-aos-delay="200" class="glass-card" style="display: flex; gap: 20px; background: white; padding: 35px; border-radius: 12px; border: 1px solid rgba(0,0,0,0.05); transition: all 0.3s ease; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
                <div style="width: 70px; height: 70px; background: var(--primary-light); border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                    <img src="assets/images/feature_kids.png" alt="Safe for Kids" style="height: 45px; width: auto;">
                </div>
                <div>
                     <h3 style="font-size: 1.25rem; margin-bottom: 10px; color: var(--primary); font-weight: 700;">Safe for Kids</h3>
                     <p style="color: var(--text-muted); font-size: 0.95rem; line-height: 1.6;">Safe Quran Classroom for kids and adults with parental monitoring.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section style="background: linear-gradient(rgba(15, 23, 42, 0.92), rgba(15, 23, 42, 0.95)), url('assets/images/hero_premium.png'); background-size: cover; background-position: center; background-attachment: fixed; padding: 100px 0; color: white; position: relative; overflow: hidden; text-align: center;">
    <!-- Decorative Circle -->
    <div style="position: absolute; top: -100px; right: -100px; width: 300px; height: 300px; background: radial-gradient(circle, rgba(197,160,89,0.15) 0%, rgba(0,0,0,0) 70%); border-radius: 50%;"></div>
    <div style="position: absolute; bottom: -50px; left: -50px; width: 200px; height: 200px; background: radial-gradient(circle, rgba(197,160,89,0.15) 0%, rgba(0,0,0,0) 70%); border-radius: 50%;"></div>

    <div class="container" style="position: relative; z-index: 1;">
        <div data-aos="fade-up" style="max-width: 800px; margin: 0 auto;">
            <h2 class="section-title" style="margin-bottom: 25px; line-height: 1.2; color: var(--accent); text-shadow: 0 2px 4px rgba(0,0,0,0.5);">Start Your Journey With The Holy Quran</h2>
            <p style="font-size: 1.25rem; color: rgba(255,255,255,0.95); margin-bottom: 45px; line-height: 1.8; text-shadow: 0 2px 4px rgba(0,0,0,0.3);">
                Connect with expert tutors who can help you learn to read, recite, and memorize the Quran. 
                Experience the best online classroom designed for students of all ages.
            </p>
            <div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;">
                 <a href="register.php" class="btn-main" style="padding: 18px 45px; font-size: 1.1rem; background: var(--accent); color: var(--primary); font-weight: 700; border-radius: 50px; text-decoration: none; transition: transform 0.3s ease; box-shadow: 0 10px 20px rgba(0,0,0,0.3); border: 2px solid var(--accent);">
                    <i class="fas fa-user-plus" style="margin-right: 10px;"></i> Join as Student
                 </a>
                 <a href="tutors.php" class="btn-main" style="padding: 18px 45px; font-size: 1.1rem; background: rgba(255,255,255,0.1); border: 2px solid rgba(255,255,255,0.4); color: white; font-weight: 700; border-radius: 50px; text-decoration: none; transition: all 0.3s ease; backdrop-filter: blur(5px);">
                    <i class="fas fa-search" style="margin-right: 10px;"></i> Browse Tutors
                 </a>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials -->
<section class="section-padding" style="background: white;">
    <div class="container text-center">
        <h2 class="section-title">What they say about us</h2>
        <div style="width: 60px; height: 3px; background: var(--accent); margin: 20px auto 50px;"></div>
        
        <div class="responsive-grid">
            <!-- Testimonial 1 -->
            <div data-aos="fade-up" class="glass-card" style="padding: 40px; text-align: left; position: relative; background: white; border-top: 5px solid var(--accent); border-radius: 12px; box-shadow: 0 15px 30px rgba(0,0,0,0.08);">
                <i class="fas fa-quote-right" style="position: absolute; top: 30px; right: 30px; font-size: 3rem; color: rgba(0,0,0,0.05);"></i>
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 25px;">
                    <div style="width: 50px; height: 50px; background: var(--primary-light); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 1.2rem;">P</div>
                    <div>
                         <div class="review-stars" style="color: #f4c150; font-size: 0.9rem;"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                         <strong style="color: var(--primary); font-size: 1rem;">Parent</strong> <span style="font-size: 0.9rem; color: #999;">from UK</span>
                    </div>
                </div>
                <p style="color: #555; font-size: 1.05rem; line-height: 1.7; font-style: italic;">"Excellent platform. My son has learned so much in just a few months. The tutor is very punctual and handles the class very professionally."</p>
            </div>
             <!-- Testimonial 2 -->
             <div data-aos="fade-up" data-aos-delay="100" class="glass-card" style="padding: 40px; text-align: left; position: relative; background: white; border-top: 5px solid var(--accent); border-radius: 12px; box-shadow: 0 15px 30px rgba(0,0,0,0.08);">
                <i class="fas fa-quote-right" style="position: absolute; top: 30px; right: 30px; font-size: 3rem; color: rgba(0,0,0,0.05);"></i>
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 25px;">
                    <div style="width: 50px; height: 50px; background: var(--primary-light); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 1.2rem;">S</div>
                    <div>
                         <div class="review-stars" style="color: #f4c150; font-size: 0.9rem;"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                         <strong style="color: var(--primary); font-size: 1rem;">Student</strong> <span style="font-size: 0.9rem; color: #999;">from USA</span>
                    </div>
                </div>
                <p style="color: #555; font-size: 1.05rem; line-height: 1.7; font-style: italic;">"I was hesitant about online learning but Qutor's classroom made it very easy. It's just like a real class, but from the comfort of my home."</p>
            </div>
             <!-- Testimonial 3 -->
             <div data-aos="fade-up" data-aos-delay="200" class="glass-card" style="padding: 40px; text-align: left; position: relative; background: white; border-top: 5px solid var(--accent); border-radius: 12px; box-shadow: 0 15px 30px rgba(0,0,0,0.08);">
                <i class="fas fa-quote-right" style="position: absolute; top: 30px; right: 30px; font-size: 3rem; color: rgba(0,0,0,0.05);"></i>
                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 25px;">
                    <div style="width: 50px; height: 50px; background: var(--primary-light); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 1.2rem;">H</div>
                    <div>
                         <div class="review-stars" style="color: #f4c150; font-size: 0.9rem;"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                         <strong style="color: var(--primary); font-size: 1rem;">Student</strong> <span style="font-size: 0.9rem; color: #999;">from Canada</span>
                    </div>
                </div>
                <p style="color: #555; font-size: 1.05rem; line-height: 1.7; font-style: italic;">"The ability to replay lessons is a game changer for Hifz students. Highly recommended for anyone serious about memorizing the Quran."</p>
            </div>
        </div>
    </div>
</section>




<!-- Our Skilled Instructors Section (Dummy & Repeating) -->
<section style="background: #f8f9fa; position: relative; padding: 100px 0; overflow: hidden;">
    <!-- Geometric Pattern Overlay -->
    <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background-image: url('assets/images/hero_pattern.png'); background-size: 300px; opacity: 0.03; pointer-events: none;"></div>
    
    <div class="container" style="position: relative; z-index: 2;">
        <div class="d-flex justify-content-between align-items-end mb-5">
            <div>
                <h2 style="font-family: 'Outfit', sans-serif; font-weight: 800; color: var(--primary); font-size: 2.8rem; margin-bottom: 10px;">Our Skilled Instructors</h2>
                <div style="width: 80px; height: 4px; background: var(--accent);"></div>
            </div>
            <div class="slider-controls-top d-none d-md-flex">
                <button class="slider-btn" onclick="document.getElementById('instructor-slider-hijra').scrollBy({left: -320, behavior: 'smooth'})"><i class="fas fa-chevron-left"></i></button>
                <button class="slider-btn" onclick="document.getElementById('instructor-slider-hijra').scrollBy({left: 320, behavior: 'smooth'})"><i class="fas fa-chevron-right"></i></button>
            </div>
        </div>

        <div id="instructor-slider-hijra" style="display: flex; gap: 25px; overflow-x: auto; scroll-behavior: smooth; padding: 10px 5px 30px; scrollbar-width: none; -ms-overflow-style: none;">
            <?php 
            $base_instructors = [
                ['name' => 'Shaykh Abdullah Nasir Rehmani', 'role' => 'Founder', 'img' => 'assets/images/sheikh_abdullah.png'],
                ['name' => 'Shaykh Usman Safder', 'role' => 'CEO & Co-Founder', 'img' => 'https://hijraonline.com/wp-content/uploads/2021/09/avatar_user_16_1631194592.jpg'],
                ['name' => 'Shaykh Abdullah Shamim', 'role' => 'Deputy CEO & Instructor', 'img' => 'https://hijraonline.com/wp-content/uploads/2024/03/avatar_user_17_1709817818-360x360.jpg'],
                ['name' => 'Shaykh Kamran Yaseen', 'role' => 'Senior Instructor', 'img' => 'https://hijraonline.com/wp-content/uploads/2021/09/avatar_user_19_1631112407.jpg'],
                ['name' => 'Shaykh Jamshed Sultan', 'role' => 'Instructor', 'img' => 'https://hijraonline.com/wp-content/uploads/2024/03/avatar_user_18_1709826687-360x360.jpg'],
                ['name' => 'Shaykh Obaid-ur-Rehman Muhammadi', 'role' => 'Senior Scholar', 'img' => 'https://hijraonline.com/wp-content/uploads/2024/03/avatar_user_20_1709818169-360x360.jpg'],
                ['name' => 'Shaykh Badi-ud-Din Abdullah', 'role' => 'Senior Instructor', 'img' => 'https://hijraonline.com/wp-content/uploads/2021/09/avatar_user_21_1631112310.jpg'],
                ['name' => 'Shaykh Taha Pasha', 'role' => 'Islamic Scholar', 'img' => 'https://hijraonline.com/wp-content/uploads/2021/09/avatar_user_22_1631112468.jpg'],
                ['name' => 'Shaykh Dr. Faraz-ul-Haq', 'role' => 'Academic Dean', 'img' => 'https://hijraonline.com/wp-content/uploads/2024/03/avatar_user_534_1709818041-360x360.jpg'],
                ['name' => 'Shaykh Musab Abrar', 'role' => 'Senior Instructor', 'img' => 'https://hijraonline.com/wp-content/uploads/2024/03/avatar_user_1387_1709826805-360x360.jpg']
            ];
            // Repeating instructors for a "full" look - multiple repetitions as requested
            $all_instructors = array_merge($base_instructors, $base_instructors, $base_instructors);
            foreach($all_instructors as $ins): 
            ?>
                <div style="min-width: 280px; flex: 0 0 280px;" data-aos="fade-up">
                    <a href="tutor_profile.php?name=<?php echo urlencode($ins['name']); ?>&role=<?php echo urlencode($ins['role']); ?>&img=<?php echo urlencode($ins['img']); ?>" style="text-decoration: none; display: block;">
                        <div class="instructor-card">
                            <div class="instructor-img-wrapper">
                                <img src="<?php echo $ins['img']; ?>" alt="<?php echo $ins['name']; ?>">
                            </div>
                            <h3 class="instructor-name"><?php echo $ins['name']; ?></h3>
                            <span class="instructor-role"><?php echo $ins['role']; ?></span>
                            <div class="instructor-accent"></div>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<style>
    #instructor-slider-hijra::-webkit-scrollbar { display: none; }
</style>



<!-- Our Skilled Instructors (Hijra Style) ... (scripts handled in footer) -->
<?php include 'includes/footer.php'; ?>
