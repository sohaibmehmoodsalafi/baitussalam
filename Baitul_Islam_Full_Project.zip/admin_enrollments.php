<?php
session_start();
require 'includes/db.php';
require 'includes/send_email.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Handle Expiry Logic
$current_date = date('Y-m-d H:i:s');
$stmt = $pdo->prepare("UPDATE enrollments SET status = 'completed' WHERE expiry_date < ? AND status = 'active'");
$stmt->execute([$current_date]);
$expired_count = $stmt->rowCount();

// Handle Assignment & Activation
if (isset($_POST['assign_tutor']) || isset($_POST['approve_referral'])) {
    $enrollment_id = $_POST['enrollment_id'];
    $tutor_id = $_POST['tutor_id'] ?? null;
    
    try {
        if (isset($_POST['approve_referral'])) {
            // Already has a tutor, just activate
            $stmt = $pdo->prepare("UPDATE enrollments SET status = 'active' WHERE id = ?");
            $stmt->execute([$enrollment_id]);
            $assign_success = "Referral assignment activated!";
        } else {
            // Assign new tutor and activate
            $stmt = $pdo->prepare("UPDATE enrollments SET assigned_tutor_id = ?, status = 'active' WHERE id = ?");
            $stmt->execute([$tutor_id, $enrollment_id]);
            $assign_success = "Tutor assigned and student activated!";

            // --- Send Email Notifications ---
            // 1. Fetch relevant details for the email
            $stmt = $pdo->prepare("
                SELECT e.*, s.name as student_name, s.email as student_email, s.phone as student_phone,
                       t.name as tutor_name, t.email as tutor_email, t.phone as tutor_phone,
                       c.title as course_title
                FROM enrollments e
                JOIN students s ON e.student_id = s.id
                JOIN tutors t ON e.assigned_tutor_id = t.id
                JOIN courses c ON e.course_id = c.id
                WHERE e.id = ?
            ");
            $stmt->execute([$enrollment_id]);
            $details = $stmt->fetch();

            if ($details) {
                // Email to Student
                $student_subject = "Teacher Assigned! Your Course is Active - Peace Institute";
                $student_body = "
                    <div style='font-family: Arial, sans-serif; padding: 20px; border: 1px solid #eee; border-radius: 10px;'>
                        <h2 style='color: #0F5132;'>Assalamu Alaikum " . htmlspecialchars($details['student_name']) . "!</h2>
                        <p>Great news! Your enrollment for <strong>" . htmlspecialchars($details['course_title']) . "</strong> has been activated.</p>
                        <p><strong>Your Assigned Teacher:</strong> " . htmlspecialchars($details['tutor_name']) . "</p>
                        <p><strong>Teacher Contact:</strong> " . htmlspecialchars($details['tutor_email']) . " (" . htmlspecialchars($details['tutor_phone']) . ")</p>
                        <p>You can now log in to your dashboard to start your classes.</p>
                        <hr>
                        <p>JazakAllah Khair,<br>Peace Institute Team</p>
                    </div>";
                sendEmail($details['student_email'], $student_subject, $student_body);

                // Email to Tutor
                $tutor_subject = "New Student Assigned! - Peace Institute";
                $tutor_body = "
                    <div style='font-family: Arial, sans-serif; padding: 20px; border: 1px solid #eee; border-radius: 10px;'>
                        <h2 style='color: #0F5132;'>Assalamu Alaikum " . htmlspecialchars($details['tutor_name']) . "!</h2>
                        <p>You have been assigned a new student for the course: <strong>" . htmlspecialchars($details['course_title']) . "</strong>.</p>
                        <p><strong>Student Name:</strong> " . htmlspecialchars($details['student_name']) . "</p>
                        <p><strong>Student Contact:</strong> " . htmlspecialchars($details['student_email']) . " (" . htmlspecialchars($details['student_phone']) . ")</p>
                        <p>Please log in to your dashboard to manage your schedule with the student.</p>
                        <hr>
                        <p>JazakAllah Khair,<br>Peace Institute Team</p>
                    </div>";
                sendEmail($details['tutor_email'], $tutor_subject, $tutor_body);
            }
        }
    } catch (PDOException $e) {
        $assign_error = "Error: " . $e->getMessage();
    }
}

// Handle Enrollment Deletion
if (isset($_POST['delete_enrollment'])) {
    $enrollment_id = $_POST['enrollment_id'];
    try {
        $stmt = $pdo->prepare("DELETE FROM enrollments WHERE id = ?");
        $stmt->execute([$enrollment_id]);
        $assign_success = "Enrollment deleted successfully!";
    } catch (PDOException $e) {
        $assign_error = "Delete failed: " . $e->getMessage();
    }
}

// Fetch All Active Tutors for fallback list
$all_tutors_stmt = $pdo->query("SELECT id, name FROM tutors WHERE is_active = 1 ORDER BY name ASC");
$global_tutors = $all_tutors_stmt->fetchAll();

// Fetch Enrollments - Using LEFT JOIN for courses so we can see orphaned enrollments
$stmt = $pdo->query("
    SELECT e.*, s.name as student_name, s.email as student_email, c.title as course_title, 
           t_orig.name as course_tutor_name, t_assigned.name as assigned_tutor_name
    FROM enrollments e
    JOIN students s ON e.student_id = s.id
    LEFT JOIN courses c ON e.course_id = c.id
    LEFT JOIN tutors t_orig ON c.tutor_id = t_orig.id
    LEFT JOIN tutors t_assigned ON e.assigned_tutor_id = t_assigned.id
    ORDER BY e.enrolled_at DESC
");
$enrollments = $stmt->fetchAll();

// Fetch all tutors grouped by course title for assignment dropdowns
$tutors_stmt = $pdo->query("SELECT t.id, t.name, c.title FROM tutors t JOIN courses c ON c.tutor_id = t.id WHERE t.is_active = 1");
$all_available_tutors = $tutors_stmt->fetchAll();
$tutors_by_course = [];
foreach($all_available_tutors as $t) {
    $tutors_by_course[$t['title']][] = $t;
}

include 'includes/admin_header_layout.php';
?>

<div class="d-flex" id="wrapper">
    <?php include 'includes/admin_sidebar.php'; ?> 

    <div id="page-content-wrapper">
        <!-- Top Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 px-4 mb-4 border-bottom shadow-sm">
            <div class="container-fluid">
                <div class="d-flex align-items-center">
                    <button class="btn btn-light d-lg-none me-3" id="menu-toggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h4 class="fw-bold mb-0 text-dark">Enrollment Management</h4>
                </div>
                
                <div class="user-profile">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=0F5132&color=fff" class="avatar">
                    <div class="user-info d-none d-sm-flex ms-2">
                        <span class="name">Administrator</span>
                        <span class="role text-muted small">Super Admin</span>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid px-4">
            
            <?php if(isset($assign_success)): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4 border-0 shadow-sm mb-4" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $assign_success; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if(isset($assign_error)): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4 border-0 shadow-sm mb-4" role="alert">
                    <i class="fas fa-exclamation-circle me-2"></i> <?php echo $assign_error; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <?php if($expired_count > 0): ?>
                <div class="alert alert-warning alert-dismissible fade show rounded-4 border-0 shadow-sm mb-4" role="alert">
                    <i class="fas fa-clock me-2"></i> Automatically expired <strong><?php echo $expired_count; ?></strong> ended courses.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-5">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
                    <h5 class="mb-0 fw-bold text-dark"><i class="fas fa-calendar-check me-2 text-primary"></i> Course Enrollments</h5>
                    <div class="d-flex gap-2">
                        <button class="btn btn-outline-secondary btn-sm rounded-pill px-3"><i class="fas fa-download me-1"></i> Export</button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">Student</th>
                                    <th>Course & Tutor</th>
                                    <th>Plan Type</th>
                                    <th>Timeline</th>
                                    <th>Status</th>
                                    <th class="text-end pe-4">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($enrollments as $enrol): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-circle bg-primary-subtle text-primary fw-bold d-flex align-items-center justify-content-center me-3" style="width:38px; height:38px; border-radius:10px;">
                                                <?php echo strtoupper(substr($enrol['student_name'], 0, 1)); ?>
                                            </div>
                                            <div>
                                                <div class="fw-bold text-dark small"><?php echo htmlspecialchars($enrol['student_name']); ?></div>
                                                <div class="text-muted small" style="font-size: 0.75rem;"><?php echo htmlspecialchars($enrol['student_email']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-primary small mb-1">
                                            <?php echo $enrol['course_title'] ? htmlspecialchars($enrol['course_title']) : '<span class="text-danger">[DELETED COURSE]</span>'; ?>
                                        </div>
                                        <div class="text-muted small">
                                            <?php if($enrol['assigned_tutor_id']): ?>
                                                <i class="fas fa-chalkboard-teacher me-1 text-success"></i> 
                                                <span class="fw-bold"><?php echo htmlspecialchars($enrol['assigned_tutor_name']); ?></span>
                                                <?php if($enrol['status'] == 'pending'): ?>
                                                    <span class="badge bg-info-subtle text-info ms-1" style="font-size: 0.6rem; text-transform: uppercase;">Direct Referral</span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <i class="fas fa-user-slash me-1 text-danger opacity-50"></i> 
                                                <span class="text-danger fw-medium italic">Unassigned</span>
                                            <?php endif; ?>
                                        </div>
                                        <?php if($enrol['status'] == 'pending'): ?>
                                            <div class="badge bg-warning-subtle text-warning border border-warning-subtle py-1 px-2 mt-1" style="font-size: 0.7rem;">
                                                <i class="fas fa-user-clock me-1"></i> Waiting for Admin
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php 
                                            $plan = $enrol['plan_type'] ?? 'monthly';
                                            $badgeClass = match($plan) {
                                                'yearly' => 'bg-warning-subtle text-warning-emphasis',
                                                'quarterly' => 'bg-info-subtle text-info-emphasis',
                                                default => 'bg-light text-dark border'
                                            };
                                        ?>
                                        <span class="badge <?php echo $badgeClass; ?> rounded-pill px-3 py-2 text-capitalize">
                                            <?php echo $plan; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="small">
                                            <div class="text-dark mb-1"><i class="far fa-calendar-alt me-2 text-muted"></i><?php echo date('M d, Y', strtotime($enrol['enrolled_at'])); ?></div>
                                            <div class="text-muted" style="font-size: 0.75rem;">
                                                Expires: 
                                                <?php if($enrol['expiry_date']): ?>
                                                    <?php 
                                                        $expiry = strtotime($enrol['expiry_date']);
                                                        $is_near = ($expiry - time() < 86400 * 7) && ($expiry > time());
                                                        $textClass = $is_near ? 'text-danger fw-bold' : '';
                                                        echo "<span class='$textClass'>" . date('M d, Y', $expiry) . "</span>";
                                                    ?>
                                                <?php else: ?>
                                                    N/A
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($enrol['status'] == 'active'): ?>
                                            <span class="badge bg-success-subtle text-success rounded-pill px-3 py-2">
                                                <i class="fas fa-check-circle me-1"></i> Active
                                            </span>
                                        <?php elseif($enrol['status'] == 'pending'): ?>
                                            <span class="badge bg-warning-subtle text-warning rounded-pill px-3 py-2">
                                                <i class="fas fa-clock me-1"></i> Pending
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary-subtle text-secondary rounded-pill px-3 py-2">
                                                <i class="fas fa-times-circle me-1"></i> <?php echo ucfirst($enrol['status']); ?>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end pe-4">
                                        <?php if($enrol['status'] == 'pending'): ?>
                                            <?php if($enrol['assigned_tutor_id']): ?>
                                                <!-- Case: Has Referral, Just Approve -->
                                                <button onclick="submitAssignment(<?php echo $enrol['id']; ?>, <?php echo $enrol['assigned_tutor_id']; ?>, 'approve')" class="btn btn-success btn-sm rounded-pill px-3 shadow-sm" style="font-weight: 700; background: #15803d; border: none;">
                                                    <i class="fas fa-check-circle me-1"></i> Approve Ref
                                                </button>
                                                
                                                <!-- Allow changing referral if needed -->
                                                <div class="dropdown d-inline-block">
                                                    <button class="btn btn-light btn-sm rounded-circle border p-0 transition-all" style="width: 32px; height: 32px;" type="button" data-bs-toggle="dropdown">
                                                        <i class="fas fa-ellipsis-v"></i>
                                                    </button>
                                                    <ul class="dropdown-menu dropdown-menu-end shadow p-2 rounded-3 border-0">
                                                        <li class="dropdown-header small fw-bold">Change Teacher</li>
                                                        <?php foreach($global_tutors as $gt): ?>
                                                            <li><a class="dropdown-item py-2 rounded-2 small" href="javascript:void(0)" onclick="submitAssignment(<?php echo $enrol['id']; ?>, <?php echo $gt['id']; ?>, 'assign')">Assign: <?php echo htmlspecialchars($gt['name']); ?></a></li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </div>
                                            <?php else: ?>
                                                <!-- Case: No Referral, Assign New -->
                                                <div class="dropdown d-inline-block">
                                                    <button class="btn btn-primary btn-sm rounded-pill px-3 dropdown-toggle shadow-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="font-weight: 700;">
                                                        Assign Teacher
                                                    </button>
                                                    <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-3 p-2" style="min-width: 250px; max-height: 350px; overflow-y: auto;">
                                                        <li class="dropdown-header text-uppercase fw-bold pb-2" style="font-size: 0.65rem;">Recommended Teachers</li>
                                                        <?php 
                                                            $course_title = $enrol['course_title'];
                                                            $matched = $tutors_by_course[$course_title] ?? [];
                                                            $matched_ids = array_column($matched, 'id');
                                                            foreach($matched as $tutor):
                                                        ?>
                                                            <li>
                                                                <a class="dropdown-item rounded-2 py-2 d-flex align-items-center justify-content-between" href="javascript:void(0)" onclick="submitAssignment(<?php echo $enrol['id']; ?>, <?php echo $tutor['id']; ?>, 'assign')">
                                                                    <span><i class="fas fa-star text-warning me-2"></i> <?php echo htmlspecialchars($tutor['name']); ?></span>
                                                                    <small class="badge bg-success-subtle text-success ms-2" style="font-size: 0.6rem;">Match</small>
                                                                </a>
                                                            </li>
                                                        <?php endforeach; ?>
                                                        
                                                        <li class="dropdown-divider"></li>
                                                        <li class="dropdown-header text-uppercase fw-bold pb-2" style="font-size: 0.65rem;">All Teachers</li>
                                                        <?php foreach($global_tutors as $gt): 
                                                            if(in_array($gt['id'], $matched_ids)) continue;
                                                        ?>
                                                            <li><a class="dropdown-item rounded-2 py-2 small" href="javascript:void(0)" onclick="submitAssignment(<?php echo $enrol['id']; ?>, <?php echo $gt['id']; ?>, 'assign')"><?php echo htmlspecialchars($gt['name']); ?></a></li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <div class="d-flex justify-content-end gap-2">
                                                <button class="btn btn-light btn-sm rounded-circle border p-0 d-inline-flex align-items-center justify-content-center" style="width: 32px; height: 32px;" title="View Details">
                                                    <i class="fas fa-eye text-muted" style="font-size: 0.8rem;"></i>
                                                </button>
                                                <form method="POST" onsubmit="return confirm('Silently remove this enrollment record? Student will no longer see it.');" class="d-inline">
                                                    <input type="hidden" name="enrollment_id" value="<?php echo $enrol['id']; ?>">
                                                    <button type="submit" name="delete_enrollment" class="btn btn-danger btn-sm rounded-circle border p-0 d-inline-flex align-items-center justify-content-center" style="width: 32px; height: 32px;" title="Delete Enrollment">
                                                        <i class="fas fa-trash" style="font-size: 0.75rem;"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <?php if(empty($enrollments)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-5 text-muted">
                                            <i class="fas fa-layer-group fa-3x mb-3 opacity-25"></i>
                                            <p>No enrollment records found.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Hidden Assignment Form -->
<form id="assignmentForm" method="POST" style="display:none;">
    <input type="hidden" name="enrollment_id" id="form_enroll_id">
    <input type="hidden" name="tutor_id" id="form_tutor_id">
    <input type="hidden" name="action_type" id="form_action_type">
</form>

<script>
// Sidebar Toggle
document.getElementById("menu-toggle")?.addEventListener("click", function(e) {
    e.preventDefault();
    document.getElementById("wrapper").classList.toggle("toggled");
});

// Robust Assignment Submission
function submitAssignment(enroll_id, tutor_id, type) {
    if(confirm('Are you sure you want to ' + (type === 'approve' ? 'approve this referral?' : 'assign this teacher?') )) {
        document.getElementById('form_enroll_id').value = enroll_id;
        document.getElementById('form_tutor_id').value = tutor_id;
        document.getElementById('form_action_type').value = type;
        
        // Add the correct submit name dynamically
        const submitBtn = document.createElement('input');
        submitBtn.type = 'hidden';
        submitBtn.name = (type === 'approve' ? 'approve_referral' : 'assign_tutor');
        submitBtn.value = '1';
        
        const form = document.getElementById('assignmentForm');
        form.appendChild(submitBtn);
        form.submit();
    }
}
</script>

<?php include 'includes/admin_footer.php'; ?>
