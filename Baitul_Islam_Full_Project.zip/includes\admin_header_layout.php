<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
// No-cache headers
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Baitul Islam</title>
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom Sidebar Styles -->
    <style>
        <?php include 'includes/sidebar_css.php'; ?>
        
        body { 
            font-family: 'Outfit', sans-serif; 
            background-color: #f8fafc; 
            overflow-x: hidden; 
        }
        
        /* Utility for all admin pages */
        .transition-all { transition: all 0.3s ease; }
    </style>
</head>
<body>
