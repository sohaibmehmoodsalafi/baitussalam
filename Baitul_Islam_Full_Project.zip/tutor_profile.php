<?php
include 'includes/header.php';

// Get parameters from URL (Dummy Data Mode)
$name = $_GET['name'] ?? 'Shaykh Usman Safder';
$role = $_GET['role'] ?? 'CEO & Co-Founder';
$img = $_GET['img'] ?? 'https://hijraonline.com/wp-content/uploads/2021/09/avatar_user_16_1631194592.jpg';

// Auto-Override for Founder
if(stripos($name, 'Abdullah Nasir Rehmani') !== false) {
    $img = 'assets/images/sheikh_abdullah.png';
}

// Content Mapping Array
$teachers_data = [
    'Shaykh Usman Safder' => [
        'en' => [
            'personal' => 'Shaykh Usman Safder was born in 1984 at Gulshan Hadeed, Karachi. He is a dedicated educator with a vision for digital dawah.',
            'education' => 'He received his early education in his hometown after which he did Hifz of The Holy Quran at Masjid Taweed. In 1999, he acquired admission at Madrasah Almahad-us-Salafi and completed his Dars-e-Nizami Course. Later, he was selected for Kulyatul Hadith at Islamic University of Madinah, Saudi Arabia.',
            'positions' => ['Head of Baitul Islam', 'Al-Madinah Islamic Research Center', 'Nibras Institute'],
            'foundation' => 'After coming back to Pakistan, he realized the need of an institution to provide Da’wah through digital means. He founded Baitul Islam under the supervision of Shaykh Abdullah Nasir Rehmani.',
            'services' => 'Providing services at Baitul Islam and Al-Bayaan Institute. He conducts public talks at Role Model and Burooj Institutes.',
            'specialties' => ['Aqeedah', 'Hadith', 'Islamic Finance'],
            'publications' => ['Al-La’aali Al-Muziyyah'],
            'translations' => ['Manhaje Ahle Hadith (Sharh As-Sunnah by Imam Al-Barbahari)']
        ],
        'ur' => [
            'personal' => 'شیخ عثمان صفدر 1984 میں گلشن حدید، کراچی میں پیدا ہوئے۔ وہ ایک وقف معلم ہیں اور ڈیجیٹل دعوت کا وژن رکھتے ہیں۔',
            'education' => 'انہوں نے اپنی ابتدائی تعلیم اپنے آبائی شہر میں حاصل کی جس کے بعد مسجد توحید میں حفظِ قرآن مکمل کیا۔ 1999 میں مدرسہ المعہد السلفی میں داخلہ لیا اور اپنا درسِ نظامی کورس مکمل کیا۔ بعد ازاں، جامعہ اسلامیہ مدینہ منورہ میں کلیۃ الحدیث کے لیے منتخب ہوئے۔',
            'positions' => ['سربراہ، بیت الاسلام', 'المعہد المدینہ اسلامک ریسرچ سینٹر', 'نبراس انسٹی ٹیوٹ'],
            'foundation' => 'پاکستان واپسی پر انہوں نے ڈیجیٹل ذرائع سے دعوتِ دین کی ضرورت کو محسوس کیا اور شیخ عبداللہ ناصر رحمانی کی زیر نگرانی بیت الاسلام کی بنیاد رکھی۔',
            'services' => 'بیت الاسلام اور البیان انسٹی ٹیوٹ میں تدریسی خدمات، اور رول ماڈل و بروج انسٹی ٹیوٹ میں عوامی خطابات۔',
            'specialties' => ['عقیدہ', 'حدیث', 'اسلامی مالیات'],
            'publications' => ['اللآالی المضیئۃ'],
            'translations' => ['منہجِ اہل حدیث (شرح السنہ از امام البربہاری)']
        ]
    ],
    'Shaykh Abdullah Nasir Rehmani' => [
        'en' => [
            'personal' => 'Shaykh Abdullah Nasir Rehmani bin Abdur-Rashid was born on December 28, 1958. He is a world-renowned scholar specializing in Hadith and Uloom-ul-Hadith.',
            'education' => 'Degree in Dars-e-Nizami from Jamia Dar-ul-Hadith Rehmania. Earned a higher degree in Hadith from Imam Mohammad Ibn Saud Islamic University, Riyadh, Saudi Arabia.',
            'positions' => ['Emir of Jamiat Ahle Hadith, Sindh', 'Founder & President of Baitul Islam', 'President of Al-Madinah Islamic Research Center'],
            'foundation' => 'Founded Baitul Islam in 1999 to preserve sacred knowledge through classical and modern academic structures.',
            'services' => 'Started career at Abu Bakr Islamic University. Currently serving as Shaykh-ul-Hadith at Almahad-us-Salafi Littaleem Wattarbiyah.',
            'specialties' => ['Hadith Sciences', 'Aqeedah', 'Fiqh'],
            'publications' => ['Al-Manhaj-ul As’ad', 'Sharh Hadith Jibril', 'Khutbaat-e-Rehmani'],
            'translations' => ['Tawhid Ilaahul Alameen', 'Aqidah Firqa-e-Najia', 'Bunyadi Aqa\'id']
        ],
        'ur' => [
            'personal' => 'شیخ عبداللہ ناصر رحمانی بن عبدالرشید 28 دسمبر 1958 کو پیدا ہوئے۔ آپ حدیث اور علوم الحدیث کے عالمی سطح پر معروف عالمِ دین ہیں۔',
            'education' => 'جامعہ دارالحدیث رحمانیہ سے درسِ نظامی کی سند حاصل کی۔ امام محمد بن سعود اسلامی یونیورسٹی، ریاض، سعودی عرب سے حدیث میں اعلیٰ ڈگری حاصل کی۔',
            'positions' => ['امیر، جمعیت اہلحدیث سندھ', 'بانی و صدر، بیت الاسلام', 'صدر، المعہد المدینہ اسلامک ریسرچ سینٹر'],
            'foundation' => 'آپ نے 1999 میں بیت الاسلام کی بنیاد رکھی تاکہ قدیم و جدید تعلیمی ڈھانچے کے ذریعے مقدس علوم کی حفاظت کی جا سکے۔',
            'services' => 'تدریسی سفر کا آغاز ابوبکر اسلامی یونیورسٹی سے کیا۔ اس وقت مدرسہ المعہد السلفی میں شیخ الحدیث کے طور پر خدمات انجام دے رہے ہیں۔',
            'specialties' => ['علوم الحدیث', 'عقیدہ', 'فقہ'],
            'publications' => ['المنہج الاسعد', 'شرح حدیث جبرائیل', 'خطباتِ رحمانی'],
            'translations' => ['توحید الہ العالمین', 'عقیدہ فرقہ ناجیہ', 'بنیادی عقائد']
        ]
    ],
    'Shaykh Abdullah Shamim' => [
        'en' => [
            'personal' => 'Shaykh Abdullah Shamim was born on April 8, 1985. He serves as the Deputy CEO and a dedicated researcher at Baitul Islam.',
            'education' => 'Completed Dars-e-Nizami at Almahad-us-Salafi. Earned his Master’s degree from the Islamic University of Madinah, specializing in Shariah.',
            'positions' => ['Deputy CEO, Baitul Islam', 'Instructor at Madrasah Almahad-us-Salafi', 'Researcher at Al-Madinah Center'],
            'foundation' => 'Key pillar in the growth of Baitul Islam, focusing on research-based dawah and academic excellence.',
            'services' => 'Providing teaching services at Baitul Islam and delivering regular religious sermons (Khutbas) across Pakistan.',
            'specialties' => ['Islamic Jurisprudence (Fiqh)', 'Shariah', 'Quranic Memorization'],
            'publications' => ['Maali Jurmaany Ki Shar’e Hesiat', 'Hujiyyatu Qawlus Sahabi'],
            'translations' => ['Sahifah Hammam ibn Munabbih (Translation & Explanation)']
        ],
        'ur' => [
            'personal' => 'شیخ عبداللہ شمیم 8 اپریل 1985 کو پیدا ہوئے۔ آپ نائب سی ای او اور ایک بہترین محقق کی حیثیت سے خدمات انجام دے رہے ہیں۔',
            'education' => 'المعہد السلفی سے درسِ نظامی مکمل کیا۔ جامعہ اسلامیہ مدینہ منورہ سے شریعہ میں ماسٹرز کی ڈگری حاصل کی۔',
            'positions' => ['نائب سی ای او، بیت الاسلام', 'استاد، مدرسہ المعہد السلفی', 'محقق، المعہد المدینہ ریسرچ سینٹر'],
            'foundation' => 'آپ بیت الاسلام کی ترقی میں ایک اہم ستون رہے ہیں، جس کا مرکز تحقیقی بنیادوں پر دعوت اور تعلیمی فضیلت ہے۔',
            'services' => 'بیت الاسلام میں تدریسی خدمات اور پاکستان کے مختلف شہروں میں باقاعدہ مذہبی خطبات (جمعہ و دیگر) کی فراہمی۔',
            'specialties' => ['اسلامی فقہ', 'شریعہ', 'حفظِ قرآن'],
            'publications' => ['مالی جرمانے کی شرعی حیثیت', 'حجیتِ قولِ صحابی'],
            'translations' => ['صحیفہ ہمام بن منبہ (ترجمہ و تشریح)']
        ]
    ]
];

// Fallback logic
$current_data = null;
foreach($teachers_data as $t_name => $data) {
    if(stripos($name, $t_name) !== false) { $current_data = $data; break; }
}
if(!$current_data) {
    $current_data = [
        'en' => ['personal'=>$name.' is an educator at Baitul Islam.','education'=>'Scholarly Islamic education.','positions'=>['Teacher, Baitul Islam'],'foundation'=>'Spreading authentic knowledge.','services'=>'Instruction in Tajweed.','specialties'=>['Quran'],'publications'=>['N/A'],'translations'=>['N/A']],
        'ur' => ['personal'=>$name.' بیت الاسلام سے وابستہ معلم ہیں۔','education'=>'اعلیٰ اسلامی تعلیم۔','positions'=>['استاد، بیت الاسلام'],'foundation'=>'مستند علم کی اشاعت۔','services'=>'تجوید کی تدریس۔','specialties'=>['قرآن'],'publications'=>['N/A'],'translations'=>['N/A']]
    ];
}
?>

<style>
    :root { --hijra-navy: #002147; --hijra-gold: #c5a059; }
    .navbar { background: var(--hijra-navy) !important; position: relative !important; z-index: 1000 !important; }
    .navbar .nav-links a, .navbar .login-text-link { color: white !important; }
    .profile-hero { background: var(--hijra-navy); padding: 50px 0 110px; position: relative; }
    .breadcrumb-hijra { color: rgba(255,255,255,0.7); font-size: 0.85rem; margin-bottom: 20px; }
    .breadcrumb-hijra span { color: var(--hijra-gold); font-weight: 700; }
    .teacher-main-card { background: var(--hijra-navy); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 40px; display: flex; align-items: center; gap: 35px; box-shadow: 0 20px 50px rgba(0,0,0,0.25); margin-top: -85px; position: relative; z-index: 10; color: white; }
    .teacher-portrait { width: 170px; height: 170px; border-radius: 8px; border: 4px solid rgba(255,255,255,0.1); object-fit: cover; }
    .sidebar-menu { background: white; border-radius: 10px; padding: 20px 0; box-shadow: 0 10px 30px rgba(0,0,0,0.05); border: 1px solid #eee; position: sticky; top: 100px; }
    .sidebar-link { display: flex; align-items: center; gap: 15px; padding: 12px 25px; color: #555; text-decoration: none; font-weight: 600; cursor: pointer; transition: 0.3s; }
    .sidebar-link.active { background: var(--hijra-gold); color: white; border-left-color: white; }
    .sidebar-link i { font-size: 1rem; width: 22px; text-align: center; }
    .content-area { background: white; border-radius: 10px; padding: 50px; box-shadow: 0 5px 30px rgba(0,0,0,0.03); border: 1px solid #eee; min-height: 500px; }
    .section-title-hijra { font-family: 'Outfit', sans-serif; font-weight: 800; color: var(--hijra-navy); margin-bottom: 30px; font-size: 1.8rem; padding-bottom: 10px; border-bottom: 2px solid #f0f0f0; display: flex; justify-content: space-between; align-items: center; }
    .bio-text { font-size: 1.05rem; line-height: 1.8; color: #333; }
    .bio-text h3 { font-size: 1.25rem; color: var(--hijra-navy); font-weight: 800; margin-top: 35px; margin-bottom: 15px; }
    .bio-text ul { list-style: none; padding-left: 0; margin-bottom: 25px; }
    .bio-text li { position: relative; padding-left: 20px; margin-bottom: 10px; }
    .bio-text li::before { content: '•'; position: absolute; left: 0; color: var(--hijra-gold); font-weight: 900; font-size: 1.5rem; line-height: 1; }
    .content-section { display: none; }
    .content-section.active { display: block; }
    .urdu-text { direction: rtl; font-family: 'Noto Nastaliq Urdu', serif; text-align: right; line-height: 2.5; font-size: 1.2rem; }
    .urdu-text h3 { text-align: right; font-size: 1.6rem; }
    .urdu-text li { padding-right: 25px; }
    .urdu-text li::before { left: auto; right: 0; }
    .btn-translate-toggle { background: var(--hijra-gold); color: white; border: none; padding: 5px 15px; border-radius: 5px; font-size: 0.85rem; font-weight: 700; cursor: pointer; display: none; }
</style>
<link href="https://fonts.googleapis.com/css2?family=Noto+Nastaliq+Urdu:wght@400;700&display=swap" rel="stylesheet">

<div class="profile-hero">
    <div class="container" style="position: relative; z-index: 2;">
        <div class="breadcrumb-hijra">Baitul Islam &nbsp; <i class="fas fa-chevron-right mx-2" style="font-size: 0.7rem;"></i> &nbsp; <span>Profile</span></div>
    </div>
</div>

<div class="container" style="margin-bottom: 100px;">
    <div class="teacher-main-card" data-aos="fade-up">
        <img src="<?php echo htmlspecialchars($img); ?>" alt="<?php echo htmlspecialchars($name); ?>" class="teacher-portrait">
        <div>
            <h1 style="font-family: 'Outfit', sans-serif; font-size: 2.6rem; font-weight: 800; margin-bottom: 5px;"><?php echo htmlspecialchars($name); ?></h1>
            <div style="color: var(--hijra-gold); font-size: 1.1rem; font-weight: 700; letter-spacing: 2px; text-transform: uppercase;"><?php echo htmlspecialchars($role); ?></div>
        </div>
    </div>

    <div class="row g-5 mt-4">
        <div class="col-lg-3">
            <div class="sidebar-menu">
                <div class="sidebar-link active" onclick="showSection('dashboard', this)"><i class="fas fa-th-large"></i> Dashboard</div>
                <div class="sidebar-link" onclick="showSection('info', this)"><i class="fas fa-user-circle"></i> Personal Information</div>
                <div class="sidebar-link" onclick="showSection('education', this)"><i class="fas fa-graduation-cap"></i> Education</div>
                <div class="sidebar-link" onclick="showSection('positions', this)"><i class="fas fa-university"></i> Religious Positions</div>
                <div class="sidebar-link" onclick="showSection('services', this)"><i class="fas fa-book-reader"></i> Teaching Services</div>
                <div class="sidebar-link" onclick="showSection('specialties', this)"><i class="fas fa-award"></i> Specialties</div>
                <div class="sidebar-link" onclick="showSection('publications', this)"><i class="fas fa-print"></i> Publications</div>
            </div>
        </div>

        <div class="col-lg-9">
            <div class="content-area" data-aos="fade-left">
                <div class="section-title-hijra"><span id="current-section-title">Dashboard</span> <button class="btn-translate-toggle" id="lang-toggle-btn" onclick="toggleLanguageManual()" style="display: block;">اردو میں دیکھیں</button></div>

                <!-- ENGLISH CONTENT -->
                <div id="english-content">
                    <div id="dashboard" class="content-section bio-text active">
                        <h3>Personal Information:</h3><p><?php echo $current_data['en']['personal']; ?></p>
                        <h3>Education:</h3><p><?php echo $current_data['en']['education']; ?></p>
                        <h3>Educational and Religious Positions:</h3><ul><?php foreach($current_data['en']['positions'] as $p) echo "<li>$p</li>"; ?></ul>
                        <h3>Teaching and Religious Services:</h3><p><?php echo $current_data['en']['services']; ?></p>
                        <h3>Specialties:</h3><ul><?php foreach($current_data['en']['specialties'] as $s) echo "<li>$s</li>"; ?></ul>
                        <h3>Publications:</h3><ul><?php foreach($current_data['en']['publications'] as $pub) echo "<li>$pub</li>"; ?></ul>
                        <h3>Translations:</h3><ul><?php foreach($current_data['en']['translations'] as $tr) echo "<li>$tr</li>"; ?></ul>
                    </div>
                    <div id="info" class="content-section bio-text"><h3>Personal Information:</h3><p><?php echo $current_data['en']['personal']; ?></p></div>
                    <div id="education" class="content-section bio-text"><h3>Education:</h3><p><?php echo $current_data['en']['education']; ?></p></div>
                    <div id="positions" class="content-section bio-text"><h3>Religious Positions:</h3><ul><?php foreach($current_data['en']['positions'] as $p) echo "<li>$p</li>"; ?></ul></div>
                    <div id="services" class="content-section bio-text"><h3>Teaching Services:</h3><p><?php echo $current_data['en']['services']; ?></p></div>
                    <div id="specialties" class="content-section bio-text"><h3>Specialties:</h3><ul><?php foreach($current_data['en']['specialties'] as $s) echo "<li>$s</li>"; ?></ul></div>
                    <div id="publications" class="content-section bio-text"><h3>Publications:</h3><ul><?php foreach($current_data['en']['publications'] as $pub) echo "<li>$pub</li>"; ?></ul><h3>Translations:</h3><ul><?php foreach($current_data['en']['translations'] as $tr) echo "<li>$tr</li>"; ?></ul></div>
                </div>

                <!-- URDU CONTENT (Only for Dashboard) -->
                <div id="urdu-content" class="content-section urdu-text">
                    <h3>شخصی معلومات:</h3><p><?php echo $current_data['ur']['personal']; ?></p>
                    <h3>تعلیم:</h3><p><?php echo $current_data['ur']['education']; ?></p>
                    <h3>تعلیمی اور مذہبی عہدے:</h3><ul><?php foreach($current_data['ur']['positions'] as $p) echo "<li>$p</li>"; ?></ul>
                    <h3>تدریسی اور مذہبی خدمات:</h3><p><?php echo $current_data['ur']['services']; ?></p>
                    <h3>تخصص (مہارت):</h3><ul><?php foreach($current_data['ur']['specialties'] as $s) echo "<li>$s</li>"; ?></ul>
                    <h3>تصانیف:</h3><ul><?php foreach($current_data['ur']['publications'] as $pub) echo "<li>$pub</li>"; ?></ul>
                    <h3>ترجمہ:</h3><ul><?php foreach($current_data['ur']['translations'] as $tr) echo "<li>$tr</li>"; ?></ul>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let currentLang = 'english';
    function showSection(sectionId, element) {
        // Sidebar active class
        document.querySelectorAll('.sidebar-link').forEach(link => link.classList.remove('active'));
        element.classList.add('active');
        document.getElementById('current-section-title').innerText = element.innerText.trim();

        // Control Translate Button visibility
        const btn = document.getElementById('lang-toggle-btn');
        if (sectionId === 'dashboard') {
            btn.style.display = 'block';
        } else {
            btn.style.display = 'none';
            toggleLanguage('english'); // Force English for non-dashboard
        }

        // Section visibility (English container)
        document.querySelectorAll('#english-content .content-section').forEach(s => s.classList.remove('active'));
        const target = document.getElementById(sectionId);
        if (target) target.classList.add('active');

        window.scrollTo({ top: document.querySelector('.content-area').offsetTop - 120, behavior: 'smooth' });
    }

    function toggleLanguage(lang) {
        currentLang = lang;
        const engWrap = document.getElementById('english-content');
        const urdWrap = document.getElementById('urdu-content');
        const btn = document.getElementById('lang-toggle-btn');

        if (lang === 'urdu') {
            engWrap.style.display = 'none';
            urdWrap.style.display = 'block';
            urdWrap.classList.add('active');
            btn.innerText = 'View in English';
        } else {
            engWrap.style.display = 'block';
            urdWrap.style.display = 'none';
            urdWrap.classList.remove('active');
            btn.innerText = 'اردو میں دیکھیں';
        }
    }

    function toggleLanguageManual() { toggleLanguage(currentLang === 'english' ? 'urdu' : 'english'); }
</script>
<?php include 'includes/footer.php'; ?>
