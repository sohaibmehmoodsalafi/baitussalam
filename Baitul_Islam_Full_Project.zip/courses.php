<?php
require 'includes/db.php';
session_start();

// Fetch Approved Courses with Tutor Info
$stmt = $pdo->query("SELECT courses.*, tutors.name as tutor_name, tutors.image as tutor_image FROM courses JOIN tutors ON courses.tutor_id = tutors.id WHERE courses.status = 'approved' ORDER BY courses.created_at DESC");
$courses = $stmt->fetchAll();

include 'includes/header.php';
?>

<!-- Course Page Banner (Premium Style) -->
<section class="page-banner-premium">
    <div class="container">
        <div class="page-header-divider"></div>
        <h1 class="section-title">All Courses</h1>
        <nav>
            <ol class="breadcrumb-hijra">
                <li><a href="index.php">Baitul Islam</a></li>
                <li style="opacity: 0.5;">/</li>
                <li>Courses</li>
            </ol>
        </nav>
    </div>
</section>

<!-- Course List Section -->
<section style="background: #f8f9fa; padding: 60px 0;">
    <div class="container">
        <!-- Top Toolbar -->
        <div style="display: flex; justify-content: space-between; align-items: center; background: white; padding: 15px 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); margin-bottom: 40px; flex-wrap: wrap; gap: 20px;" class="courses-toolbar">
            <div style="display: flex; align-items: center; gap: 15px;">
                <span style="font-weight: 700; color: #444;">Showing <?php echo count($courses); ?> courses</span>
            </div>
            <div style="display: flex; gap: 10px; width: 100%; max-width: 350px;">
               <input type="text" id="courseSearch" placeholder="Search courses..." style="padding: 10px 20px; border: 1px solid #ddd; border-radius: 50px; font-size: 0.9rem; width: 100%; outline: none;" class="w-100">
            </div>
        </div>

        <div class="row g-4" id="coursesGrid">
            <?php foreach($courses as $course): 
                $tutor_image = $course['tutor_image'] ?? 'assets/images/default_avatar.png';
                if(stripos($course['tutor_name'], 'Abdullah Nasir Rehmani') !== false) {
                    $tutor_image = 'assets/images/sheikh_abdullah.png';
                }
            ?>
                <div class="col-lg-4 col-md-6 course-item" data-title="<?php echo strtolower($course['title']); ?>">
                    <div class="course-card-hijra-alt">
                        <div class="course-img-box-alt">
                            <img src="<?php echo htmlspecialchars($course['banner_image'] ?? 'assets/images/default_course.jpg'); ?>" class="main-img" alt="Course Image">
                            <div class="tutor-avatar-overlay">
                                <img src="<?php echo htmlspecialchars($tutor_image); ?>" alt="Tutor">
                            </div>
                            <div class="course-badge-alt">Free</div>
                        </div>
                        <div class="course-content-alt">
                            <h3 class="course-title-alt"><a href="javascript:void(0)"><?php echo htmlspecialchars($course['title']); ?></a></h3>
                            <p class="course-excerpt-alt"><?php echo htmlspecialchars(substr($course['description'], 0, 100)) . '...'; ?></p>
                            <div class="course-meta-alt">
                                <span><i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($course['tutor_name']); ?></span>
                            </div>
                            <div style="padding-top: 15px; border-top: 1px solid #eee; margin-top: 15px;">
                                <a href="javascript:void(0)" class="view-details-btn">View Details <i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<style>
    .course-card-hijra-alt {
        background: white;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        transition: all 0.3s ease;
        height: 100%;
        display: flex;
        flex-direction: column;
        border: 1px solid #eee;
    }
    .course-card-hijra-alt:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.1);
    }
    .course-img-box-alt {
        position: relative;
        height: 200px;
        width: 100%;
        overflow: hidden;
    }
    .course-img-box-alt .main-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: 0.5s;
    }
    .course-card-hijra-alt:hover .main-img {
        transform: scale(1.1);
    }
    .tutor-avatar-overlay {
        position: absolute;
        bottom: -20px;
        left: 20px;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        border: 3px solid white;
        overflow: hidden;
        background: #eee;
        z-index: 10;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .tutor-avatar-overlay img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .course-badge-alt {
        position: absolute;
        top: 15px;
        right: 15px;
        background: #4CAF50;
        color: white;
        padding: 4px 12px;
        border-radius: 4px;
        font-size: 0.8rem;
        font-weight: 700;
    }
    .course-content-alt {
        padding: 35px 20px 20px;
        flex-grow: 1;
    }
    .course-title-alt {
        font-size: 1.25rem;
        font-weight: 800;
        margin-bottom: 12px;
        color: var(--primary);
    }
    .course-title-alt a {
        color: inherit;
        text-decoration: none;
    }
    .course-title-alt a:hover {
        color: var(--accent);
    }
    .course-excerpt-alt {
        font-size: 0.9rem;
        color: #666;
        line-height: 1.6;
        margin-bottom: 15px;
    }
    .course-meta-alt {
        color: #888;
        font-size: 0.85rem;
        display: flex;
        align-items: center;
        gap: 15px;
    }
    .course-meta-alt i {
        color: var(--accent);
    }
    .view-details-btn {
        display: block;
        text-align: center;
        color: var(--primary);
        font-weight: 700;
        text-decoration: none;
        font-size: 0.9rem;
        transition: 0.3s;
    }
    .view-details-btn:hover {
        color: var(--accent);
        transform: translateX(5px);
    }
</style>

<script>
    document.getElementById('courseSearch').addEventListener('input', function(e) {
        const query = e.target.value.toLowerCase();
        const items = document.querySelectorAll('.course-item');
        
        items.forEach(item => {
            const title = item.getAttribute('data-title');
            if (title.includes(query)) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    });
</script>

<?php include 'includes/footer.php'; ?>
