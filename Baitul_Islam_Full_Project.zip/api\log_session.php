<?php
header('Content-Type: application/json');
require '../includes/db.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'tutor') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$action = $_POST['action'] ?? '';
$course_id = $_POST['course_id'] ?? 0;
$session_id = $_POST['session_id'] ?? 0;

if ($action == 'start') {
    try {
        $stmt = $pdo->prepare("INSERT INTO class_sessions (tutor_id, course_id, start_time, status) VALUES (?, ?, NOW(), 'active')");
        $stmt->execute([$user_id, $course_id]);
        echo json_encode(['success' => true, 'session_id' => $pdo->lastInsertId()]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} elseif ($action == 'end' && $session_id > 0) {
    try {
        // Calculate duration
        $stmt = $pdo->prepare("SELECT start_time FROM class_sessions WHERE id = ? AND tutor_id = ?");
        $stmt->execute([$session_id, $user_id]);
        $session = $stmt->fetch();
        
        if ($session) {
            $start = new DateTime($session['start_time']);
            $end = new DateTime();
            $interval = $start->diff($end);
            $minutes = ($interval->days * 24 * 60) + ($interval->h * 60) + $interval->i;
            
            $stmt = $pdo->prepare("UPDATE class_sessions SET end_time = NOW(), duration_minutes = ?, status = 'completed' WHERE id = ?");
            $stmt->execute([$minutes, $session_id]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Session not found']);
        }
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>
