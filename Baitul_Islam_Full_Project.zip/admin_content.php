<?php
session_start();
require 'includes/db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Handle Add/Delete FAQ
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_faq'])) {
        $q = $_POST['question'];
        $a = $_POST['answer'];
        $stmt = $pdo->prepare("INSERT INTO faqs (question, answer) VALUES (?, ?)");
        $stmt->execute([$q, $a]);
        $msg = "FAQ added successfully!";
    } elseif (isset($_POST['delete_id'])) {
        $stmt = $pdo->prepare("DELETE FROM faqs WHERE id = ?");
        $stmt->execute([$_POST['delete_id']]);
        $msg = "FAQ deleted.";
    }
}

$faqs = $pdo->query("SELECT * FROM faqs ORDER BY created_at DESC")->fetchAll();

include 'includes/admin_header_layout.php';
?>

<div class="d-flex" id="wrapper">
    <?php include 'includes/admin_sidebar.php'; ?>

    <div id="page-content-wrapper">
        <!-- Top Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 px-4 mb-4 border-bottom shadow-sm">
            <div class="container-fluid">
                <div class="d-flex align-items-center">
                    <button class="btn btn-light d-lg-none me-3" id="menu-toggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h4 class="fw-bold mb-0 text-dark">Content Management</h4>
                </div>
                
                <div class="user-profile">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=0F5132&color=fff" class="avatar">
                    <div class="user-info d-none d-sm-flex ms-2">
                        <span class="name">Administrator</span>
                        <span class="role text-muted small">Super Admin</span>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid px-4">
            <?php if(isset($msg)): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4 shadow-sm border-0 mb-4" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $msg; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="row g-4 mb-5">
                <!-- Add New FAQ -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4 position-sticky" style="top: 20px;">
                        <div class="card-header bg-white py-3 fw-bold border-bottom">
                            <h6 class="mb-0 fw-bold"><i class="fas fa-plus-circle me-2 text-primary"></i> Add New FAQ</h6>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label text-muted small fw-bold">Question</label>
                                    <input type="text" name="question" class="form-control rounded-3 border-light-subtle" required placeholder="e.g. How do I apply?">
                                </div>
                                <div class="mb-4">
                                    <label class="form-label text-muted small fw-bold">Answer</label>
                                    <textarea name="answer" class="form-control rounded-3 border-light-subtle" rows="5" required placeholder="Enter the answer clarity..."></textarea>
                                </div>
                                <div class="d-grid">
                                    <button type="submit" name="add_faq" class="btn btn-primary rounded-pill py-2 shadow-sm">
                                        <i class="fas fa-plus me-2"></i> Add FAQ
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Existing FAQs -->
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                        <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                            <h6 class="mb-0 fw-bold"><i class="fas fa-list-ul me-2 text-primary"></i> Frequently Asked Questions</h6>
                            <span class="badge bg-light text-muted border fw-normal px-3"><?php echo count($faqs); ?> Total</span>
                        </div>
                        <div class="card-body p-0">
                            <div class="list-group list-group-flush">
                                <?php foreach($faqs as $f): ?>
                                <div class="list-group-item p-4 transition-all">
                                    <div class="d-flex justify-content-between align-items-start gap-3">
                                        <div class="flex-grow-1">
                                            <h6 class="fw-bold mb-2 text-dark d-flex align-items-center">
                                                <i class="far fa-question-circle text-primary me-2"></i>
                                                <?php echo htmlspecialchars($f['question']); ?>
                                            </h6>
                                            <div class="text-muted small lh-lg bg-light p-3 rounded-3">
                                                <?php echo nl2br(htmlspecialchars($f['answer'])); ?>
                                            </div>
                                        </div>
                                        <form method="POST" onsubmit="return confirm('Are you sure you want to delete this FAQ?');">
                                            <input type="hidden" name="delete_id" value="<?php echo $f['id']; ?>">
                                            <button type="submit" class="btn btn-outline-danger btn-sm rounded-circle shadow-sm" style="width: 32px; height: 32px; display: flex; align-items: center; justify-content: center;">
                                                <i class="fas fa-trash-alt fa-xs"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                                <?php if(empty($faqs)): ?>
                                    <div class="p-5 text-center text-muted">
                                        <i class="fas fa-comment-slash fa-3x mb-3 opacity-25"></i>
                                        <p class="mb-0">No FAQs found. Use the form to add some content.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    body { background-color: #f8fafc; font-family: 'Outfit', sans-serif; }
    #page-content-wrapper {
        flex-grow: 1;
        min-width: 0;
        transition: 0.3s;
        min-height: 100vh;
    }
    .user-profile {
        display: flex; align-items: center; background: #fff; padding: 6px 12px;
        border-radius: 12px; border: 1px solid #f1f5f9;
        cursor: pointer;
    }
    .avatar { width: 32px; height: 32px; border-radius: 8px; }
    
    .form-control { font-size: 0.9rem; }
    .transition-all { transition: all 0.3s ease; }
    .list-group-item:hover { background-color: #fdfdfd; }

    @media (max-width: 992px) {
        #page-content-wrapper { margin-left: 0; width: 100%; }
        #sidebar-wrapper { margin-left: -280px; position: fixed; height: 100vh; z-index: 1050; }
        #wrapper.toggled #sidebar-wrapper { margin-left: 0; }
    }
</style>

<script>
// Sidebar Toggle
document.getElementById("menu-toggle")?.addEventListener("click", function(e) {
    e.preventDefault();
    document.getElementById("wrapper").classList.toggle("toggled");
});
</script>

<?php include 'includes/admin_footer.php'; ?>
