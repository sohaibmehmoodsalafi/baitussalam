    <!-- Core Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
        
        // Mobile Toggle Logic
        const toggleBtn = document.getElementById("menu-toggle");
        const wrapper = document.getElementById("wrapper");
        if(toggleBtn){
            toggleBtn.onclick = function () {
                wrapper.classList.toggle("toggled");
            };
        }
    </script>
</body>
</html>
