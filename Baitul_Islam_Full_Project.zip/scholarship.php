<?php
require 'includes/db.php';
session_start();
include 'includes/header.php';
?>

<!-- Scholarship Page Banner -->
<section style="background: var(--primary); padding: 50px 0; position: relative;">
    <div class="container text-center">
        <h1 style="color: white; font-family: 'Outfit', sans-serif; font-size: 2.5rem; font-weight: 800; margin: 0;">Scholarship Form</h1>
    </div>
</section>

<!-- Main Content Section -->
<section style="background: #ffffff; padding: 60px 0;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-9 col-md-10"> <!-- Adjusted width to match reference better -->
                
                <?php if (isset($_GET['status'])): ?>
                    <?php if ($_GET['status'] == 'success'): ?>
                        <div class="alert alert-success mt-3" style="border-radius: 8px;">
                            Application Submitted Successfully!
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <form action="submit_scholarship.php" method="POST" class="needs-validation scholarship-form-hijra" novalidate>
                    
                    <div class="mb-4">
                        <label class="form-label">First Name: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="first_name" required>
                        <div class="invalid-feedback">This field is required.</div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Last Name: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="last_name" required>
                        <div class="invalid-feedback">This field is required.</div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Phone: <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="phone" placeholder="0301 2345678" required>
                        <div class="invalid-feedback">This field is required.</div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Email: <span class="text-danger">*</span></label>
                        <input type="email" class="form-control" name="email" required>
                        <div class="invalid-feedback">This field is required.</div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Country Name: <span class="text-danger">*</span></label>
                        <select class="form-select" name="country" required>
                            <option value="">Select your country</option>
                            <option value="Pakistan">Pakistan</option>
                            <option value="USA">USA</option>
                            <option value="UK">UK</option>
                            <option value="Canada">Canada</option>
                        </select>
                        <div class="invalid-feedback">This field is required.</div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Discount: <span class="text-danger">*</span></label>
                        <select class="form-select" name="discount_level" required>
                            <option value="30%">30%</option>
                            <option value="50%">50%</option>
                            <option value="Full">Full Scholarship</option>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Statement of Purpose for Scholarship: <span class="text-danger">*</span></label>
                        <textarea class="form-control" name="statement_of_purpose" rows="5" required></textarea>
                        <div class="invalid-feedback">This field is required.</div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label d-block">Terms & Conditions <span class="text-danger">*</span></label>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="termsCheck" required>
                            <label class="form-check-label" for="termsCheck">
                                I accept the Terms and Conditions.
                            </label>
                            <div class="invalid-feedback">This field is required.</div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary w-100 py-3 mt-3" style="background: var(--primary); border: none; font-weight: 700; font-size: 1.1rem; border-radius: 5px;">Submit Application</button>

                </form>

                <!-- Terms & Conditions at the bottom -->
                <div class="mt-5 pt-4 border-top">
                    <h5 style="font-weight: 700; color: #333; margin-bottom: 20px;">Terms & Conditions</h5>
                    <ul style="list-style: none; padding: 0; color: #666; font-size: 0.95rem; line-height: 1.7;">
                        <li class="mb-3">
                            <i class="fas fa-info-circle me-2" style="color: var(--primary);"></i>
                            If your application is accepted, you will receive an email with a coupon code, which you must use within 5 days. You can then apply the code on the payment form for the discounted rate.
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-info-circle me-2" style="color: var(--primary);"></i>
                            If you do not log in within 3 days after joining the course, your scholarship will be cancelled.
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-info-circle me-2" style="color: var(--primary);"></i>
                            Your scholarship may be withdrawn or cancelled if you fail to complete your offered course within the designated time.
                        </li>
                        <li class="mb-3">
                            <i class="fas fa-info-circle me-2" style="color: var(--primary);"></i>
                            All scholarships will be at the discretion of the Scholarship Committee.
                        </li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
</section>

<style>
    .scholarship-form-hijra .form-label {
        font-weight: 600;
        color: #333;
        font-size: 1rem;
        margin-bottom: 8px;
    }
    .scholarship-form-hijra .form-control, 
    .scholarship-form-hijra .form-select {
        border: 1px solid #ced4da;
        border-radius: 4px;
        padding: 12px;
        font-size: 0.95rem;
    }
    .scholarship-form-hijra .form-control:focus, 
    .scholarship-form-hijra .form-select:focus {
        border-color: #80bdff;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }
    .invalid-feedback {
        font-size: 0.85rem;
        color: #dc3545;
        margin-top: 5px;
    }
</style>

<script>
// Bootstrap validation script
(function () {
  'use strict'
  var forms = document.querySelectorAll('.needs-validation')
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }
        form.classList.add('was-validated')
      }, false)
    })
})()
</script>

<?php include 'includes/footer.php'; ?>
