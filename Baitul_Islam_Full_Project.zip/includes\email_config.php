<?php
// Email Configuration for Gmail SMTP
// IMPORTANT: Replace these with your actual Gmail credentials

define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'muhammadsaadmrsaad3815@gmail.com'); // Updated Gmail
define('SMTP_PASSWORD', 'oovfnndhivpdirrz');                 // App Password (spaces removed)
define('SMTP_FROM_EMAIL', 'muhammadsaadmrsaad3815@gmail.com');
define('SMTP_FROM_NAME', 'Baitul Islam');

// Organization Info
define('ORG_NAME', 'Baitul Islam');
define('ORG_EMAIL', 'info@peace.org.pk');
define('ORG_PHONE', '+92 300 1234567');
define('ORG_ADDRESS', 'Islamabad, Pakistan');
define('ORG_WEBSITE', 'www.baitulislam.org');

/*
 * HOW TO GET GMAIL APP PASSWORD:
 * 1. Go to your Google Account settings
 * 2. Security > 2-Step Verification (enable it)
 * 3. App passwords > Select app: Mail > Select device: Other
 * 4. Copy the 16-character password
 * 5. Paste it in SMTP_PASSWORD above
 */
?>
