<?php
require 'includes/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = htmlspecialchars($_POST['first_name'] ?? '');
    $last_name = htmlspecialchars($_POST['last_name'] ?? '');
    $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
    $phone = htmlspecialchars($_POST['phone'] ?? '');
    $country = htmlspecialchars($_POST['country'] ?? '');
    $discount_level = htmlspecialchars($_POST['discount_level'] ?? '');
    $statement_of_purpose = htmlspecialchars($_POST['statement_of_purpose'] ?? '');

    if (!$email || !$first_name || !$last_name) {
        header("Location: scholarship.php?status=error&msg=Invalid+Input");
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO scholarship_applications (first_name, last_name, email, phone, country, discount_level, statement_of_purpose) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$first_name, $last_name, $email, $phone, $country, $discount_level, $statement_of_purpose]);

        header("Location: scholarship.php?status=success");
        exit;

    } catch (PDOException $e) {
        header("Location: scholarship.php?status=error");
        exit;
    }
} else {
    header("Location: scholarship.php");
    exit;
}
