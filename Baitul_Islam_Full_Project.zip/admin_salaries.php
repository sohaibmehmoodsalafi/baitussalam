<?php
session_start();
require 'includes/db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Fetch all tutors with their total hours for the selected/current month
$month = $_GET['month'] ?? date('m');
$year = $_GET['year'] ?? date('Y');

$stmt = $pdo->prepare("
    SELECT t.id, t.name, t.email, t.price_hourly,
    (SELECT SUM(duration_minutes) FROM class_sessions WHERE tutor_id = t.id AND MONTH(start_time) = ? AND YEAR(start_time) = ?) as total_minutes
    FROM tutors t
    WHERE t.is_active = 1
");
$stmt->execute([$month, $year]);
$tutors_data = $stmt->fetchAll();

// Handle Salary Generation
if (isset($_POST['generate_salary'])) {
    $tutor_id = $_POST['tutor_id'];
    $hours = $_POST['hours'];
    $rate = $_POST['rate'];
    $total = $hours * $rate;
    
    // Check if slip already exists
    $chk = $pdo->prepare("SELECT id FROM salary_slips WHERE tutor_id = ? AND month = ? AND year = ?");
    $chk->execute([$tutor_id, $month, $year]);
    
    if (!$chk->fetch()) {
        try {
            $ins = $pdo->prepare("INSERT INTO salary_slips (tutor_id, month, year, total_hours, hourly_rate, total_salary, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
            $ins->execute([$tutor_id, $month, $year, $hours, $rate, $total]);
            $success_msg = "Salary slip generated for this month.";
        } catch (PDOException $e) {
            $error_msg = "Error: " . $e->getMessage();
        }
    } else {
        $error_msg = "Salary slip already exists for this month.";
    }
}

// Fetch existing slips for selected month
$slips_stmt = $pdo->prepare("
    SELECT ss.*, t.name as tutor_name 
    FROM salary_slips ss 
    JOIN tutors t ON ss.tutor_id = t.id 
    WHERE ss.month = ? AND ss.year = ?
");
$slips_stmt->execute([$month, $year]);
$existing_slips = $slips_stmt->fetchAll();

include 'includes/admin_header_layout.php';
?>

<div class="d-flex" id="wrapper">
    <?php include 'includes/admin_sidebar.php'; ?> 

    <div id="page-content-wrapper">
        <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 px-4 mb-4 border-bottom shadow-sm">
            <div class="container-fluid">
                <h4 class="fw-bold mb-0 text-dark">Teacher Payroll & Slips</h4>
                <div class="user-profile">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=0F5132&color=fff" class="avatar">
                    <div class="user-info d-none d-sm-flex ms-2">
                        <span class="name">Administrator</span>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid px-4">
            
            <!-- Filters -->
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-body py-3">
                    <form method="GET" class="row align-items-center g-3">
                        <div class="col-md-3">
                            <label class="small fw-bold text-muted mb-1">Select Month</label>
                            <select name="month" class="form-select rounded-pill">
                                <?php for($m=1; $m<=12; $m++): ?>
                                    <option value="<?php echo $m; ?>" <?php echo $month == $m ? 'selected' : ''; ?>><?php echo date('F', mktime(0,0,0,$m, 1)); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="small fw-bold text-muted mb-1">Select Year</label>
                            <select name="year" class="form-select rounded-pill">
                                <option value="2025" <?php echo $year == '2025' ? 'selected' : ''; ?>>2025</option>
                                <option value="2024" <?php echo $year == '2024' ? 'selected' : ''; ?>>2024</option>
                            </select>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary rounded-pill px-4 w-100">Filter Data</button>
                        </div>
                    </form>
                </div>
            </div>

            <?php if(isset($success_msg)): ?>
                <div class="alert alert-success rounded-4 border-0 shadow-sm mb-4"><i class="fas fa-check-circle me-2"></i> <?php echo $success_msg; ?></div>
            <?php endif; ?>
            <?php if(isset($error_msg)): ?>
                <div class="alert alert-danger rounded-4 border-0 shadow-sm mb-4"><i class="fas fa-exclamation-circle me-2"></i> <?php echo $error_msg; ?></div>
            <?php endif; ?>

            <div class="row">
                <!-- Salary Calculation Table -->
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4">
                        <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                            <h5 class="mb-0 fw-bold text-dark"><i class="fas fa-calculator me-2 text-primary"></i> Monthly Earning Tracker</h5>
                            <span class="badge bg-primary-subtle text-primary rounded-pill px-3 py-2" style="background: #ecfdf5 !important; color: #0F5132 !important; font-weight: 700;">
                                <?php echo date('F Y', mktime(0,0,0, $month, 1, $year)); ?>
                            </span>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead style="background: #f8fafc;">
                                        <tr>
                                            <th class="ps-4 py-3" style="font-size: 0.75rem; text-transform: uppercase; color: #64748b; font-weight: 800;">Instructor</th>
                                            <th class="py-3" style="font-size: 0.75rem; text-transform: uppercase; color: #64748b; font-weight: 800;">Base Rate</th>
                                            <th class="py-3" style="font-size: 0.75rem; text-transform: uppercase; color: #64748b; font-weight: 800;">Total Time</th>
                                            <th class="py-3" style="font-size: 0.75rem; text-transform: uppercase; color: #64748b; font-weight: 800;">Payout</th>
                                            <th class="text-end pe-4 py-3" style="font-size: 0.75rem; text-transform: uppercase; color: #64748b; font-weight: 800;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($tutors_data as $tr): 
                                            $mins = $tr['total_minutes'] ?? 0;
                                            $hrs = round($mins / 60, 2);
                                            $amt = $hrs * $tr['price_hourly'];
                                        ?>
                                        <tr>
                                            <td class="ps-4">
                                                <div class="d-flex align-items-center py-2">
                                                    <div class="avatar-sm bg-success text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 38px; height: 38px; font-weight: 800; font-size: 0.8rem;">
                                                        <?php echo strtoupper(substr($tr['name'], 0, 1)); ?>
                                                    </div>
                                                    <div>
                                                        <div class="fw-bold text-dark"><?php echo htmlspecialchars($tr['name']); ?></div>
                                                        <div class="small text-muted"><?php echo htmlspecialchars($tr['email']); ?></div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><span class="fw-bold text-primary">$<?php echo number_format($tr['price_hourly'], 2); ?></span><small class="text-muted">/hr</small></td>
                                            <td>
                                                <div class="d-flex flex-column">
                                                    <span class="fw-bold text-dark"><?php echo $hrs; ?> hrs</span>
                                                    <small class="text-muted"><?php echo $mins; ?> mins tracked</small>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="p-2 px-3 rounded-pill d-inline-block" style="background: #f0fdf4; border: 1px solid #bbf7d0;">
                                                    <span class="fw-black text-success" style="font-size: 1.05rem;">$<?php echo number_format($amt, 2); ?></span>
                                                </div>
                                            </td>
                                            <td class="text-end pe-4">
                                                <form method="POST">
                                                    <input type="hidden" name="tutor_id" value="<?php echo $tr['id']; ?>">
                                                    <input type="hidden" name="hours" value="<?php echo $hrs; ?>">
                                                    <input type="hidden" name="rate" value="<?php echo $tr['price_hourly']; ?>">
                                                    <button type="submit" name="generate_salary" class="btn btn-primary rounded-pill px-4 shadow-sm" style="font-size: 0.85rem; font-weight: 700;">
                                                        <i class="fas fa-plus-circle me-1"></i> Issue Slip
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Slips Summary / Recent -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                        <div class="card-header bg-white py-3 d-flex justify-content-between">
                            <h5 class="mb-0 fw-bold"><i class="fas fa-file-invoice-dollar me-2 text-success"></i> Monthly Slips</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="list-group list-group-flush">
                                <?php if(empty($existing_slips)): ?>
                                    <div class="p-5 text-center text-muted">No slips generated for this month.</div>
                                <?php else: ?>
                                    <?php foreach($existing_slips as $slip): ?>
                                    <div class="list-group-item p-3 border-0 border-bottom">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="fw-bold text-dark"><?php echo htmlspecialchars($slip['tutor_name']); ?></span>
                                            <span class="badge bg-success-subtle text-success rounded-pill px-3"><?php echo ucfirst($slip['status']); ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between small text-muted">
                                            <span><?php echo $slip['total_hours']; ?> hrs @ $<?php echo $slip['hourly_rate']; ?></span>
                                            <span class="fw-black text-dark">$<?php echo number_format($slip['total_salary'], 2); ?></span>
                                        </div>
                                        <div class="mt-2 text-end">
                                            <a href="salary_slip_view.php?id=<?php echo $slip['id']; ?>" class="btn btn-link btn-sm text-decoration-none p-0"><i class="fas fa-download me-1"></i> View Slip</a>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<style>
    body { background-color: #f8fafc; font-family: 'Outfit', sans-serif; }
    .btn-primary { background-color: #0F5132; border-color: #0F5132; }
    .btn-primary:hover { background-color: #0c4229; border-color: #0c4229; }
    .text-primary { color: #0F5132 !important; }
    .table thead th { font-size: 0.8rem; text-transform: uppercase; color: #64748b; padding: 1.25rem 0.75rem; }
</style>

<?php include 'includes/admin_footer.php'; ?>
