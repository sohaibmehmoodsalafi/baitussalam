<?php
include 'includes/header.php';
require 'includes/db.php';

// Auth Check - Only students can complain
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_complaint'])) {
    $student_id = $_SESSION['user_id'];
    $tutor_id = !empty($_POST['tutor_id']) ? $_POST['tutor_id'] : null;
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);

    if (empty($subject) || empty($message)) {
        $error = "Please fill in all required fields.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO complaints (student_id, tutor_id, subject, message) VALUES (?, ?, ?, ?)");
            $stmt->execute([$student_id, $tutor_id, $subject, $message]);
            $success = "Your complaint has been submitted successfully. Our team will review it shortly.";
        } catch (PDOException $e) {
            $error = "Something went wrong. Please try again.";
        }
    }
}

// Fetch tutors the student has enrolled with (optional but helpful)
$tutors = [];
try {
    $stmt = $pdo->prepare("SELECT DISTINCT t.id, t.name FROM tutors t JOIN courses c ON t.id = c.tutor_id JOIN enrollments e ON c.id = e.course_id WHERE e.student_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $tutors = $stmt->fetchAll();
} catch (Exception $e) {}

?>

<div class="container" style="padding: 120px 0;">
    <div style="max-width: 700px; margin: 0 auto; background: white; padding: 50px; border-radius: 20px; box-shadow: 0 20px 50px rgba(0,0,0,0.05); border: 1px solid #eef2f3;">
        <div style="text-align: center; margin-bottom: 40px;">
            <div style="width: 70px; height: 70px; background: #fff5f5; color: #e53e3e; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 2rem;">
                <i class="fas fa-exclamation-circle"></i>
            </div>
            <h1 style="color: var(--primary-dark); font-weight: 800; font-size: 2rem;">Help & Support</h1>
            <p style="color: var(--text-muted);">Have a complaint or need assistance? Let us know.</p>
        </div>

        <?php if($success): ?>
            <div style="background: #dcfce7; color: #166534; padding: 20px; border-radius: 12px; margin-bottom: 30px; border: 1px solid #bbf7d0; display: flex; align-items: center; gap: 15px;">
                <i class="fas fa-check-circle"></i> <?php echo $success; ?>
            </div>
        <?php endif; ?>

        <?php if($error): ?>
            <div style="background: #fee2e2; color: #991b1b; padding: 20px; border-radius: 12px; margin-bottom: 30px; border: 1px solid #fecaca; display: flex; align-items: center; gap: 15px;">
                <i class="fas fa-times-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <div style="margin-bottom: 25px;">
                <label style="display: block; font-weight: 700; color: var(--primary-dark); margin-bottom: 10px; font-size: 0.9rem; text-transform: uppercase;">Subject <span style="color: red;">*</span></label>
                <input type="text" name="subject" class="form-control" placeholder="What is the issue about?" required style="width: 100%; padding: 15px; border: 2px solid #f1f5f9; border-radius: 12px; font-size: 1rem; transition: 0.3s; background: #f8fafc;">
            </div>

            <div style="margin-bottom: 25px;">
                <label style="display: block; font-weight: 700; color: var(--primary-dark); margin-bottom: 10px; font-size: 0.9rem; text-transform: uppercase;">Related Tutor (Optional)</label>
                <select name="tutor_id" style="width: 100%; padding: 15px; border: 2px solid #f1f5f9; border-radius: 12px; font-size: 1rem; background: #f8fafc;">
                    <option value="">Select Tutor (if applicable)</option>
                    <?php foreach($tutors as $t): ?>
                        <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="margin-bottom: 30px;">
                <label style="display: block; font-weight: 700; color: var(--primary-dark); margin-bottom: 10px; font-size: 0.9rem; text-transform: uppercase;">Your Message <span style="color: red;">*</span></label>
                <textarea name="message" rows="6" placeholder="Describe your complaint in detail..." required style="width: 100%; padding: 15px; border: 2px solid #f1f5f9; border-radius: 12px; font-size: 1rem; transition: 0.3s; background: #f8fafc; resize: none;"></textarea>
            </div>

            <button type="submit" name="submit_complaint" class="btn btn-primary" style="width: 100%; padding: 18px; font-size: 1.1rem; border-radius: 12px; font-weight: 800; box-shadow: 0 10px 30px rgba(15, 81, 50, 0.2); background: #e53e3e; border: none; color: white; cursor: pointer;">
                Submit Complaint
            </button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
