<?php
/**
 * Session Security & Privacy Helper
 * Prevents unauthorized access and session hijacking
 */

class SessionSecurity {
    
    /**
     * Start secure session with proper configuration
     */
    public static function startSecureSession() {
        if (session_status() === PHP_SESSION_NONE) {
            // Secure session configuration
            ini_set('session.cookie_httponly', 1);
            ini_set('session.use_only_cookies', 1);
            ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
            ini_set('session.cookie_samesite', 'Lax');
            
            session_start();
            
            // Regenerate session ID to prevent fixation
            if (!isset($_SESSION['initiated'])) {
                session_regenerate_id(true);
                $_SESSION['initiated'] = true;
                $_SESSION['user_ip'] = $_SERVER['REMOTE_ADDR'] ?? '';
                $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
            }
            
            // Validate session
            self::validateSession();
        }
    }
    
    /**
     * Validate session to prevent hijacking
     */
    private static function validateSession() {
        // Check if IP address matches
        if (isset($_SESSION['user_ip'])) {
            $current_ip = $_SERVER['REMOTE_ADDR'] ?? '';
            if ($_SESSION['user_ip'] !== $current_ip) {
                self::destroySession();
                return false;
            }
        }
        
        // Check if user agent matches
        if (isset($_SESSION['user_agent'])) {
            $current_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
            if ($_SESSION['user_agent'] !== $current_agent) {
                self::destroySession();
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Check if user is logged in
     */
    public static function isLoggedIn() {
        return isset($_SESSION['user_id']) && isset($_SESSION['user_role']);
    }
    
    /**
     * Check if user has specific role
     */
    public static function hasRole($role) {
        return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
    }
    
    /**
     * Require login - redirect if not logged in
     */
    public static function requireLogin($redirect = 'login.php') {
        if (!self::isLoggedIn()) {
            header("Location: $redirect");
            exit;
        }
    }
    
    /**
     * Require specific role - redirect if not authorized
     */
    public static function requireRole($role, $redirect = 'index.php') {
        if (!self::hasRole($role)) {
            header("Location: $redirect");
            exit;
        }
    }
    
    /**
     * Prevent logged-in users from accessing login/register pages
     */
    public static function preventLoggedInAccess($redirect = null) {
        if (self::isLoggedIn()) {
            if ($redirect === null) {
                // Auto-redirect based on role
                $redirect = self::hasRole('student') ? 'student_dashboard.php' : 
                           (self::hasRole('tutor') ? 'tutor_dashboard.php' : 
                           (self::hasRole('admin') ? 'admin_panel.php' : 'index.php'));
            }
            header("Location: $redirect");
            exit;
        }
    }
    
    /**
     * Destroy session securely
     */
    public static function destroySession() {
        $_SESSION = array();
        
        if (isset($_COOKIE[session_name()])) {
            setcookie(session_name(), '', time() - 3600, '/');
        }
        
        session_destroy();
    }
    
    /**
     * Logout user
     */
    public static function logout($redirect = 'login.php') {
        self::destroySession();
        header("Location: $redirect");
        exit;
    }
    
    /**
     * Get current user ID
     */
    public static function getUserId() {
        return $_SESSION['user_id'] ?? null;
    }
    
    /**
     * Get current user role
     */
    public static function getUserRole() {
        return $_SESSION['user_role'] ?? null;
    }
    
    /**
     * Get current user name
     */
    public static function getUserName() {
        return $_SESSION['user_name'] ?? 'Guest';
    }
    
    /**
     * Prevent CSRF attacks - generate token
     */
    public static function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
    
    /**
     * Verify CSRF token
     */
    public static function verifyCSRFToken($token) {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * Sanitize input to prevent XSS
     */
    public static function sanitizeInput($data) {
        if (is_array($data)) {
            return array_map([self::class, 'sanitizeInput'], $data);
        }
        return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * Prevent SQL injection - use with PDO prepared statements
     */
    public static function validateInteger($value) {
        return filter_var($value, FILTER_VALIDATE_INT) !== false;
    }
    
    /**
     * Validate email
     */
    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    /**
     * Check if request is POST
     */
    public static function isPostRequest() {
        return $_SERVER['REQUEST_METHOD'] === 'POST';
    }
    
    /**
     * Prevent browser back button after logout
     */
    public static function preventCaching() {
        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
    }
    
    /**
     * Set secure headers
     */
    public static function setSecureHeaders() {
        header("X-Frame-Options: DENY");
        header("X-Content-Type-Options: nosniff");
        header("X-XSS-Protection: 1; mode=block");
        header("Referrer-Policy: strict-origin-when-cross-origin");
    }
}
?>
