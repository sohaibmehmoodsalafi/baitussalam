DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admins` (`id`, `username`, `password`, `created_at`) VALUES ('1', 'admin', '$2y$10$/nkkEjZXeUdFyEAWj9T4O.VrdsI0LY7auGb4oBB4ojSce2z7IqSg6', '2025-12-17 14:50:08');


DROP TABLE IF EXISTS `courses`;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tutor_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `schedule_days` varchar(255) DEFAULT NULL COMMENT 'e.g. Mon,Wed,Fri',
  `schedule_time` varchar(100) DEFAULT NULL COMMENT 'e.g. 10:00 AM - 11:00 AM',
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `banner_image` varchar(255) DEFAULT 'assets/images/default_course.jpg',
  `benefits` text DEFAULT NULL,
  `faqs` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tutor_id` (`tutor_id`),
  CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`tutor_id`) REFERENCES `tutors` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('2', '1', 'Advanced Tajweed Masterclass', 'A comprehensive course to master Quran recitation with proper Tajweed rules. Ideal for intermediate students.', '50.00', 'Mon,Wed', '10:00 AM - 12:00 PM', 'approved', '2025-12-17 15:35:54', 'assets/images/courses/tajweed.png', 'Perfect Recitation\nIjazah Preparation\nOne-on-One Attention', 'Q: Is this course for beginners?\nA: It is better suited for those who can already read Arabic.\n\nQ: Is there a certificate?\nA: Yes, upon completion.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('3', '1', 'Basic Arabic Grammar', 'Learn the fundamentals of Arabic grammar (Nahw and Sarf).', '40.00', 'Tue,Thu', '09:00 AM - 11:00 AM', 'approved', '2025-12-17 16:17:21', 'assets/images/courses/arabic.png', 'Understand Quranic Arabic\nDaily Usage Phrases\nGrammar Rules', 'Q: Is this Modern Standard Arabic?\nA: Yes, with a focus on Quranic understanding.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('4', '1', 'Hifz Program', 'Memorize the Holy Quran with expert Huffaz.', '60.00', 'Tue,Thu', '09:00 AM - 11:00 AM', 'approved', '2025-12-17 16:17:21', 'assets/images/courses/hifz.png', 'Structured Memorization\nRevision Techniques\nIjazah Opportunity', 'Q: How long does it take?\nA: It depends on individual pace.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('5', '1', 'Quran Reading for Beginners', 'Start your journey of reading the Quran from scratch (Qaida).', '30.00', 'Tue,Thu', '09:00 AM - 11:00 AM', 'approved', '2025-12-17 16:17:21', 'assets/images/courses/reading.png', 'Noorani Qaida\nMakharij Practice\nBasic Tajweed', 'Q: Is there an age limit?\nA: No, this course is for all ages.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('6', '2', 'Advanced Tajweed Masterclass', 'A comprehensive course to master Quran recitation with proper Tajweed rules. Ideal for intermediate students.', '50.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/tajweed.png', 'Perfect Recitation\nIjazah Preparation\nOne-on-One Attention', 'Q: Is this course for beginners?\nA: It is better suited for those who can already read Arabic.\n\nQ: Is there a certificate?\nA: Yes, upon completion.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('7', '6', 'Advanced Tajweed Masterclass', 'A comprehensive course to master Quran recitation with proper Tajweed rules. Ideal for intermediate students.', '50.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/tajweed.png', 'Perfect Recitation\nIjazah Preparation\nOne-on-One Attention', 'Q: Is this course for beginners?\nA: It is better suited for those who can already read Arabic.\n\nQ: Is there a certificate?\nA: Yes, upon completion.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('8', '7', 'Advanced Tajweed Masterclass', 'A comprehensive course to master Quran recitation with proper Tajweed rules. Ideal for intermediate students.', '50.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/tajweed.png', 'Perfect Recitation\nIjazah Preparation\nOne-on-One Attention', 'Q: Is this course for beginners?\nA: It is better suited for those who can already read Arabic.\n\nQ: Is there a certificate?\nA: Yes, upon completion.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('9', '8', 'Advanced Tajweed Masterclass', 'A comprehensive course to master Quran recitation with proper Tajweed rules. Ideal for intermediate students.', '50.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/tajweed.png', 'Perfect Recitation\nIjazah Preparation\nOne-on-One Attention', 'Q: Is this course for beginners?\nA: It is better suited for those who can already read Arabic.\n\nQ: Is there a certificate?\nA: Yes, upon completion.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('10', '2', 'Basic Arabic Grammar', 'Learn the fundamentals of Arabic grammar (Nahw and Sarf).', '40.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/arabic.png', 'Understand Quranic Arabic\nDaily Usage Phrases\nGrammar Rules', 'Q: Is this Modern Standard Arabic?\nA: Yes, with a focus on Quranic understanding.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('11', '6', 'Basic Arabic Grammar', 'Learn the fundamentals of Arabic grammar (Nahw and Sarf).', '40.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/arabic.png', 'Understand Quranic Arabic\nDaily Usage Phrases\nGrammar Rules', 'Q: Is this Modern Standard Arabic?\nA: Yes, with a focus on Quranic understanding.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('12', '7', 'Basic Arabic Grammar', 'Learn the fundamentals of Arabic grammar (Nahw and Sarf).', '40.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/arabic.png', 'Understand Quranic Arabic\nDaily Usage Phrases\nGrammar Rules', 'Q: Is this Modern Standard Arabic?\nA: Yes, with a focus on Quranic understanding.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('13', '8', 'Basic Arabic Grammar', 'Learn the fundamentals of Arabic grammar (Nahw and Sarf).', '40.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/arabic.png', 'Understand Quranic Arabic\nDaily Usage Phrases\nGrammar Rules', 'Q: Is this Modern Standard Arabic?\nA: Yes, with a focus on Quranic understanding.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('14', '2', 'Hifz Program', 'Memorize the Holy Quran with expert Huffaz.', '60.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/hifz.png', 'Structured Memorization\nRevision Techniques\nIjazah Opportunity', 'Q: How long does it take?\nA: It depends on individual pace.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('15', '6', 'Hifz Program', 'Memorize the Holy Quran with expert Huffaz.', '60.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/hifz.png', 'Structured Memorization\nRevision Techniques\nIjazah Opportunity', 'Q: How long does it take?\nA: It depends on individual pace.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('16', '7', 'Hifz Program', 'Memorize the Holy Quran with expert Huffaz.', '60.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/hifz.png', 'Structured Memorization\nRevision Techniques\nIjazah Opportunity', 'Q: How long does it take?\nA: It depends on individual pace.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('17', '8', 'Hifz Program', 'Memorize the Holy Quran with expert Huffaz.', '60.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/hifz.png', 'Structured Memorization\nRevision Techniques\nIjazah Opportunity', 'Q: How long does it take?\nA: It depends on individual pace.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('18', '2', 'Quran Reading for Beginners', 'Start your journey of reading the Quran from scratch (Qaida).', '30.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/reading.png', 'Noorani Qaida\nMakharij Practice\nBasic Tajweed', 'Q: Is there an age limit?\nA: No, this course is for all ages.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('19', '6', 'Quran Reading for Beginners', 'Start your journey of reading the Quran from scratch (Qaida).', '30.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/reading.png', 'Noorani Qaida\nMakharij Practice\nBasic Tajweed', 'Q: Is there an age limit?\nA: No, this course is for all ages.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('20', '7', 'Quran Reading for Beginners', 'Start your journey of reading the Quran from scratch (Qaida).', '30.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/reading.png', 'Noorani Qaida\nMakharij Practice\nBasic Tajweed', 'Q: Is there an age limit?\nA: No, this course is for all ages.');
INSERT INTO `courses` (`id`, `tutor_id`, `title`, `description`, `price`, `schedule_days`, `schedule_time`, `status`, `created_at`, `banner_image`, `benefits`, `faqs`) VALUES ('21', '8', 'Quran Reading for Beginners', 'Start your journey of reading the Quran from scratch (Qaida).', '30.00', 'Mon,Wed,Fri', '10:00 AM - 11:00 AM', 'approved', '2025-12-17 16:41:12', 'assets/images/courses/reading.png', 'Noorani Qaida\nMakharij Practice\nBasic Tajweed', 'Q: Is there an age limit?\nA: No, this course is for all ages.');


DROP TABLE IF EXISTS `enrollments`;
CREATE TABLE `enrollments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `status` enum('active','completed','cancelled') DEFAULT 'active',
  `payment_status` enum('paid','pending') DEFAULT 'pending',
  `transaction_id` varchar(100) DEFAULT NULL,
  `enrolled_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `course_id` (`course_id`),
  CONSTRAINT `enrollments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `enrollments_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `enrollments` (`id`, `student_id`, `course_id`, `status`, `payment_status`, `transaction_id`, `enrolled_at`) VALUES ('2', '1', '2', 'active', 'paid', 'TXN80616', '2025-12-17 15:42:15');


DROP TABLE IF EXISTS `inquiries`;
CREATE TABLE `inquiries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `country` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `students` (`id`, `name`, `email`, `password`, `country`, `phone`, `created_at`) VALUES ('1', 'Muhammad Saad', 'adminshop@gmail.com', '$2y$10$2ivVnu9ZpE4EBtEAGSb7G.0RANxWF4G7/K9HG9mIpeXDzWpa2V6lO', 'Pakistan', '', '2025-12-17 12:29:04');
INSERT INTO `students` (`id`, `name`, `email`, `password`, `country`, `phone`, `created_at`) VALUES ('2', 'Admin User', 'admin@digitalhub.com', '$2y$10$ClgIvJcus969MAHyYP8XLexm4Ct5U4R7iW/2HEwEZrfArIKwSinVW', 'Pakistan', '', '2025-12-17 14:26:23');
INSERT INTO `students` (`id`, `name`, `email`, `password`, `country`, `phone`, `created_at`) VALUES ('3', 'Muhammad Saad', 'muhammadsaad10661@gmail.com', '$2y$10$t9osirbOyKGkCCoeQakTF.t2hG4K1PiexH.Xjnl/U6xKG3lWYUwKi', 'pakistan', '03203410117', '2025-12-17 22:00:47');


DROP TABLE IF EXISTS `tutors`;
CREATE TABLE `tutors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `country` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `specialty` varchar(100) DEFAULT 'General',
  `rating` decimal(3,1) DEFAULT 0.0,
  `price_hourly` decimal(10,2) DEFAULT 0.00,
  `image` varchar(255) DEFAULT 'assets/images/default_avatar.png',
  `bio` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('1', 'Sheikh Ahmed', 'ahmed@example.com', '$2y$10$h5BPqzdjcYwpLJDg/TWfEeSRSoRxP.XV6Sr49edSKxIwW6U4oX5xm', 'Egypt', NULL, 'Male', 'Tajweed & Hifz', '5.0', '8.00', 'assets/images/default_avatar.png', 'Expert in Tajweed rules with 10 years experience.', '1', '2025-12-17 11:48:08');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('2', 'Ustadha Fatima', 'fatima@example.com', '$2y$10$h5BPqzdjcYwpLJDg/TWfEeSRSoRxP.XV6Sr49edSKxIwW6U4oX5xm', 'UK', NULL, 'Female', 'Arabic Grammar', '4.9', '10.00', 'assets/images/default_avatar.png', 'Specializes in teaching kids and beginners.', '1', '2025-12-17 11:48:08');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('3', 'Qari Abdur Rahman', 'rahman@example.com', '$2y$10$h5BPqzdjcYwpLJDg/TWfEeSRSoRxP.XV6Sr49edSKxIwW6U4oX5xm', 'Pakistan', NULL, 'Male', 'Recitation', '5.0', '12.00', 'assets/images/default_avatar.png', 'Ijazah holder with a beautiful voice.', '1', '2025-12-17 11:48:08');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('4', 'Muhammad Saad', 'muhammadsaadmrsaad381@gmail.com', '$2y$10$UG2v.H3RgUwV1zgEk8aDIOkwLWHSOmKRnEp7ZLDMR0HoSCsBRNWoq', 'Pakistan', '03203410117', 'Male', 'General', '0.0', '0.00', 'assets/images/default_avatar.png', NULL, '1', '2025-12-17 11:48:40');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('5', 'Muhammad Saad', 'habiburrehman0p@gmail.com', '$2y$10$j2IcFwTtt7xKtlDZtJhsbuh5B//EQ1mnbhkGTYRlYnKKayoUwCBcO', 'Pakistan', '03203410117', 'Male', 'General', '0.0', '0.00', 'assets/images/default_avatar.png', NULL, '1', '2025-12-17 12:27:28');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('6', 'Qari Ibrahim', 'ibrahim@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Egypt', NULL, 'Male', 'General', '5.0', '0.00', 'assets/images/tutor_male.png', 'Al-Azhar graduate specializing in Hifz.', '1', '2025-12-17 16:41:12');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('7', 'Sister Maryam', 'maryam@example.com', '$2y$10$abcdefg1234567890abcdefg', 'UK', NULL, 'Female', 'General', '5.0', '0.00', 'assets/images/tutor_female.png', 'Expert in teaching kids and beginners.', '1', '2025-12-17 16:41:12');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('8', 'Brother Ali', 'ali@example.com', '$2y$10$abcdefg1234567890abcdefg', 'USA', NULL, 'Male', 'General', '5.0', '0.00', 'assets/images/tutor_male.png', 'Focuses on Arabic grammar and understanding.', '1', '2025-12-17 16:41:12');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('9', 'Abdullah 782', 'abdullah782@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Egypt', NULL, 'Male', 'General', '5.0', '16.00', 'assets/images/tutor_male.png', 'Specializes in Tajweed and Hifz for children and adults.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('10', 'Hassan 962', 'hassan962@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Pakistan', NULL, 'Male', 'General', '4.6', '17.00', 'assets/images/tutor_male.png', 'Fluent in English and Arabic, great with kids.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('11', 'Yusuf 906', 'yusuf906@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Egypt', NULL, 'Male', 'General', '4.8', '9.00', 'assets/images/tutor_male.png', 'Certified Quran teacher with 5 years of online experience.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('12', 'Ali 728', 'ali728@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Pakistan', NULL, 'Male', 'General', '4.8', '10.00', 'assets/images/tutor_male.png', 'Patient and experienced tutor for beginners.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('13', 'Hassan 225', 'hassan225@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Egypt', NULL, 'Male', 'General', '4.6', '11.00', 'assets/images/tutor_male.png', 'Certified Quran teacher with 5 years of online experience.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('14', 'Abdullah 525', 'abdullah525@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Pakistan', NULL, 'Male', 'General', '4.8', '14.00', 'assets/images/tutor_male.png', 'Specializes in Tajweed and Hifz for children and adults.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('15', 'Mustafa 646', 'mustafa646@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Egypt', NULL, 'Male', 'General', '4.8', '13.00', 'assets/images/tutor_male.png', 'Specializes in Tajweed and Hifz for children and adults.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('16', 'Khalid 471', 'khalid471@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Pakistan', NULL, 'Male', 'General', '4.7', '16.00', 'assets/images/tutor_male.png', 'Ijazah holder from Al-Azhar University.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('17', 'Sara 857', 'sara857@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Egypt', NULL, 'Female', 'General', '4.6', '12.00', 'assets/images/tutor_female.png', 'Fluent in English and Arabic, great with kids.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('18', 'Hafsa 384', 'hafsa384@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Pakistan', NULL, 'Female', 'General', '4.6', '15.00', 'assets/images/tutor_female.png', 'Ijazah holder from Al-Azhar University.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('19', 'Sara 104', 'sara104@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Egypt', NULL, 'Female', 'General', '4.9', '15.00', 'assets/images/tutor_female.png', 'Specializes in Tajweed and Hifz for children and adults.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('20', 'Zahra 940', 'zahra940@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Pakistan', NULL, 'Female', 'General', '4.9', '16.00', 'assets/images/tutor_female.png', 'Certified Quran teacher with 5 years of online experience.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('21', 'Sumayya 699', 'sumayya699@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Egypt', NULL, 'Female', 'General', '4.7', '14.00', 'assets/images/tutor_female.png', 'Certified Quran teacher with 5 years of online experience.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('22', 'Ayesha 258', 'ayesha258@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Pakistan', NULL, 'Female', 'General', '4.5', '14.00', 'assets/images/tutor_female.png', 'Ijazah holder from Al-Azhar University.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('23', 'Sara 458', 'sara458@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Egypt', NULL, 'Female', 'General', '4.9', '9.00', 'assets/images/tutor_female.png', 'Ijazah holder from Al-Azhar University.', '1', '2025-12-18 17:20:45');
INSERT INTO `tutors` (`id`, `name`, `email`, `password`, `country`, `phone`, `gender`, `specialty`, `rating`, `price_hourly`, `image`, `bio`, `is_active`, `created_at`) VALUES ('24', 'Hafsa 202', 'hafsa202@example.com', '$2y$10$abcdefg1234567890abcdefg', 'Pakistan', NULL, 'Female', 'General', '4.8', '12.00', 'assets/images/tutor_female.png', 'Ijazah holder from Al-Azhar University.', '1', '2025-12-18 17:20:45');


