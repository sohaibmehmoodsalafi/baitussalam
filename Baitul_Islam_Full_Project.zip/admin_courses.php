<?php
session_start();
require 'includes/db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

if (isset($_POST['action']) && isset($_POST['course_id'])) {
    $course_id = $_POST['course_id'];
    $new_status = ($_POST['action'] === 'approve') ? 'approved' : 'rejected';
    
    try {
        $stmt = $pdo->prepare("UPDATE courses SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $course_id]);
        $msg = "Course has been " . $new_status . " successfully!";
        $msg_type = "success";
    } catch (PDOException $e) {
        $msg = "Error updating course: " . $e->getMessage();
        $msg_type = "danger";
    }
}

// Handle Course Deletion
if (isset($_POST['delete_course'])) {
    $course_id = $_POST['course_id'];
    try {
        $pdo->beginTransaction();
        // 1. Delete associated enrollments
        $stmt = $pdo->prepare("DELETE FROM enrollments WHERE course_id = ?");
        $stmt->execute([$course_id]);
        
        // 2. Delete the course
        $stmt = $pdo->prepare("DELETE FROM courses WHERE id = ?");
        $stmt->execute([$course_id]);
        
        $pdo->commit();
        $msg = "Course and all associated enrollments deleted successfully!";
        $msg_type = "success";
    } catch (Exception $e) {
        $pdo->rollBack();
        $msg = "Delete failed: " . $e->getMessage();
        $msg_type = "danger";
    }
}

// Fetch Courses with Tutor Info
$stmt = $pdo->query("
    SELECT c.*, t.name as tutor_name, t.email as tutor_email 
    FROM courses c 
    JOIN tutors t ON c.tutor_id = t.id 
    ORDER BY c.status = 'pending' DESC, c.created_at DESC
");
$courses = $stmt->fetchAll();

include 'includes/admin_header_layout.php';
?>

<div class="d-flex" id="wrapper">
    <?php include 'includes/admin_sidebar.php'; ?> 

    <div id="page-content-wrapper">
        <!-- Top Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 px-4 mb-4 border-bottom shadow-sm">
            <div class="container-fluid">
                <div class="d-flex align-items-center">
                    <button class="btn btn-light d-lg-none me-3" id="menu-toggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h4 class="fw-bold mb-0 text-dark">Course Management</h4>
                </div>
                
                <div class="user-profile">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=0F5132&color=fff" class="avatar">
                    <div class="user-info d-none d-sm-flex ms-2">
                        <span class="name">Administrator</span>
                        <span class="role text-muted small">Super Admin</span>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid px-4">
            
            <?php if(isset($msg)): ?>
                <div class="alert alert-<?php echo $msg_type; ?> alert-dismissible fade show rounded-4 border-0 shadow-sm mb-4" role="alert">
                    <i class="fas <?php echo $msg_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> me-2"></i> <?php echo $msg; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-5">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
                    <h5 class="mb-0 fw-bold text-dark"><i class="fas fa-book me-2 text-primary"></i> Pending & Active Courses</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">Tutor</th>
                                    <th>Course Details</th>
                                    <th>Price & Schedule</th>
                                    <th>Status</th>
                                    <th class="text-end pe-4">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($courses as $course): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-circle bg-primary-subtle text-primary fw-bold d-flex align-items-center justify-content-center me-3" style="width:38px; height:38px; border-radius:10px;">
                                                <?php echo strtoupper(substr($course['tutor_name'], 0, 1)); ?>
                                            </div>
                                            <div>
                                                <div class="fw-bold text-dark small"><?php echo htmlspecialchars($course['tutor_name']); ?></div>
                                                <div class="text-muted small" style="font-size: 0.75rem;"><?php echo htmlspecialchars($course['tutor_email']); ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-primary small mb-1"><?php echo htmlspecialchars($course['title']); ?></div>
                                        <div class="text-muted small" style="max-width: 250px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                            <?php echo htmlspecialchars($course['description']); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="small">
                                            <div class="text-dark fw-bold mb-1">$<?php echo number_format($course['price'], 2); ?></div>
                                            <div class="text-muted" style="font-size: 0.75rem;">
                                                <i class="far fa-calendar-alt me-1"></i> <?php echo htmlspecialchars($course['schedule_days']); ?><br>
                                                <i class="far fa-clock me-1"></i> <?php echo htmlspecialchars($course['schedule_time']); ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($course['status'] == 'approved'): ?>
                                            <span class="badge bg-success-subtle text-success rounded-pill px-3 py-2">
                                                <i class="fas fa-check-circle me-1"></i> Approved
                                            </span>
                                        <?php elseif($course['status'] == 'pending'): ?>
                                            <span class="badge bg-warning-subtle text-warning rounded-pill px-3 py-2">
                                                <i class="fas fa-clock me-1"></i> Pending
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger rounded-pill px-3 py-2">
                                                <i class="fas fa-times-circle me-1"></i> Rejected
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end pe-4">
                                        <div class="d-flex justify-content-end gap-2">
                                            <?php if($course['status'] == 'pending'): ?>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                                                    <button type="submit" name="action" value="approve" class="btn btn-success btn-sm rounded-pill px-3 shadow-sm" style="font-weight: 700; background: #15803d; border: none;">
                                                        Approve
                                                    </button>
                                                    <button type="submit" name="action" value="reject" class="btn btn-outline-danger btn-sm rounded-pill px-3 shadow-sm" style="font-weight: 700;">
                                                        Reject
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                            
                                            <a href="admin_edit_course.php?id=<?php echo $course['id']; ?>" class="btn btn-light btn-sm rounded-circle border p-0 d-inline-flex align-items-center justify-content-center" style="width: 32px; height: 32px;" title="Edit Course">
                                                <i class="fas fa-edit text-primary" style="font-size: 0.8rem;"></i>
                                            </a>
                                            <form method="POST" onsubmit="return confirm('WARNING: This will delete the course AND all student enrollments associated with it. Continue?');" class="d-inline">
                                                <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                                                <button type="submit" name="delete_course" class="btn btn-danger btn-sm rounded-circle border p-0 d-inline-flex align-items-center justify-content-center" style="width: 32px; height: 32px;" title="Delete Course">
                                                    <i class="fas fa-trash" style="font-size: 0.75rem;"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                
                                <?php if(empty($courses)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-5 text-muted">
                                            <i class="fas fa-book-open fa-3x mb-3 opacity-25"></i>
                                            <p>No courses found.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
// Sidebar Toggle
document.getElementById("menu-toggle")?.addEventListener("click", function(e) {
    e.preventDefault();
    document.getElementById("wrapper").classList.toggle("toggled");
});
</script>

<?php include 'includes/admin_footer.php'; ?>
