<?php
require 'includes/db.php';
session_start();

$slip_id = $_GET['id'] ?? 0;

$stmt = $pdo->prepare("
    SELECT ss.*, t.name as tutor_name, t.email as tutor_email, t.specialty, t.phone
    FROM salary_slips ss 
    JOIN tutors t ON ss.tutor_id = t.id 
    WHERE ss.id = ?
");
$stmt->execute([$slip_id]);
$slip = $stmt->fetch();

if (!$slip) die("Slip not found.");

$monthName = date('F', mktime(0,0,0, $slip['month'], 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Slip - <?php echo $slip['tutor_name']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; background: #f0f2f5; padding: 40px 0; }
        .slip-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 60px;
            border-radius: 0;
            box-shadow: 0 50px 100px rgba(0,0,0,0.05);
            position: relative;
            border-top: 10px solid #0F5132;
        }
        .logo-box { margin-bottom: 40px; }
        .logo-box img { height: 60px; }
        .slip-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 50px;
            border-bottom: 2px solid #f1f5f9;
            padding-bottom: 30px;
        }
        .section-title {
            text-transform: uppercase;
            font-size: 0.8rem;
            letter-spacing: 2px;
            color: #94a3b8;
            font-weight: 800;
            margin-bottom: 15px;
        }
        .data-label { color: #64748b; font-size: 0.9rem; margin-bottom: 5px; }
        .data-value { font-weight: 700; color: #1e293b; margin-bottom: 20px; }
        
        .table-salary { margin-top: 40px; }
        .table-salary thead { background: #f8fafc; }
        .table-salary th { border: none; padding: 20px; font-weight: 800; font-size: 0.85rem; text-transform: uppercase; color: #64748b; }
        .table-salary td { padding: 20px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
        
        .total-box {
            background: #0F5132;
            color: white;
            padding: 30px;
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .watermark {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            font-size: 8rem;
            color: rgba(0,0,0,0.02);
            font-weight: 900;
            white-space: nowrap;
            pointer-events: none;
            z-index: 0;
        }
        @media print {
            body { background: white; padding: 0; }
            .slip-container { box-shadow: none; border: 1px solid #eee; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>

<div class="container text-center mb-4 no-print">
    <button onclick="window.print()" class="btn btn-dark px-4 rounded-pill">Print / Download PDF</button>
    <a href="admin_salaries.php" class="btn btn-outline-secondary px-4 rounded-pill ms-2">Back to Payroll</a>
</div>

<div class="slip-container">
    <div class="watermark">BAITUL ISLAM</div>
    
    <div class="logo-box d-flex justify-content-between align-items-center">
        <img src="assets/images/logo.png" alt="Logo">
        <div class="text-end">
            <h2 class="fw-black mb-0" style="color: #0F5132; letter-spacing: -1px;">SALARY SLIP</h2>
            <p class="text-muted small">#PI-PAY-<?php echo str_pad($slip['id'], 5, '0', STR_PAD_LEFT); ?></p>
        </div>
    </div>

    <div class="slip-header">
        <div style="flex: 1;">
            <div class="section-title">Teacher Information</div>
            <div class="data-label">Name</div>
            <div class="data-value"><?php echo $slip['tutor_name']; ?></div>
            <div class="data-label">Specialty</div>
            <div class="data-value"><?php echo $slip['specialty']; ?></div>
            <div class="data-label">Email</div>
            <div class="data-value"><?php echo $slip['tutor_email']; ?></div>
        </div>
        <div style="flex: 1;" class="text-end">
            <div class="section-title">Payment Period</div>
            <div class="data-label">Month & Year</div>
            <div class="data-value" style="font-size: 1.5rem; color: #0F5132;"><?php echo $monthName . ', ' . $slip['year']; ?></div>
            <div class="data-label">Generation Date</div>
            <div class="data-value"><?php echo date('d M, Y', strtotime($slip['created_at'])); ?></div>
            <div class="data-label">Status</div>
            <div class="data-value"><span class="badge bg-success"><?php echo strtoupper($slip['status']); ?></span></div>
        </div>
    </div>

    <table class="table table-salary">
        <thead>
            <tr>
                <th>Description</th>
                <th class="text-center">Hours</th>
                <th class="text-end">Rate / Hour</th>
                <th class="text-end">Total Amount</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>
                    <div class="fw-bold">Instructional Classes</div>
                    <div class="small text-muted">Fixed hourly sessions conducted via Jitsi Platform</div>
                </td>
                <td class="text-center fw-bold"><?php echo $slip['total_hours']; ?> hrs</td>
                <td class="text-end">$<?php echo number_format($slip['hourly_rate'], 2); ?></td>
                <td class="text-end fw-black">$<?php echo number_format($slip['total_salary'], 2); ?></td>
            </tr>
        </tbody>
    </table>

    <div class="total-box">
        <div>
            <h4 class="mb-0 fw-bold">Grand Total Earnings</h4>
            <p class="mb-0 small opacity-75">All taxes and platform fees included</p>
        </div>
        <div class="text-end">
            <h1 class="mb-0 fw-black" style="font-size: 3rem;">$<?php echo number_format($slip['total_salary'], 2); ?></h1>
        </div>
    </div>

    <div class="mt-5 pt-5 row align-items-end">
        <div class="col-6">
            <div style="height: 1px; background: #eee; width: 200px; margin-bottom: 10px;"></div>
            <p class="small text-muted fw-bold">FINANCE DIRECTOR SIGNATURE</p>
        </div>
        <div class="col-6 text-end">
            <p class="small text-muted italic">This is a system-generated document and requires no physical signature for digital use.</p>
        </div>
    </div>
</div>

<div class="container text-center mt-4">
    <p class="small text-muted">&copy; <?php echo date('Y'); ?> Baitul Islam Academy. Powered by Soft Desk Solutions.</p>
</div>

</body>
</html>
