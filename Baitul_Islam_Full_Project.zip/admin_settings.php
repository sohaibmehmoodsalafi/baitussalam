<?php
session_start();
require 'includes/db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Handle Save
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $settings = $_POST['settings'];
    foreach ($settings as $key => $value) {
        $stmt = $pdo->prepare("INSERT INTO site_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->execute([$key, $value, $value]);
    }
    $msg = "Settings updated successfully!";
}

// Fetch Settings
$stmt = $pdo->query("SELECT setting_key, setting_value FROM site_settings");
$all_settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR); // constant key => value

include 'includes/admin_header_layout.php';
?>

<div class="d-flex" id="wrapper">
    <?php include 'includes/admin_sidebar.php'; ?>

    <div id="page-content-wrapper">
        <!-- Top Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 px-4 mb-4 border-bottom shadow-sm">
            <div class="container-fluid">
                <div class="d-flex align-items-center">
                    <button class="btn btn-light d-lg-none me-3" id="menu-toggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h4 class="fw-bold mb-0 text-dark">Site Configuration</h4>
                </div>
                
                <div class="user-profile">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=0F5132&color=fff" class="avatar">
                    <div class="user-info d-none d-sm-flex ms-2">
                        <span class="name">Administrator</span>
                        <span class="role text-muted small">Super Admin</span>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid px-4">
            
            <?php if(isset($msg)): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4 shadow-sm border-0 mb-4" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $msg; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="row g-4 mb-5">
                    <!-- General Settings -->
                    <div class="col-md-6">
                        <div class="card border-0 shadow-sm rounded-4 h-100">
                            <div class="card-header bg-white py-3 fw-bold border-bottom">
                                <h6 class="mb-0 fw-bold"><i class="fas fa-globe me-2 text-primary"></i> General Information</h6>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="form-label text-muted small fw-bold">Website Name</label>
                                    <input type="text" name="settings[site_name]" class="form-control rounded-3 border-light-subtle" value="<?php echo htmlspecialchars($all_settings['site_name'] ?? ''); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label text-muted small fw-bold">Support Phone</label>
                                    <input type="text" name="settings[site_phone]" class="form-control rounded-3 border-light-subtle" value="<?php echo htmlspecialchars($all_settings['site_phone'] ?? ''); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label text-muted small fw-bold">Support Email</label>
                                    <input type="email" name="settings[site_email]" class="form-control rounded-3 border-light-subtle" value="<?php echo htmlspecialchars($all_settings['site_email'] ?? ''); ?>">
                                </div>
                                <div class="mb-0">
                                    <label class="form-label text-muted small fw-bold">Physical Address</label>
                                    <textarea name="settings[site_address]" class="form-control rounded-3 border-light-subtle" rows="2"><?php echo htmlspecialchars($all_settings['site_address'] ?? ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Social Media -->
                    <div class="col-md-6">
                        <div class="card border-0 shadow-sm rounded-4 h-100">
                            <div class="card-header bg-white py-3 fw-bold border-bottom">
                                <h6 class="mb-0 fw-bold"><i class="fas fa-share-alt me-2 text-info"></i> Social Links</h6>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label class="form-label text-muted small fw-bold">Facebook URL</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-light-subtle border-end-0"><i class="fab fa-facebook text-primary"></i></span>
                                        <input type="text" name="settings[facebook_url]" class="form-control rounded-end-3 border-light-subtle border-start-0" value="<?php echo htmlspecialchars($all_settings['facebook_url'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label text-muted small fw-bold">Instagram URL</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-light-subtle border-end-0"><i class="fab fa-instagram text-danger"></i></span>
                                        <input type="text" name="settings[instagram_url]" class="form-control rounded-end-3 border-light-subtle border-start-0" value="<?php echo htmlspecialchars($all_settings['instagram_url'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <label class="form-label text-muted small fw-bold">Twitter URL</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light border-light-subtle border-end-0"><i class="fab fa-twitter text-info"></i></span>
                                        <input type="text" name="settings[twitter_url]" class="form-control rounded-end-3 border-light-subtle border-start-0" value="<?php echo htmlspecialchars($all_settings['twitter_url'] ?? ''); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Finance System -->
                    <div class="col-md-12">
                         <div class="card border-0 shadow-sm rounded-4">
                            <div class="card-header bg-white py-3 fw-bold border-bottom">
                                <h6 class="mb-0 fw-bold"><i class="fas fa-wallet me-2 text-success"></i> Financial Settings</h6>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-muted small fw-bold">Currency Symbol</label>
                                        <input type="text" name="settings[currency_symbol]" class="form-control rounded-3 border-light-subtle" value="<?php echo htmlspecialchars($all_settings['currency_symbol'] ?? '$'); ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label text-muted small fw-bold">Default Tutor Commission (%)</label>
                                        <input type="number" name="settings[tutor_commission]" class="form-control rounded-3 border-light-subtle" value="<?php echo htmlspecialchars($all_settings['tutor_commission'] ?? '20'); ?>">
                                        <small class="text-muted opacity-75">Applied for freelance tutors by default.</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="text-end mb-5">
                    <button type="submit" class="btn btn-primary btn-lg rounded-pill px-5 shadow-sm transition-all"><i class="fas fa-save me-2"></i> Update Site Settings</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    body { background-color: #f8fafc; font-family: 'Outfit', sans-serif; }
    #page-content-wrapper {
        flex-grow: 1;
        min-width: 0;
        transition: 0.3s;
        min-height: 100vh;
    }
    .user-profile {
        display: flex; align-items: center; background: #fff; padding: 6px 12px;
        border-radius: 12px; border: 1px solid #f1f5f9;
        cursor: pointer;
    }
    .avatar { width: 32px; height: 32px; border-radius: 8px; }
    
    .form-control, .form-select, .input-group-text {
        font-size: 0.9rem;
        padding: 0.6rem 0.8rem;
    }
    .form-label { margin-bottom: 0.4rem; }
    
    .transition-all { transition: all 0.3s ease; }
    .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(13, 110, 253, 0.3) !important; }

    @media (max-width: 992px) {
        #page-content-wrapper { margin-left: 0; width: 100%; }
        #sidebar-wrapper { margin-left: -280px; position: fixed; height: 100vh; z-index: 1050; }
        #wrapper.toggled #sidebar-wrapper { margin-left: 0; }
    }
</style>

<script>
// Sidebar Toggle
document.getElementById("menu-toggle")?.addEventListener("click", function(e) {
    e.preventDefault();
    document.getElementById("wrapper").classList.toggle("toggled");
});
</script>

<?php include 'includes/admin_footer.php'; ?>
