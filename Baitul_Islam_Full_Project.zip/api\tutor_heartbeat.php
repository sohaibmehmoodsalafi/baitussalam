<?php
require '../includes/db.php';
session_start();

if (isset($_SESSION['user_id']) && $_SESSION['user_role'] == 'tutor') {
    $user_id = $_SESSION['user_id'];
    try {
        $stmt = $pdo->prepare("UPDATE tutors SET is_online = 1, last_seen = NOW() WHERE id = ?");
        $stmt->execute([$user_id]);
        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        echo json_encode(['success' => false]);
    }
}
