<?php
session_start();
require 'includes/db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Handle Actions (Delete/Ban)
if(isset($_POST['action']) && isset($_POST['student_id'])) {
    $id = $_POST['student_id'];
    if($_POST['action'] == 'delete') {
        $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
        $stmt->execute([$id]);
        $success_msg = "Student record deleted.";
    }
}

// Fetch Students
$stmt = $pdo->query("
    SELECT s.*, 
    (SELECT COUNT(*) FROM enrollments e WHERE e.student_id = s.id AND e.status = 'active') as active_courses
    FROM students s 
    ORDER BY created_at DESC
");
$students = $stmt->fetchAll();

include 'includes/admin_header_layout.php';
?>

<div class="d-flex" id="wrapper">
    <?php include 'includes/admin_sidebar.php'; ?> 

    <div id="page-content-wrapper">
        <!-- Top Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 px-4 mb-4 border-bottom shadow-sm">
            <div class="container-fluid">
                <div class="d-flex align-items-center">
                    <button class="btn btn-light d-lg-none me-3" id="menu-toggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h4 class="fw-bold mb-0 text-dark">Student Management</h4>
                </div>
                
                <div class="user-profile">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=0F5132&color=fff" class="avatar">
                    <div class="user-info d-none d-sm-flex ms-2">
                        <span class="name">Administrator</span>
                        <span class="role text-muted small">Super Admin</span>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid px-4">
            
            <?php if(isset($success_msg)): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4 shadow-sm border-0 mb-4" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $success_msg; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-5">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold text-dark"><i class="fas fa-user-graduate me-2 text-primary"></i> Registered Students</h5>
                    <button class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm"><i class="fas fa-user-plus me-2"></i> Add New Student</button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4">Student</th>
                                    <th>Contact Information</th>
                                    <th>Country</th>
                                    <th>Status</th>
                                    <th>Joined Date</th>
                                    <th class="text-end pe-4">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($students as $s): ?>
                                <tr>
                                    <td class="ps-4">
                                        <div class="d-flex align-items-center py-2">
                                            <div class="avatar-circle bg-primary-subtle text-primary fw-bold d-flex align-items-center justify-content-center me-3 shadow-sm" style="width:42px; height:42px; border-radius:12px; font-size: 0.9rem;">
                                                <?php echo strtoupper(substr($s['name'], 0, 1)); ?>
                                            </div>
                                            <div>
                                                <div class="fw-bold text-dark"><?php echo htmlspecialchars($s['name']); ?></div>
                                                <small class="text-muted">ID: #ST-<?php echo str_pad($s['id'], 4, '0', STR_PAD_LEFT); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <span class="text-dark small mb-1"><i class="far fa-envelope me-2 text-muted"></i><?php echo htmlspecialchars($s['email']); ?></span>
                                            <span class="text-muted small"><i class="fas fa-phone-alt me-2 text-muted"></i><?php echo htmlspecialchars($s['phone'] ?? 'N/A'); ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <span class="badge bg-light text-dark border-0 shadow-sm rounded-pill px-3 py-2 fw-medium">
                                                <i class="fas fa-globe-americas text-primary-emphasis me-1"></i> <?php echo htmlspecialchars($s['country']); ?>
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($s['active_courses'] > 0): ?>
                                            <span class="badge bg-success-subtle text-success rounded-pill px-3 py-2">
                                                <i class="fas fa-circle me-1" style="font-size: 0.5rem;"></i> <?php echo $s['active_courses']; ?> Active Courses
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary-subtle text-secondary rounded-pill px-3 py-2">
                                                <i class="fas fa-circle me-1" style="font-size: 0.5rem;"></i> No Active Courses
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-muted small"><?php echo date('M d, Y', strtotime($s['created_at'])); ?></td>
                                    <td class="text-end pe-4">
                                        <div class="dropdown">
                                            <button class="btn btn-light btn-sm rounded-circle shadow-sm" type="button" data-bs-toggle="dropdown" style="width:32px; height:32px;">
                                                <i class="fas fa-ellipsis-v fa-xs"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end border-0 shadow-lg rounded-3">
                                                <li><a class="dropdown-item py-2" href="#"><i class="fas fa-user-edit me-2 text-primary"></i> Edit Profile</a></li>
                                                <li><a class="dropdown-item py-2" href="#"><i class="fas fa-book-reader me-2 text-info"></i> View Enrollments</a></li>
                                                <li><hr class="dropdown-divider opacity-50"></li>
                                                <li>
                                                    <form method="POST" onsubmit="return confirm('Are you sure you want to delete this student permanently?');">
                                                        <input type="hidden" name="student_id" value="<?php echo $s['id']; ?>">
                                                        <button type="submit" name="action" value="delete" class="dropdown-item py-2 text-danger fw-medium"><i class="fas fa-trash-alt me-2"></i> Delete Student</button>
                                                    </form>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer bg-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="text-muted small">Showing <?php echo count($students); ?> students</span>
                        <nav>
                            <ul class="pagination pagination-sm mb-0">
                                <li class="page-item disabled"><a class="page-link rounded-start-pill px-3" href="#">Prev</a></li>
                                <li class="page-item active"><a class="page-link px-3" href="#">1</a></li>
                                <li class="page-item"><a class="page-link rounded-end-pill px-3" href="#">Next</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<style>
    body { background-color: #f8fafc; font-family: 'Outfit', sans-serif; }
    #page-content-wrapper {
        flex-grow: 1;
        min-width: 0;
        transition: 0.3s;
        min-height: 100vh;
    }
    .user-profile {
        display: flex; align-items: center; background: #fff; padding: 6px 12px;
        border-radius: 12px; border: 1px solid #f1f5f9;
        cursor: pointer;
    }
    .avatar { width: 32px; height: 32px; border-radius: 8px; }
    
    .table thead th {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 700;
        color: #64748b;
        border-top: none;
        padding: 1.25rem 0.75rem;
    }
    
    .bg-primary-subtle { background-color: #ebf5ff; }
    .bg-success-subtle { background-color: #f0fdf4; }
    .bg-info-subtle { background-color: #f0f9ff; }
    .bg-secondary-subtle { background-color: #f8fafc; }

    .dropdown-item:hover { background-color: #f8fafc; color: #0F5132; }
    
    @media (max-width: 992px) {
        #page-content-wrapper { margin-left: 0; width: 100%; }
        #sidebar-wrapper { margin-left: -280px; position: fixed; height: 100vh; z-index: 1050; }
        #wrapper.toggled #sidebar-wrapper { margin-left: 0; }
    }
</style>

<script>
// Sidebar Toggle
document.getElementById("menu-toggle")?.addEventListener("click", function(e) {
    e.preventDefault();
    document.getElementById("wrapper").classList.toggle("toggled");
});
</script>

<?php include 'includes/admin_footer.php'; ?>
