<?php
session_start();
require_once 'includes/db.php';

$message = '';
$error = '';
$token_valid = false;

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    
    // Verify token
    $stmt = $pdo->prepare("SELECT id, username, reset_token_expiry FROM admins WHERE reset_token = ?");
    $stmt->execute([$token]);
    $admin = $stmt->fetch();
    
    if ($admin && strtotime($admin['reset_token_expiry']) > time()) {
        $token_valid = true;
        
        // Handle password reset
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $new_password = $_POST['password'];
            $confirm_password = $_POST['confirm_password'];
            
            if (strlen($new_password) < 8) {
                $error = "Password must be at least 8 characters long.";
            } elseif ($new_password !== $confirm_password) {
                $error = "Passwords do not match.";
            } else {
                // Hash new password
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                
                // Update password and clear reset token
                $stmt = $pdo->prepare("UPDATE admins SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?");
                $stmt->execute([$hashed_password, $admin['id']]);
                
                $message = "Your admin password has been reset successfully! You can now login with your new password.";
                $token_valid = false; // Hide form after success
            }
        }
    } else {
        $error = "Invalid or expired reset link. Please request a new password reset.";
    }
} else {
    $error = "Invalid reset link.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Admin Password - Peace Institute</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #0F5132;
            --primary-dark: #082F1D;
            --accent: #D4AF37;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: radial-gradient(circle at center, var(--primary) 0%, var(--primary-dark) 100%);
            padding: 20px;
            position: relative;
        }

        .orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            z-index: 1;
        }
        .orb-1 { width: 400px; height: 400px; background: rgba(212, 175, 55, 0.15); top: -100px; left: -100px; }
        .orb-2 { width: 300px; height: 300px; background: rgba(15, 81, 50, 0.5); bottom: -50px; right: -50px; }

        .reset-card {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            padding: 50px;
            border-radius: 24px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
            width: 100%;
            max-width: 500px;
            position: relative;
            z-index: 10;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .reset-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .brand-icon {
            width: 70px;
            height: 70px;
            background: var(--primary);
            color: var(--accent);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            margin: 0 auto 20px;
            box-shadow: 0 10px 20px rgba(15, 81, 50, 0.2);
        }

        .reset-header h1 {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--primary-dark);
            margin-bottom: 8px;
        }

        .reset-header p {
            color: #64748b;
            font-size: 0.95rem;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-label {
            display: block;
            font-weight: 700;
            color: var(--primary-dark);
            margin-bottom: 10px;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-control {
            width: 100%;
            padding: 15px 45px 15px 20px;
            border: 2px solid #f1f5f9;
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s;
            background: #f8fafc;
        }

        .form-control:focus {
            border-color: var(--primary);
            background: white;
            outline: none;
            box-shadow: 0 0 0 4px rgba(15, 81, 50, 0.05);
        }

        .toggle-password {
            position: absolute;
            right: 15px;
            top: 48px;
            cursor: pointer;
            color: #999;
            font-size: 1.1rem;
        }

        .toggle-password:hover {
            color: var(--primary);
        }

        .btn-reset {
            width: 100%;
            padding: 16px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 800;
            cursor: pointer;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 10px;
        }

        .btn-reset:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(15, 81, 50, 0.2);
        }

        .success-alert {
            background: #d4edda;
            color: #155724;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 0.9rem;
            font-weight: 600;
            text-align: center;
            border: 1px solid #c3e6cb;
        }

        .error-alert {
            background: #fee2e2;
            color: #991b1b;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 0.9rem;
            font-weight: 600;
            text-align: center;
            border: 1px solid #fecaca;
        }

        .back-link {
            text-align: center;
            margin-top: 30px;
        }

        .back-link a {
            color: #64748b;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: 0.3s;
        }

        .back-link a:hover {
            color: var(--primary);
        }

        .password-strength {
            height: 4px;
            background: #e0e0e0;
            border-radius: 2px;
            margin-top: 8px;
            overflow: hidden;
        }

        .password-strength-bar {
            height: 100%;
            width: 0%;
            transition: all 0.3s;
        }

        .strength-weak { width: 33%; background: #dc3545; }
        .strength-medium { width: 66%; background: #ffc107; }
        .strength-strong { width: 100%; background: #28a745; }
    </style>
</head>
<body>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>

    <div class="reset-card">
        <div class="reset-header">
            <div class="brand-icon">
                <i class="fas fa-lock"></i>
            </div>
            <h1>Reset Admin Password</h1>
            <p>Create a new secure password</p>
        </div>

        <?php if($message): ?>
            <div class="success-alert">
                <i class="fas fa-check-circle"></i> <?php echo $message; ?>
            </div>
            <div class="back-link">
                <a href="admin_login.php">
                    <i class="fas fa-sign-in-alt"></i> Go to Admin Login
                </a>
            </div>
        <?php endif; ?>

        <?php if($error): ?>
            <div class="error-alert">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
            <?php if (!$token_valid): ?>
                <div class="back-link">
                    <a href="admin_forgot_password.php">
                        <i class="fas fa-redo"></i> Request New Reset Link
                    </a>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <?php if ($token_valid && !$message): ?>
            <form method="POST" id="resetForm">
                <div class="form-group">
                    <label class="form-label">New Password</label>
                    <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        class="form-control" 
                        placeholder="Enter new password (min 8 characters)"
                        required
                        minlength="8"
                    >
                    <i class="fas fa-eye toggle-password" onclick="togglePassword('password')"></i>
                    <div class="password-strength">
                        <div class="password-strength-bar" id="strengthBar"></div>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Confirm Password</label>
                    <input 
                        type="password" 
                        id="confirm_password" 
                        name="confirm_password" 
                        class="form-control" 
                        placeholder="Re-enter new password"
                        required
                    >
                    <i class="fas fa-eye toggle-password" onclick="togglePassword('confirm_password')"></i>
                </div>

                <button type="submit" class="btn-reset">
                    <i class="fas fa-save"></i> Reset Password
                </button>
            </form>

            <div class="back-link">
                <a href="admin_login.php"><i class="fas fa-arrow-left"></i> Back to Login</a>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const icon = field.nextElementSibling;
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                field.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        // Password strength indicator
        const passwordField = document.getElementById('password');
        if (passwordField) {
            passwordField.addEventListener('input', function() {
                const password = this.value;
                const strengthBar = document.getElementById('strengthBar');
                
                let strength = 0;
                if (password.length >= 8) strength++;
                if (password.length >= 12) strength++;
                if (/[A-Z]/.test(password)) strength++;
                if (/[0-9]/.test(password)) strength++;
                if (/[^A-Za-z0-9]/.test(password)) strength++;
                
                strengthBar.className = 'password-strength-bar';
                if (strength <= 2) {
                    strengthBar.classList.add('strength-weak');
                } else if (strength <= 4) {
                    strengthBar.classList.add('strength-medium');
                } else {
                    strengthBar.classList.add('strength-strong');
                }
            });
        }

        // Password match validation
        const resetForm = document.getElementById('resetForm');
        if (resetForm) {
            resetForm.addEventListener('submit', function(e) {
                const password = document.getElementById('password').value;
                const confirmPassword = document.getElementById('confirm_password').value;
                
                if (password !== confirmPassword) {
                    e.preventDefault();
                    alert('❌ Passwords do not match! Please make sure both passwords are the same.');
                    return false;
                }
            });
        }
    </script>
</body>
</html>
