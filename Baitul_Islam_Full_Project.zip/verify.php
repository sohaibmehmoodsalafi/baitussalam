<?php
require 'includes/db.php';
session_start();

$email = $_GET['email'] ?? ($_POST['email'] ?? '');
$type = $_GET['type'] ?? ($_POST['type'] ?? 'student');
$token = $_GET['token'] ?? '';
$redirect = $_GET['redirect'] ?? ($_POST['redirect'] ?? '');

$error_msg = '';
$success_msg = '';

// Handle Direct Token Verification Link
if (!empty($email) && !empty($token)) {
    $table = ($type == 'tutor') ? 'tutors' : 'students';
    $stmt = $pdo->prepare("SELECT * FROM $table WHERE email = ? AND verification_token = ? AND is_verified = 0");
    $stmt->execute([$email, $token]);
    $user = $stmt->fetch();

    if ($user) {
        $stmt = $pdo->prepare("UPDATE $table SET is_verified = 1, verification_token = NULL, verification_code = NULL WHERE id = ?");
        $stmt->execute([$user['id']]);

        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $type;
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['initiated'] = true;
        $_SESSION['user_ip'] = $_SERVER['REMOTE_ADDR'] ?? '';
        $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? '';

        if ($type == 'tutor') {
            $success_msg = "Email verified successfully! Your account is now pending admin approval. You will receive an email once approved.";
            header("refresh:4;url=login.php?type=tutor" . ($redirect ? "&redirect=" . urlencode($redirect) : ""));
        } else {
            $success_msg = "Email verified successfully via direct link!";
            $target = $redirect ? $redirect : "index.php";
            header("refresh:2;url=" . $target);
        }
    } else {
        $error_msg = "Invalid or expired verification link.";
    }
}

// Handle Resend Request
if (isset($_GET['resend'])) {
    $table = ($type == 'tutor') ? 'tutors' : 'students';
    $new_code = rand(100000, 999999);
    $new_token = bin2hex(random_bytes(32));
    
    // Fetch name for email
    $stmt_name = $pdo->prepare("SELECT name FROM $table WHERE email = ?");
    $stmt_name->execute([$email]);
    $user_data = $stmt_name->fetch();
    $user_name = $user_data['name'] ?? 'User';

    // Update DB
    $stmt = $pdo->prepare("UPDATE $table SET verification_code = ?, verification_token = ? WHERE email = ? AND is_verified = 0");
    $stmt->execute([$new_code, $new_token, $email]);
    
    if ($stmt->rowCount() > 0) {
        $base_url = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
        $verify_link = "$base_url/verify.php?email=" . urlencode($email) . "&token=$new_token&type=$type" . ($redirect ? "&redirect=" . urlencode($redirect) : "");

        // Send Email using PHPMailer
        require_once 'includes/verification_email.php';
        echo "<div style='background:#f1f5f9; padding:15px; border-radius:10px; font-size:12px; margin-bottom:20px;'>";
        echo "<strong>Debug Log:</strong> Updating database for $email... ";
        $emailResult = sendVerificationEmail($email, $user_name, $new_code, $verify_link, $type, true);
        echo "</div>";
        
        if ($emailResult['success']) {
            $success_msg = "A new verification link and code have been sent to your email! (Subject: [NEW CODE] ...)";
        } else {
            $error_msg = "Failed to send email. Error: " . $emailResult['message'];
        }
    } else {
        echo "<div class='alert error'>Error: Email address not found or already verified in the database.</div>";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Combine digits from individual inputs
    $code = implode('', $_POST['digit']);
    
    if (strlen($code) < 6) {
        $error_msg = 'Please enter all 6 digits.';
    } else {
        $table = ($type == 'tutor') ? 'tutors' : 'students';
        $stmt = $pdo->prepare("SELECT * FROM $table WHERE email = ? AND verification_code = ?");
        $stmt->execute([$email, $code]);
        $user = $stmt->fetch();
        
        if ($user) {
            // Mark as verified
            $stmt = $pdo->prepare("UPDATE $table SET is_verified = 1, verification_code = NULL WHERE id = ?");
            $stmt->execute([$user['id']]);
            
            session_regenerate_id(true);
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_role'] = $type;
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['initiated'] = true;
            $_SESSION['user_ip'] = $_SERVER['REMOTE_ADDR'] ?? '';
            $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? '';
            
            if ($type == 'tutor') {
                $success_msg = "Email verified successfully! Your account is now pending admin approval. You will receive an email once approved.";
                header("refresh:4;url=login.php?type=tutor" . ($redirect ? "&redirect=" . urlencode($redirect) : ""));
            } else {
                $success_msg = "Account verified successfully! Welcome to Baitul Islam.";
                $target = $redirect ? $redirect : "index.php";
                header("refresh:2;url=" . $target);
            }
        } else {
            $error_msg = 'The code you entered is incorrect. Please check and try again.';
        }
    }
}

include 'includes/header.php';
?>

<div class="container section-padding" style="min-height: 80vh; display: flex; align-items: center; justify-content: center;">
    <div style="max-width: 500px; width: 100%; background: white; padding: 50px; border-radius: 30px; box-shadow: 0 25px 70px rgba(0,0,0,0.07); text-align: center; border: 1px solid #f1f5f9;">
        
        <div style="width: 80px; height: 80px; background: rgba(15, 81, 50, 0.05); color: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 30px; font-size: 2rem;">
            <i class="fas fa-envelope-open-text"></i>
        </div>

        <h2 style="font-family: 'Outfit', sans-serif; font-weight: 800; color: var(--primary); font-size: 2rem; margin-bottom: 10px;">Check your inbox</h2>
        <p style="color: #64748b; font-size: 1.05rem; line-height: 1.6; margin-bottom: 40px;">
            We have sent a 6-digit verification code to <br>
            <strong style="color: var(--primary-dark);"><?php echo htmlspecialchars($email); ?></strong>
        </p>





        <?php if($error_msg): ?>
            <div style="background: #fff1f2; color: #be123c; padding: 15px; border-radius: 12px; margin-bottom: 30px; font-size: 0.95rem; font-weight: 600; border: 1px solid #ffe4e6;">
                <i class="fas fa-exclamation-circle me-2"></i> <?php echo $error_msg; ?>
            </div>
        <?php endif; ?>

        <?php if($success_msg): ?>
            <div style="background: #f0fdf4; color: #15803d; padding: 15px; border-radius: 12px; margin-bottom: 30px; font-size: 0.95rem; font-weight: 600; border: 1px solid #dcfce7;">
                <i class="fas fa-check-circle me-2"></i> <?php echo $success_msg; ?>
            </div>
        <?php endif; ?>

        <form method="POST" id="otp-form">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
            <input type="hidden" name="type" value="<?php echo htmlspecialchars($type); ?>">
            <input type="hidden" name="redirect" value="<?php echo htmlspecialchars($redirect); ?>">
            <div style="display: flex; gap: 12px; justify-content: center; margin-bottom: 40px;">
                <?php for($i = 1; $i <= 6; $i++): ?>
                    <input type="text" name="digit[]" class="otp-input" maxlength="1" required 
                           style="width: 55px; height: 65px; border: 2px solid #e2e8f0; border-radius: 12px; font-size: 1.8rem; text-align: center; font-weight: 800; color: var(--primary); transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); outline: none; background: #f8fafc;">
                <?php endfor; ?>
            </div>

            <button type="submit" class="btn-premium-gold" style="width: 100%; border: none; cursor: pointer;">
                Verify Account
            </button>
        </form>
        
        <div style="margin-top: 35px; border-top: 1px solid #f1f5f9; padding-top: 25px;">
            <p id="resend-text" style="color: #94a3b8; font-size: 0.95rem; font-weight: 500;">
                Didn't receive the code? 
                <span id="timer" style="color: var(--primary); font-weight: 700;">Wait 0:59</span>
            </p>
            <a href="?email=<?php echo urlencode($email); ?>&type=<?php echo $type; ?>&resend=1<?php echo $redirect ? '&redirect=' . urlencode($redirect) : ''; ?>" id="resend-btn" style="display: none; color: var(--primary); font-weight: 700; text-decoration: none; font-size: 0.95rem;">Resend Code</a>
        </div>
    </div>
</div>

<style>
    .otp-input:focus {
        border-color: var(--primary) !important;
        background: white !important;
        box-shadow: 0 0 0 4px rgba(15, 81, 50, 0.1);
        transform: translateY(-2px);
    }
    
    .otp-input.filled {
        border-color: var(--primary);
        background: white;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const inputs = document.querySelectorAll('.otp-input');
    const form = document.getElementById('otp-form');

    inputs.forEach((input, index) => {
        // Handle input
        input.addEventListener('input', (e) => {
            if (e.target.value) {
                input.classList.add('filled');
                if (index < inputs.length - 1) {
                    inputs[index + 1].focus();
                }
            } else {
                input.classList.remove('filled');
            }
        });

        // Handle backspace
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Backspace' && !input.value && index > 0) {
                inputs[index - 1].focus();
            }
        });
        
        // Handle paste
        input.addEventListener('paste', (e) => {
            e.preventDefault();
            const data = e.clipboardData.getData('text').slice(0, 6);
            if (/^\d+$/.test(data)) {
                for (let i = 0; i < data.length; i++) {
                    inputs[i].value = data[i];
                    inputs[i].classList.add('filled');
                }
                if (data.length < 6) {
                    inputs[data.length].focus();
                } else {
                    inputs[5].focus();
                }
            }
        });
    });

    // Simple Timer
    let timeLeft = 59;
    const timerElement = document.getElementById('timer');
    const resendBtn = document.getElementById('resend-btn');
    const resendText = document.getElementById('resend-text');

    const countdown = setInterval(() => {
        if (timeLeft <= 0) {
            clearInterval(countdown);
            timerElement.style.display = 'none';
            resendBtn.style.display = 'inline';
            resendText.innerHTML = "Didn't receive the code? ";
        } else {
            timerElement.innerHTML = `Wait 0:${timeLeft < 10 ? '0' : ''}${timeLeft}`;
            timeLeft--;
        }
    }, 1000);
});
</script>

<?php include 'includes/footer.php'; ?>
