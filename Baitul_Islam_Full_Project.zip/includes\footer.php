    <footer style="background: linear-gradient(rgba(0, 33, 71, 0.98), rgba(0, 33, 71, 0.98)), url('<?php echo $assets_path; ?>images/hero_pattern.png'); background-size: 300px; border-top: 5px solid var(--accent); color: rgba(255,255,255,0.75); padding: 80px 0 40px; font-size: 1rem; width: 100%; position: relative; z-index: 10;">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 40px; margin-bottom: 40px;">
                <!-- Brand -->
                <div style="max-width: 350px;">
                    <img src="<?php echo $assets_path; ?>images/logo.png" alt="Baitul Islam Logo" style="height: 90px; margin-bottom: 25px; filter: brightness(0) invert(1); opacity: 1;">
                    <p style="margin-bottom: 25px; line-height: 1.8; color: rgba(255,255,255,0.7); font-size: 0.95rem;">
                        Baitul Islam is your premier destination for holistic Islamic education, offering specialized programs in Nazra, Hifz, Tajweed, and Tafseer. We are committed to nurturing students’ connection and understanding of Islamic teachings.
                    </p>
                     <div style="display: flex; gap: 15px;">
                        <a href="https://www.facebook.com/peaceinstituteglobal" target="_blank" class="social-icon-footer fb-hover"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://www.instagram.com/peaceinstituteglobal" target="_blank" class="social-icon-footer ig-hover"><i class="fab fa-instagram"></i></a>
                        <a href="https://www.youtube.com/@peaceinstituteglobal" target="_blank" class="social-icon-footer yt-hover"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>

                <!-- Quick Links -->
                <div>
                    <h5 style="color: var(--accent); font-weight: 800; margin-bottom: 30px; font-size: 1.2rem; text-transform: uppercase; letter-spacing: 1px;">Quick Links</h5>
                    <ul style="display: flex; flex-direction: column; gap: 15px; padding: 0; margin: 0; list-style: none;">
                        <li><a href="index.php" class="footer-link">Home</a></li>
                        <li><a href="about.php" class="footer-link">About Us</a></li>
                        <li><a href="courses.php" class="footer-link">Our Courses</a></li>
                        <li><a href="contact.php" class="footer-link">Contact Us</a></li>
                        <li><a href="blog.php" class="footer-link">Blog</a></li>
                    </ul>
                </div>

                <!-- Contact Info -->
                <div>
                    <h5 style="color: var(--accent); font-weight: 800; margin-bottom: 30px; font-size: 1.2rem; text-transform: uppercase; letter-spacing: 1px;">Contact Us</h5>
                    <ul style="display: flex; flex-direction: column; gap: 20px; padding: 0; margin: 0; list-style: none;">
                        <li style="display: flex; gap: 15px; align-items: flex-start;">
                            <i class="fas fa-phone-alt" style="color: var(--accent); margin-top: 5px;"></i>
                            <div>
                                <p style="margin: 0; font-weight: 700; color: white;">Phone</p>
                                <a href="tel:+923022702808" style="color: rgba(255,255,255,0.7); text-decoration: none;">+92-302-270-2808</a>
                            </div>
                        </li>
                        <li style="display: flex; gap: 15px; align-items: flex-start;">
                            <i class="fas fa-envelope" style="color: var(--accent); margin-top: 5px;"></i>
                            <div>
                                <p style="margin: 0; font-weight: 700; color: white;">Email</p>
                                <a href="mailto:info@baitulislam.org" style="color: rgba(255,255,255,0.7); text-decoration: none;">info@baitulislam.org</a>
                            </div>
                        </li>
                        <li style="display: flex; gap: 15px; align-items: flex-start;">
                            <i class="fas fa-map-marker-alt" style="color: var(--accent); margin-top: 5px;"></i>
                            <div>
                                <p style="margin: 0; font-weight: 700; color: white;">Location</p>
                                <span style="color: rgba(255,255,255,0.7);">Gulshan-e-Hadeed Phase 2, Karachi</span>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Bottom Bar -->
            <div style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 30px; display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 20px;" class="footer-bottom">
                <p style="margin: 0; font-size: 0.95rem; color: rgba(255,255,255,0.5);">&copy; <?php echo date('Y'); ?> Baitul Islam. All rights reserved.</p>
                <div style="display: flex; gap: 30px; font-size: 0.95rem;" class="footer-bottom-links">
                     <a href="#" class="footer-link">Privacy Policy</a>
                     <a href="#" class="footer-link">Terms of Service</a>
                     <a href="admin_login.php" class="footer-link" style="color: rgba(255,255,255,0.1); font-size: 0.8rem;">Admin Login</a>
                </div>
            </div>
        </div>
        
        <style>
            .footer-link { color: rgba(255,255,255,0.7); text-decoration: none; transition: all 0.3s ease; }
            .footer-link:hover { color: var(--accent); padding-left: 5px; }
            .social-icon-footer { 
                width: 40px; height: 40px; 
                background: rgba(255,255,255,0.08); 
                color: rgba(255,255,255,0.8);
                display: flex; align-items: center; justify-content: center; 
                border-radius: 50%; 
                text-decoration: none;
                transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
                font-size: 1.1rem;
            }
            .social-icon-footer:hover { color: white; transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.3); }
            
            .fb-hover:hover { background: #1877F2 !important; }
            .ig-hover:hover { background: linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%) !important; }
            .yt-hover:hover { background: #FF0000 !important; }
        </style>
    </footer>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Main JS -->
    <script src="<?php echo $assets_path; ?>js/main.js"></script>
</body>
</html>
