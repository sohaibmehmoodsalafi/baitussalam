<?php
require 'includes/db.php';
session_start();

if (!isset($_GET['title'])) {
    header("Location: courses.php");
    exit;
}

$title = urldecode($_GET['title']);
$title = urldecode($_GET['title']);

// Fetch course details (description, benefits, banner) from ONE instance to show as the general "About" info
$stmt = $pdo->prepare("SELECT * FROM courses WHERE title = ? AND status = 'approved' LIMIT 1");
$stmt->execute([$title]);
$course_info = $stmt->fetch();

if (!$course_info) {
    header("Location: courses.php");
    exit;
}

// Fetch Tutors offering this course
$stmt = $pdo->prepare("SELECT courses.*, tutors.name as tutor_name, tutors.image as tutor_image, tutors.rating as tutor_rating, tutors.country, tutors.bio as tutor_bio FROM courses JOIN tutors ON courses.tutor_id = tutors.id WHERE courses.title = ? AND courses.status = 'approved'");
$stmt->execute([$title]);
$tutors = $stmt->fetchAll();

include 'includes/header.php';
?>

<!-- Hero Banner for Course Subject -->
<div class="course-subject-banner" style="
    background: linear-gradient(to bottom, rgba(8, 47, 29, 0.9), rgba(8, 47, 29, 0.95)), url('assets/images/feature_class.png');
    background-size: cover;
    background-position: center;
    color: #ffffff;
    padding: 120px 0 80px;
    text-align: center;
    position: relative;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
">
    <div class="container">
        <span style="background: rgba(255,255,100,0.15); border: 1px solid rgba(255,255,255,0.2); backdrop-filter: blur(5px); color: #FFD700; padding: 6px 18px; border-radius: 30px; text-transform: uppercase; font-size: 0.85rem; letter-spacing: 2px; font-weight: 700; display: inline-block; margin-bottom: 25px;">
            Premium Online Course
        </span>
        <h1 style="font-size: 3.5rem; margin-bottom: 25px; font-weight: 800; color: #ffffff; text-shadow: 0 2px 4px rgba(0,0,0,0.3); letter-spacing: -1px; line-height: 1.2;">
            <?php echo htmlspecialchars($title); ?>
        </h1>
        <p style="font-size: 1.25rem; max-width: 750px; margin: 0 auto 30px; color: rgba(255,255,255,0.95); font-weight: 400; line-height: 1.8; text-shadow: 0 1px 2px rgba(0,0,0,0.2);">
            <?php echo htmlspecialchars(substr($course_info['description'], 0, 180)); ?>...
        </p>
    </div>
</div>

<div class="container section-padding">
    
    <!-- About This Course Section -->
    <div style="margin-bottom: 60px;">
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 40px;">
            <div>
                <h2 style="color: var(--primary); margin-bottom: 20px;">About This Course</h2>
                <p style="font-size: 1.05rem; line-height: 1.8; color: #555; margin-bottom: 30px;">
                    <?php echo nl2br(htmlspecialchars($course_info['description'])); ?>
                </p>
                
                <?php if (!empty($course_info['benefits'])): ?>
                <h3 style="font-size: 1.3rem; margin-bottom: 15px;">What You Will Learn</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                     <?php 
                        $benefits = explode("\n", $course_info['benefits']);
                        foreach($benefits as $b) {
                            if(trim($b)) echo '<div style="display: flex; align-items: flex-start;"><i class="fas fa-check" style="color: var(--accent); margin-top: 5px; margin-right: 10px;"></i> <span>'.htmlspecialchars($b).'</span></div>';
                        }
                     ?>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Side Quick Stats -->
            <div style="background: #f8f9fa; padding: 30px; border-radius: 12px; height: fit-content;">
                <h3 style="font-size: 1.2rem; margin-bottom: 20px;">Course Features</h3>
                <ul style="list-style: none; padding: 0;">
                    <li style="margin-bottom: 15px; display: flex; align-items: center; color: #555;">
                        <i class="fas fa-video" style="width: 30px; color: var(--accent); font-size: 1.2rem;"></i>
                        <span>Live Video Sessions</span>
                    </li>
                    <li style="margin-bottom: 15px; display: flex; align-items: center; color: #555;">
                        <i class="fas fa-user-friends" style="width: 30px; color: var(--accent); font-size: 1.2rem;"></i>
                        <span>One-on-One Tutoring</span>
                    </li>
                    <li style="margin-bottom: 15px; display: flex; align-items: center; color: #555;">
                        <i class="fas fa-globe" style="width: 30px; color: var(--accent); font-size: 1.2rem;"></i>
                        <span>Access Anywhere</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Available Tutors Section -->
    <div style="text-align: center; margin-bottom: 40px;">
        <h2 style="font-size: 2rem; color: var(--primary);">Available Tutors</h2>
        <p style="color: #666;">Choose from our expert instructors for this course.</p>
    </div>

    <?php if (empty($tutors)): ?>
        <div style="text-align: center; padding: 40px;">
            <p>No tutors currently available for this course.</p>
            <a href="courses.php" class="btn btn-primary">Browse All Courses</a>
        </div>
    <?php else: ?>
        <div class="courses-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px;">
            <?php foreach($tutors as $course): ?>
                <div class="course-card glass-card" style="display: flex; flex-direction: column; overflow: hidden; background: white; border-radius: 10px; box-shadow: var(--shadow-sm); transition: transform 0.3s;">
                    <div style="padding: 25px; text-align: center; border-bottom: 1px solid #eee;">
                        <img src="<?php echo htmlspecialchars($course['tutor_image']); ?>" alt="Tutor" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover; margin-bottom: 15px; border: 3px solid #f8f9fa;">
                        <h3 style="margin: 0; font-size: 1.2rem; color: #333;"><?php echo htmlspecialchars($course['tutor_name']); ?></h3>
                        <p style="color: #666; font-size: 0.9rem; margin: 5px 0 10px;"><?php echo htmlspecialchars($course['country']); ?></p>
                        <div style="color: #ffc107; font-size: 0.9rem;">
                            <i class="fas fa-star"></i> <?php echo $course['tutor_rating']; ?>/5.0
                        </div>
                    </div>
                    
                    <div style="padding: 20px; flex-grow: 1;">
                        <p style="color: #555; font-size: 0.95rem; line-height: 1.6; text-align: center; margin-bottom: 0;">
                            "<?php echo htmlspecialchars(substr($course['description'], 0, 80)); ?>..."
                        </p>
                    </div>

                    <div style="padding: 20px; background: #fafafa; border-top: 1px solid #eee; display: flex; justify-content: space-between; align-items: center;">
                        <div>
                             <span style="display: block; font-size: 0.8rem; color: #666;">Course Fee</span>
                             <span style="font-size: 1.3rem; font-weight: 800; color: var(--primary);">$<?php echo number_format($course['price'], 0); ?></span>
                        </div>
                        <a href="course_details.php?id=<?php echo $course['id']; ?>" class="btn btn-primary" style="padding: 10px 25px; border-radius: 50px;">Select Tutor</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
