<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require_once 'includes/db.php';
include 'includes/header.php'; 

// Get dynamic room and course ID
$roomName = $_GET['room'] ?? "PeaceInstitute_Global_Room";
$course_id = 0;
// Extract course ID from room name if possible (format: PeaceRoom_ID_HASH)
if (preg_match('/PeaceRoom_(\d+)_/', $roomName, $matches)) {
    $course_id = $matches[1];
}

$userName = $_SESSION['user_name'] ?? 'User';
$userRole = $_SESSION['user_role'] ?? 'student';
$isTutor = ($userRole === 'tutor');
?>

<div class="container" style="padding: 120px 0 60px;">
    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 30px; border-bottom: 1px solid #eee; padding-bottom: 20px;">
        <div>
            <h1 style="font-family: 'Outfit', sans-serif; font-weight: 800; color: var(--primary); margin: 0; font-size: 2.2rem;">
                <?php echo $isTutor ? 'Teaching Terminal' : 'Student Learning Portal'; ?>
            </h1>
            <p style="color: var(--text-muted); margin: 5px 0 0; font-weight: 600;">
                <i class="fas fa-circle" style="color: #28a745; font-size: 0.7rem; margin-right: 5px; animation: pulse 2s infinite;"></i> 
                Session Active: <span style="color: var(--primary-dark);"><?php echo str_replace('_', ' ', $roomName); ?></span>
            </p>
        </div>
        <div style="text-align: right;">
            <a href="<?php echo $isTutor ? 'tutor_dashboard.php' : 'student_dashboard.php'; ?>" class="btn btn-outline" style="border: 2px solid #eee; padding: 10px 20px; border-radius: 10px; font-weight: 700; color: var(--text-dark);">
                <i class="fas fa-arrow-left me-2"></i> Exit Class
            </a>
        </div>
    </div>

    <!-- Video Container -->
    <div class="classroom-layout" style="display: flex; gap: 25px; align-items: start;">
        
        <div class="video-section" style="flex: 3; width: 100%;">
            <div class="video-wrapper" style="position: relative; width: 100%; height: 600px; background: #0f172a; border-radius: 20px; overflow: hidden; box-shadow: 0 20px 50px rgba(0,0,0,0.1); border: 1px solid #1e293b;">
                <div id="meet" style="width: 100%; height: 100%;"></div>
            </div>
            
            <?php if ($isTutor): ?>
            <div class="video-controls" style="margin-top: 25px; display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; background: #f8fafc; padding: 20px; border-radius: 15px; border: 1px solid #f1f5f9;">
                 <button onclick="api.executeCommand('toggleShareScreen')" class="btn" style="background: #2563eb; color: white; padding: 12px; border-radius: 10px; font-weight: 700;">
                    <i class="fas fa-desktop me-2"></i> Share Screen
                 </button>
                 <button onclick="api.executeCommand('muteEveryone')" class="btn" style="background: #e11d48; color: white; padding: 12px; border-radius: 10px; font-weight: 700;">
                    <i class="fas fa-microphone-slash me-2"></i> Mute All
                 </button>
                 <button onclick="api.executeCommand('toggleTileView')" class="btn" style="background: #475569; color: white; padding: 12px; border-radius: 10px; font-weight: 700;">
                    <i class="fas fa-th-large me-2"></i> Grid view
                 </button>
                 <button onclick="api.executeCommand('toggleChat')" class="btn" style="background: var(--primary); color: white; padding: 12px; border-radius: 10px; font-weight: 700;">
                    <i class="fas fa-comments me-2"></i> Open Chat
                 </button>
            </div>
            <?php endif; ?>
        </div>

        <?php if ($isTutor): 
            // Fetch students enrolled in THIS specific course
            $enrolled_students = [];
            if ($course_id > 0) {
                try {
                    $stmt = $pdo->prepare("SELECT s.name, s.email FROM students s JOIN enrollments e ON s.id = e.student_id WHERE e.course_id = ? AND e.payment_status = 'paid'");
                    $stmt->execute([$course_id]);
                    $enrolled_students = $stmt->fetchAll(PDO::FETCH_ASSOC);
                } catch (Exception $e) {}
            }
        ?>
        <div class="sidebar" style="flex: 1; min-width: 320px; background: white; padding: 25px; border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.03); border: 1px solid #f1f5f9; height: 600px; display: flex; flex-direction: column;">
            <h3 style="font-family: 'Outfit', sans-serif; font-weight: 800; font-size: 1.2rem; color: var(--primary); margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-users-viewfinder"></i> Live Roster
            </h3>
            
            <div style="margin-bottom: 20px; display: flex; gap: 10px;">
                <div style="flex: 1; background: #f0fdf4; padding: 10px; border-radius: 10px; text-align: center;">
                    <span style="display: block; font-size: 0.7rem; color: #166534; font-weight: 800; text-transform: uppercase;">Present</span>
                    <span id="present-count" style="font-size: 1.2rem; font-weight: 900; color: #166534;">0</span>
                </div>
                <div style="flex: 1; background: #fff1f2; padding: 10px; border-radius: 10px; text-align: center;">
                    <span style="display: block; font-size: 0.7rem; color: #991b1b; font-weight: 800; text-transform: uppercase;">Absent</span>
                    <span id="absent-count" style="font-size: 1.2rem; font-weight: 900; color: #991b1b;"><?php echo count($enrolled_students); ?></span>
                </div>
            </div>

            <div style="flex: 1; overflow-y: auto; padding-right: 5px;">
                <ul id="student-list" style="padding: 0; list-style: none;">
                    <?php if(empty($enrolled_students)): ?>
                        <li style="text-align: center; color: #94a3b8; font-size: 0.9rem; padding: 40px 0;">No students enrolled in this course session.</li>
                    <?php else: ?>
                        <?php foreach($enrolled_students as $student): ?>
                            <li id="student-<?php echo md5($student['name']); ?>" class="student-item absent" style="margin-bottom: 12px; padding: 12px; border-radius: 12px; background: #f8fafc; border: 1px solid #f1f5f9; display: flex; align-items: center; justify-content: space-between; transition: 0.3s;">
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <div class="avatar-mini" style="width: 35px; height: 35px; border-radius: 8px; background: #e2e8f0; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 0.8rem; color: #64748b;">
                                        <?php echo strtoupper(substr($student['name'], 0, 1)); ?>
                                    </div>
                                    <div>
                                        <span style="display: block; font-weight: 700; color: #1e293b; font-size: 0.9rem;"><?php echo htmlspecialchars($student['name']); ?></span>
                                        <span style="font-size: 0.75rem; color: #94a3b8;" class="status-text">Away</span>
                                    </div>
                                </div>
                                <i class="status-icon fas fa-circle" style="color: #cbd5e1; font-size: 0.6rem;"></i>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>

            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #f1f5f9;">
                <p style="font-size: 0.75rem; color: #94a3b8; font-weight: 600; text-align: center;">Automatically tracking attendance via Jitsi API</p>
            </div>
        </div>
        <?php endif; ?>
        
    </div>
</div>

<style>
    @keyframes pulse {
        0% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.2); opacity: 0.5; }
        100% { transform: scale(1); opacity: 1; }
    }
    .student-item.present {
        background: #f0fdf4 !important;
        border-color: #bbf7d0 !important;
    }
    .student-item.present .avatar-mini {
        background: var(--primary) !important;
        color: white !important;
    }

    /* Responsive Classroom Syles */
    @media (max-width: 991px) {
        .classroom-layout {
            flex-direction: column !important;
            gap: 20px !important;
        }
        .video-section {
            width: 100% !important;
            flex: none !important;
        }
        .video-wrapper {
            height: 500px !important;
        }
        .sidebar {
            width: 100% !important;
            min-width: 100% !important;
            height: auto !important;
            max-height: 400px;
        }
        .video-controls {
            grid-template-columns: repeat(2, 1fr) !important;
        }
        .video-controls button {
            font-size: 0.85rem;
            padding: 10px 8px !important;
        }
    }
    @media (max-width: 576px) {
        h1 { font-size: 1.4rem !important; }
        .container { padding-top: 90px !important; padding-bottom: 20px !important; }
        .video-wrapper { 
            height: 350px !important; 
            border-radius: 15px !important; 
        }
        .sidebar { padding: 15px !important; }
        .video-controls { grid-template-columns: 1fr !important; }
        .video-controls button { width: 100% !important; }
    }
    /* Mobile Landscape Optimization */
    @media (max-height: 500px) and (orientation: landscape) {
        .video-wrapper { height: 80vh !important; }
        .sidebar { display: none !important; }
    }
</style>

<script src='https://8x8.vc/vpaas-magic-cookie-83344b1c28c848529cb58616142c56a5/external_api.js'></script>
<script>
    const domain = '8x8.vc';
    const toolbarButtons = <?php echo $isTutor 
        ? "['microphone', 'camera', 'closedcaptions', 'desktop', 'fullscreen', 'fodeviceselection', 'hangup', 'profile', 'chat', 'recording', 'livestreaming', 'etherpad', 'sharedvideo', 'settings', 'raisehand', 'videoquality', 'filmstrip', 'tileview', 'stats', 'mute-everyone', 'security']" 
        : "['microphone', 'camera', 'desktop', 'fullscreen', 'chat', 'raisehand', 'tileview', 'hangup', 'profile']"; 
    ?>;

    const options = {
        roomName: '<?php echo $roomName; ?>', 
        width: '100%',
        height: '100%',
        parentNode: document.querySelector('#meet'),
        userInfo: {
            displayName: '<?php echo addslashes($userName) . ($isTutor ? " (Tutor)" : ""); ?>'
        },
        configOverwrite: {
            startWithAudioMuted: false, 
            startWithVideoMuted: false,
            disable1On1Mode: false,
            mobileAppProto: 'mailto:', // Prevent mobile app redirect
            disableDeepLinking: true,   // Stay in browser on mobile
            <?php if (!$isTutor): ?>
            remoteVideoMenu: { disableKick: true, disableGrantModerator: true },
            disableRemoteMute: true,
            <?php endif; ?>
        },
        interfaceConfigOverwrite: { 
            SHOW_JITSI_WATERMARK: false, 
            TOOLBAR_BUTTONS: toolbarButtons,
            APP_NAME: 'Peace Institute Live'
        }
    };
    const api = new JitsiMeetExternalAPI(domain, options);
    let sessionID = 0;

    <?php if ($isTutor): ?>
    // Log Session Start
    fetch('api/log_session.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=start&course_id=<?php echo $course_id; ?>'
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) sessionID = data.session_id;
    });

    // Log Session End on close
    window.addEventListener('beforeunload', () => {
        if (sessionID > 0) {
            const body = `action=end&session_id=${sessionID}`;
            navigator.sendBeacon('api/log_session.php', body);
        }
    });
    <?php endif; ?>
    
    api.addEventListeners({
        readyToClose: function () {
            <?php if ($isTutor): ?>
            if (sessionID > 0) {
                fetch('api/log_session.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `action=end&session_id=${sessionID}`
                }).finally(() => {
                    window.location.href = 'tutor_dashboard.php';
                });
            } else {
                window.location.href = 'tutor_dashboard.php';
            }
            <?php else: ?>
            window.location.href = 'student_dashboard.php';
            <?php endif; ?>
        },
        <?php if ($isTutor): ?>
        participantJoined: function(participant) { updateAttendance(participant, true); },
        participantLeft: function(participant) { updateAttendance(participant, false); }
        <?php endif; ?>
    });

    <?php if ($isTutor): ?>
    function updateAttendance(participant, isJoining) {
        const name = participant.displayName ? participant.displayName.replace(' (Tutor)', '').trim() : '';
        if (!name) return;
        
        const listItems = document.querySelectorAll('.student-item');
        let totalPresent = 0;

        listItems.forEach(item => {
            const studentName = item.querySelector('span').innerText.trim();
            if (name.toLowerCase() === studentName.toLowerCase() || name.includes(studentName) || studentName.includes(name)) {
                 if (isJoining) {
                     item.classList.add('present');
                     item.classList.remove('absent');
                     item.querySelector('.status-text').innerText = 'In Class';
                     item.querySelector('.status-text').style.color = '#166534';
                     item.querySelector('.status-icon').style.color = '#22c55e';
                 } else {
                     item.classList.remove('present');
                     item.classList.add('absent');
                     item.querySelector('.status-text').innerText = 'Left';
                     item.querySelector('.status-text').style.color = '#94a3b8';
                     item.querySelector('.status-icon').style.color = '#cbd5e1';
                 }
            }
            if (item.classList.contains('present')) totalPresent++;
        });

        document.getElementById('present-count').innerText = totalPresent;
        document.getElementById('absent-count').innerText = listItems.length - totalPresent;
    }
    <?php endif; ?>
</script>

<?php include 'includes/footer.php'; ?>
