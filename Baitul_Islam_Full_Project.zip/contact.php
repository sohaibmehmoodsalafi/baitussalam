<?php 
require 'includes/db.php';
require 'includes/send_email.php';
include 'includes/header.php'; 

$message_sent = false;
$error_msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = htmlspecialchars($_POST['first_name'] ?? '');
    $last_name = htmlspecialchars($_POST['last_name'] ?? '');
    $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
    $subject = htmlspecialchars($_POST['subject'] ?? '');
    $message = htmlspecialchars($_POST['message'] ?? '');

    if($pdo && $email && $message) {
        try {
            $stmt = $pdo->prepare("INSERT INTO inquiries (first_name, last_name, email, message) VALUES (?, ?, ?, ?)");
            $stmt->execute([$first_name, $last_name, $email, $message]);
            
            // Send Email Notification to Admin
            $admin_subject = "New Contact Form Inquiry: " . $subject;
            $admin_body = "
                <h2>New Inquiry from Baitul Islam Contact Form</h2>
                <p><strong>Name:</strong> $first_name $last_name</p>
                <p><strong>Email:</strong> $email</p>
                <p><strong>Subject:</strong> " . ($subject ?: 'General Inquiry') . "</p>
                <p><strong>Message:</strong><br>" . nl2br(htmlspecialchars($message)) . "</p>
                <hr>
                <p>This inquiry has also been saved to the database.</p>
            ";
            
            // Define ORG_EMAIL if not defined
            $to_email = defined('ORG_EMAIL') ? ORG_EMAIL : 'info@baitulislam.org';
            sendEmail($to_email, $admin_subject, $admin_body);
            
            $message_sent = true;
        } catch(PDOException $e) {
            $error_msg = "Error: " . $e->getMessage();
        }
    } else {
        $error_msg = "Please fill in all required fields.";
    }
}
?>

<!-- Contact Page Banner (Premium Style) -->
<section class="page-banner-premium">
    <div class="container">
        <div class="page-header-divider"></div>
        <h1 class="section-title">Contact Us</h1>
        <nav>
            <ol class="breadcrumb-hijra">
                <li><a href="index.php">Baitul Islam</a></li>
                <li style="opacity: 0.5;">/</li>
                <li>Contact</li>
            </ol>
        </nav>
    </div>
</section>

<!-- Contact Content Section -->
<section style="background: #ffffff; padding: 80px 0;">
    <div class="container">
        <div class="row g-5">
            <!-- Left Column: Contact Info -->
            <div class="col-lg-4">
                <div class="contact-info-hijra">
                    
                    <div class="info-block mb-4">
                        <div class="info-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="info-content">
                            <h5>Address</h5>
                            <p>Plot 24, Allahwala Town - Sector 31B Allah Wala Town Sector 31 B Korangi, Karachi, Karachi City, Sindh</p>
                        </div>
                    </div>

                    <div class="info-block mb-4">
                        <div class="info-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="info-content">
                            <h5>E-mail</h5>
                            <p><a href="mailto:info@baitulislam.org">info@baitulislam.org</a></p>
                        </div>
                    </div>

                    <div class="info-block mb-4">
                        <div class="info-icon">
                            <i class="fas fa-phone"></i>
                        </div>
                        <div class="info-content">
                            <h5>Phone</h5>
                            <p><a href="tel:+923022702808">+92-302-270-2808</a></p>
                        </div>
                    </div>

                    <div class="info-block">
                        <div class="info-icon">
                            <i class="fas fa-share-alt"></i>
                        </div>
                        <div class="info-content">
                            <h5>Find Us On</h5>
                            <div class="social-links-contact">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a>
                                <a href="#"><i class="fab fa-youtube"></i></a>
                                <a href="#"><i class="fab fa-linkedin-in"></i></a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Right Column: Form -->
            <div class="col-lg-8">
                <div class="contact-form-hijra-container">
                    <h2 style="font-weight: 800; margin-bottom: 30px; color: #222;">Contact Us</h2>
                    
                    <?php if($message_sent): ?>
                        <div class="alert alert-success py-3 px-4 mb-4" style="border-radius: 8px;">
                            <i class="fas fa-check-circle me-2"></i> Message Sent Successfully!
                        </div>
                    <?php endif; ?>

                    <?php if($error_msg): ?>
                        <div class="alert alert-danger py-3 px-4 mb-4" style="border-radius: 8px;">
                            <i class="fas fa-exclamation-circle me-2"></i> <?php echo htmlspecialchars($error_msg); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="contact.php" class="needs-validation" novalidate>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">First Name: <span class="text-danger">*</span></label>
                                <input type="text" name="first_name" class="form-control" required>
                                <div class="invalid-feedback">This field is required.</div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Last Name: <span class="text-danger">*</span></label>
                                <input type="text" name="last_name" class="form-control" required>
                                <div class="invalid-feedback">This field is required.</div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Email: <span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control" required>
                                <div class="invalid-feedback">This field is required.</div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Subject:</label>
                                <input type="text" name="subject" class="form-control">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Message: <span class="text-danger">*</span></label>
                                <textarea name="message" class="form-control" rows="6" required></textarea>
                                <div class="invalid-feedback">This field is required.</div>
                            </div>
                            <div class="col-12 mt-4 text-center">
                                <button type="submit" class="contact-btn-submit">Submit Application</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Google Map Section -->
<section style="height: 450px; width: 100%;">
    <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d115865.1760000000!2d67.10645!3d24.8465!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb33a9000000000%3A0x0!2sPlot%2024%2C%20Allahwala%20Town%20-%20Sector%2031B%20Korangi%2C%20Karachi!5e0!3m2!1sen!2s!4v1700000000000!5m2!1sen!2s" 
        width="100%" 
        height="100%" 
        style="border:0;" 
        allowfullscreen="" 
        loading="lazy" 
        referrerpolicy="no-referrer-when-downgrade">
    </iframe>
</section>


<style>
    /* Contact Info Styling */
    .info-block {
        display: flex;
        gap: 20px;
        align-items: flex-start;
    }
    .info-icon {
        width: 50px;
        height: 50px;
        background: #f8f9fa;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        font-size: 1.2rem;
        flex-shrink: 0;
        border: 1px solid #eee;
    }
    .info-content h5 {
        font-weight: 700;
        font-size: 1.1rem;
        margin-bottom: 5px;
        color: #333;
    }
    .info-content p, .info-content a {
        color: #666;
        text-decoration: none;
        line-height: 1.6;
    }
    .social-links-contact {
        display: flex;
        gap: 15px;
        margin-top: 10px;
    }
    .social-links-contact a {
        width: 35px;
        height: 35px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f8f9fa;
        color: #444;
        border-radius: 4px;
        border: 1px solid #ddd;
        transition: 0.3s;
    }
    .social-links-contact a:hover {
        background: var(--primary);
        color: white;
        border-color: var(--primary);
    }

    /* Form Styling */
    .contact-form-hijra-container .form-label {
        font-weight: 600;
        color: #333;
        margin-bottom: 8px;
    }
    .contact-form-hijra-container .form-control {
        border-radius: 4px;
        border: 1px solid #ced4da;
        padding: 12px;
    }
    .contact-btn-submit {
        background: var(--primary);
        color: white;
        border: none;
        padding: 15px 40px;
        border-radius: 5px;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 0.95rem;
        transition: 0.3s;
    }
    .contact-btn-submit:hover {
        background: #0d2c6c;
        transform: translateY(-2px);
    }
</style>

<script>
// Bootstrap validation
(function () {
  'use strict'
  var forms = document.querySelectorAll('.needs-validation')
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }
        form.classList.add('was-validated')
      }, false)
    })
})()
</script>

<?php include 'includes/footer.php'; ?>
