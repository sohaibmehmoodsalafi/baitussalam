<?php 
require 'includes/db.php';
include 'includes/header.php'; 

// Home page styled instructors data
$home_instructors = [
    ['name' => 'Shaykh Abdullah Nasir Rehmani', 'role' => 'Founder', 'img' => 'assets/images/sheikh_abdullah.png'],
    ['name' => 'Shaykh Usman Safder', 'role' => 'CEO & Co-Founder', 'img' => 'https://hijraonline.com/wp-content/uploads/2021/09/avatar_user_16_1631194592.jpg'],
    ['name' => 'Shaykh Abdullah Shamim', 'role' => 'Deputy CEO & Instructor', 'img' => 'https://hijraonline.com/wp-content/uploads/2024/03/avatar_user_17_1709817818-360x360.jpg'],
    ['name' => 'Shaykh Kamran Yaseen', 'role' => 'Senior Instructor', 'img' => 'https://hijraonline.com/wp-content/uploads/2021/09/avatar_user_19_1631112407.jpg'],
    ['name' => 'Shaykh Jamshed Sultan', 'role' => 'Instructor', 'img' => 'https://hijraonline.com/wp-content/uploads/2024/03/avatar_user_18_1709826687-360x360.jpg'],
    ['name' => 'Shaykh Obaid-ur-Rehman Muhammadi', 'role' => 'Senior Scholar', 'img' => 'https://hijraonline.com/wp-content/uploads/2024/03/avatar_user_20_1709818169-360x360.jpg'],
    ['name' => 'Shaykh Badi-ud-Din Abdullah', 'role' => 'Senior Instructor', 'img' => 'https://hijraonline.com/wp-content/uploads/2021/09/avatar_user_21_1631112310.jpg'],
    ['name' => 'Shaykh Taha Pasha', 'role' => 'Islamic Scholar', 'img' => 'https://hijraonline.com/wp-content/uploads/2021/09/avatar_user_22_1631112468.jpg']
];
?>

<!-- About Page Banner (Premium Style) -->
<section class="page-banner-premium">
    <div class="container">
        <div class="page-header-divider"></div>
        <h1 class="section-title">About Us</h1>
        <nav>
            <ol class="breadcrumb-hijra">
                <li><a href="index.php">Baitul Islam</a></li>
                <li style="opacity: 0.5;">/</li>
                <li>About Us</li>
            </ol>
        </nav>
    </div>
</section>

<!-- Main About Content -->
<section style="background: #ffffff; padding: 80px 0; overflow: hidden;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                
                <!-- Who We Are (Animation: Slide from Left) -->
                <div class="about-card-hijra mb-5" data-aos="slide-right" data-aos-duration="1000">
                    <h2 class="about-header-hijra">Who We Are</h2>
                    <div class="about-body-hijra">
                        <p><strong>Baitul Islam Online:</strong> Founded by highly respected scholars, we are an online institute comprised of certified experienced faculty providing online Islamic education all over the world. Our platform is dedicated to preserving the rich heritage of Islamic knowledge while making it accessible through modern digital tools.</p>
                        <p>We believe in spreading the message of Islam with moderation and wisdom. Our curriculum is designed to cater to students of all levels, from beginners to those seeking advanced scholarly expertise.</p>
                    </div>
                </div>

                <!-- Baitul Islam University Info (Animation: Slide from Left) -->
                <div class="about-card-hijra mb-5" data-aos="slide-right" data-aos-duration="1000">
                    <h2 class="about-header-hijra">Baitul Islam</h2>
                    <div class="about-body-hijra">
                        <p>To spread the knowledge of Qur’an and Sunnah to all through the use of latest technology. Our mission is to provide authentic knowledge of Deen (that is based on Qur’an and Sunnah alone) to those individuals who are unable to acquire it due to personal commitment or reason. Our goal is to provide high standard of education in the comfort of their homes with the use of the latest methods in technology.</p>
                    </div>
                </div>

                <!-- What We Do (Animation: Slide from Top) -->
                <div class="about-card-hijra mb-5" data-aos="slide-down" data-aos-duration="1000">
                    <h2 class="about-header-hijra">What We Do</h2>
                    <div class="about-body-hijra">
                        <p>Baitul Islam online institute aims to provide Islamic education to those people who couldn’t get this education before due to other commitments, busy schedule or lack of opportunities. At our institute, we’re also working to make your wish of becoming an Islamic scholar come true. With our 5 years (10 semesters) comprehensive Islamic course it is now possible.</p>
                        <p>We are also offering customized/ personalized certificate courses in which you can choose one or more Islamic subjects as per your interest such as Hadith, Tafseer, Fiqh, Arabic grammar etc and get a certificate by completing the course of your choice.</p>
                    </div>
                </div>

                <!-- How we do it? (Animation: Slide from Left) -->
                <div class="about-card-hijra mb-5" data-aos="slide-right" data-aos-duration="1000">
                    <h2 class="about-header-hijra">How we do it?</h2>
                    <div class="about-body-hijra">
                        <p>All the courses being offered at our institute are in the form of recorded video lectures in HD quality and multimedia presentation by highly qualified and respected scholars. For providing further comfort and ease to the learners all the lectures all available with English subtitles. Moreover, these courses are being provided through e-learning platform through which learners can access them from their laptops, iPads, mobile phones or any other smart device at any time.</p>
                    </div>
                </div>

                <!-- Who can learn? (Animation: Slide from Right) -->
                <div class="about-card-hijra" data-aos="slide-left" data-aos-duration="1000">
                    <h2 class="about-header-hijra">Who can learn/ join/ apply?</h2>
                    <div class="about-body-hijra">
                        <p>All the courses being offered at Baitul Islam institute can be availed by men and women of any age all across the globe from the very comfort of their homes.</p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<!-- Instructors Section (Hijra Inspired Slider/Grid) -->
<section style="background: #ffffff; padding: 120px 0; overflow: hidden;">
    <div class="container">
        <div class="text-center mb-5" data-aos="fade-down" data-aos-duration="1000">
            <h4 style="color: var(--accent); font-weight: 700; text-transform: uppercase; letter-spacing: 2px; font-size: 1rem; margin-bottom: 10px;">Our Leadership</h4>
            <h2 style="font-size: 3rem; font-weight: 800; color: #031b4e; font-family: 'Outfit', sans-serif;">Our Skilled Instructors</h2>
            <div style="width: 80px; height: 4px; background: #ecc53d; margin: 15px auto;"></div>
        </div>

        <div class="row g-5 justify-content-center">
            <?php foreach($home_instructors as $tutor): ?>
                <div class="col-lg-3 col-md-4 col-sm-6" data-aos="zoom-in" data-aos-duration="800">
                    <div class="instructor-card-hijra-v2">
                        <div class="instructor-img-wrapper">
                            <img src="<?php echo htmlspecialchars($tutor['img']); ?>" alt="Instructor">
                            <div class="instructor-overlay-hijra">
                                <div class="instructor-socials-hijra">
                                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="instructor-details-hijra">
                            <h3><?php echo htmlspecialchars($tutor['name']); ?></h3>
                            <p><?php echo htmlspecialchars($tutor['role'] ?? 'Instructor'); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<style>
    /* Content Elements */
    .about-card-hijra {
        background: white;
        margin-bottom: 40px;
        transition: 0.3s;
    }
    .about-header-hijra {
        font-size: 1.8rem;
        font-weight: 800;
        color: #031b4e;
        margin-bottom: 20px;
        border-left: 5px solid #ecc53d;
        padding-left: 15px;
    }
    .about-body-hijra p {
        font-size: 1.1rem;
        line-height: 1.8;
        color: #555;
        margin-bottom: 15px;
        text-align: justify;
    }

    /* Instructor Cards V2 */
    .instructor-card-hijra-v2 {
        background: white;
        text-align: center;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        position: relative;
        margin-bottom: 20px;
    }
    .instructor-img-wrapper {
        position: relative;
        width: 100%;
        height: 320px;
        overflow: hidden;
        margin-bottom: 20px;
        border: 1px solid #eee;
    }
    .instructor-img-wrapper img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.6s ease;
    }
    .instructor-overlay-hijra {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(3, 27, 78, 0.85);
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0;
        transition: all 0.4s ease;
    }
    .instructor-card-hijra-v2:hover .instructor-overlay-hijra {
        opacity: 1;
    }
    .instructor-card-hijra-v2:hover img {
        transform: scale(1.15);
    }
    .instructor-socials-hijra {
        display: flex;
        gap: 15px;
        transform: translateY(20px);
        transition: all 0.4s ease;
    }
    .instructor-card-hijra-v2:hover .instructor-socials-hijra {
        transform: translateY(0);
    }
    .instructor-socials-hijra a {
        width: 40px;
        height: 40px;
        background: var(--accent);
        color: #031b4e;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        transition: 0.3s;
    }
    .instructor-socials-hijra a:hover {
        background: white;
        transform: rotate(360deg);
    }
    .instructor-details-hijra h3 {
        font-size: 1.2rem;
        font-weight: 800;
        color: #031b4e;
        margin-bottom: 5px;
    }
    .instructor-details-hijra p {
        font-size: 0.9rem;
        color: #C08D3D;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1px;
    }

    /* Overall Layout */
    @media (max-width: 768px) {
        .about-header-hijra {
            font-size: 1.4rem;
        }
        .instructor-img-wrapper {
            height: 280px;
        }
    }
</style>

<?php include 'includes/footer.php'; ?>
