<?php
require 'includes/db.php';
session_start();
include 'includes/header.php';
?>

<!-- Curriculum Page Banner (Premium Style) -->
<section class="page-banner-premium">
    <div class="container">
        <div class="page-header-divider"></div>
        <h1 class="section-title">Curriculum</h1>
        <nav>
            <ol class="breadcrumb-hijra">
                <li><a href="index.php">Baitul Islam Open University</a></li>
                <li style="opacity: 0.5;">/</li>
                <li>Curriculum</li>
            </ol>
        </nav>
    </div>
</section>

<!-- Curriculum Intro Section -->
<section style="padding: 60px 0; background: #fff;">
    <div class="container text-center">
        <div style="max-width: 800px; margin: 0 auto;">
            <h2 style="font-family: 'Outfit', sans-serif; font-weight: 800; color: var(--primary); margin-bottom: 25px;">A Comprehensive Journey of Learning</h2>
            <p style="font-size: 1.2rem; color: #666; line-height: 1.8;">
                Our curriculum is a 5-year comprehensive Islamic course consisting of 10 semesters. 
                It is designed to provide students with a deep understanding of Quran, Hadith, Fiqh, and Arabic Language.
            </p>
        </div>
    </div>
</section>

<!-- Curriculum Accordion Section -->
<section style="padding: 0 0 100px; background: #fff;">
    <div class="container">
        <div class="accordion" id="curriculumAccordion">
            
            <?php 
            $semesters = [
                ["year" => "1st Year", "sem" => "Semester - 1", "id" => "collapseOne", "data" => [
                    ["sr" => "1", "subject" => "The Creed", "book" => "Get your Belief from the Quran and the Prophetic Sunnah (خذ عقيدتك من الكتاب والسنة)"],
                    ["sr" => "2", "subject" => "Explanation of the Holy Quran", "book" => "Explanation of the Last Tenth of the Quran (تفسير العشر الأخير من القرآن الكريم)"],
                    ["sr" => "3", "subject" => "Call and Morals", "book" => "The Method of the Prophets in Calling to Allah (منهج الأنبياء في الدعوة إلى الله)"],
                    ["sr" => "4", "subject" => "Jurisprudence", "book" => "Al-Fiqh Al-Muyassar (الفقه الميسر)"],
                    ["sr" => "5", "subject" => "Arabic Language", "book" => "Arabic for Beginners (العربية لغير الناطقين بها)"]
                ]],
                ["year" => "1st Year", "sem" => "Semester - 2", "id" => "collapseTwo", "data" => [
                    ["sr" => "1", "subject" => "Fundamentals of Faith", "book" => "Explanation of the Three Fundamental Principles (شرح الأصول الثلاثة)"],
                    ["sr" => "2", "subject" => "Hadith Studies", "book" => "Forty Hadith of Imam Nawawi (الأربعون النووية)"],
                    ["sr" => "3", "subject" => "Islamic History", "book" => "The Sealed Nectar (الرحيق المختوم)"],
                    ["sr" => "4", "subject" => "Tajweed", "book" => "Tuhfat al-Atfal (تحفة الأطفال)"],
                    ["sr" => "5", "subject" => "Arabic Grammar", "book" => "Al-Ajurrumiyyah (الآجرومية)"]
                ]],
                ["year" => "2nd Year", "sem" => "Semester - 3", "id" => "collapseThree", "data" => [
                    ["sr" => "1", "subject" => "Advanced Creed", "book" => "Kitab at-Tawheed (كتاب التوحيد)"],
                    ["sr" => "2", "subject" => "Tafseer Studies", "book" => "Tafseer Ibn Katheer (Abridged) (تيسير العلي القدير)"],
                    ["sr" => "3", "subject" => "Jurisprudence (Salah)", "book" => "Bulugh al-Maram (بلوغ المرام - كتاب الصلاة)"],
                    ["sr" => "4", "subject" => "Arabic Literature", "book" => "Qasas al-Nabiyyin (قصص النبيين)"]
                ]],
                // Add more placeholders for high fidelity look
                ["year" => "2nd Year", "sem" => "Semester - 4", "id" => "collapseFour", "data" => []],
                ["year" => "3rd Year", "sem" => "Semester - 5", "id" => "collapseFive", "data" => []],
                ["year" => "3rd Year", "sem" => "Semester - 6", "id" => "collapseSix", "data" => []],
                ["year" => "4th Year", "sem" => "Semester - 7", "id" => "collapseSeven", "data" => []],
                ["year" => "4th Year", "sem" => "Semester - 8", "id" => "collapseEight", "data" => []],
                ["year" => "5th Year", "sem" => "Semester - 9", "id" => "collapseNine", "data" => []],
                ["year" => "5th Year", "sem" => "Semester - 10", "id" => "collapseTen", "data" => []]
            ];

            foreach($semesters as $index => $sem):
            ?>
            <div class="accordion-item mb-3" style="border: none; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
                <h2 class="accordion-header" id="heading<?php echo $sem['id']; ?>">
                    <button class="accordion-button <?php echo $index === 0 ? '' : 'collapsed'; ?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo $sem['id']; ?>" aria-expanded="<?php echo $index === 0 ? 'true' : 'false'; ?>" aria-controls="<?php echo $sem['id']; ?>" style="background: var(--primary); color: white; padding: 20px 25px; font-weight: 700; font-size: 1.1rem; border: none; box-shadow: none;">
                        <i class="fas fa-bars me-3" style="color: var(--accent);"></i>
                        <?php echo $sem['year']; ?> – <?php echo $sem['sem']; ?>
                    </button>
                </h2>
                <div id="<?php echo $sem['id']; ?>" class="accordion-collapse collapse <?php echo $index === 0 ? 'show' : ''; ?>" aria-labelledby="heading<?php echo $sem['id']; ?>" data-bs-parent="#curriculumAccordion">
                    <div class="accordion-body" style="padding: 0;">
                        <?php if(!empty($sem['data'])): ?>
                        <div class="table-responsive">
                            <table class="table table-hover mb-0" style="background: #fff; vertical-align: middle;">
                                <thead style="background: #f8f9fa;">
                                    <tr>
                                        <th style="padding: 15px 25px; width: 100px;">Sr No</th>
                                        <th style="padding: 15px 25px;">Subjects</th>
                                        <th style="padding: 15px 25px;">Resource Books</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($sem['data'] as $row): ?>
                                    <tr>
                                        <td style="padding: 15px 25px; font-weight: 600; color: #888; border-bottom: 1px solid #f0f0f0;"><?php echo $row['sr']; ?></td>
                                        <td style="padding: 15px 25px; font-weight: 700; color: var(--primary); border-bottom: 1px solid #f0f0f0;"><?php echo $row['subject']; ?></td>
                                        <td style="padding: 15px 25px; color: #555; border-bottom: 1px solid #f0f0f0; font-size: 0.95rem; font-style: italic;"><?php echo $row['book']; ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <div style="padding: 30px; text-align: center; color: #999;">
                            Curriculum details for this semester will be updated soon.
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>

        </div>
    </div>
</section>

<style>
    .accordion-button::after {
        filter: brightness(0) invert(1);
    }
    .accordion-button:not(.collapsed) {
        box-shadow: none;
    }
</style>

<?php include 'includes/footer.php'; ?>
