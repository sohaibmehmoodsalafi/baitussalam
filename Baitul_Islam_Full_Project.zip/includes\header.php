<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Prevent caching to ensure logout works effectively with back button
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1.
header("Pragma: no-cache"); // HTTP 1.0.
header("Expires: 0"); // Proxies.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        // Force reload on back button to prevent viewing cached authenticated pages after logout
        window.onpageshow = function(event) {
            if (event.persisted) {
                window.location.reload();
            }
        };
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baitul Islam - Online Quran Teaching</title>
    <?php
    // Dynamic Asset Path Detection
    $assets_path = 'assets/'; // Default for root files
    
    // Check if we are in a subdirectory (like admin/)
    if (!file_exists(__DIR__ . '/../' . $assets_path . 'css/style.css')) {
         // This logic is tricky with __DIR__.
         // Let's use the execution context (cwd)
         if (!file_exists('assets/css/style.css') && file_exists('../assets/css/style.css')) {
             $assets_path = '../assets/';
         }
    } else {
        // If specific check needed
        if (!file_exists('assets/css/style.css') && file_exists('../assets/css/style.css')) {
             $assets_path = '../assets/';
         }
    }
    // Simple check based on CWD
    if (!file_exists('assets/css/style.css') && file_exists('../assets/css/style.css')) {
        $assets_path = '../assets/';
    }
    
    $css_ver = file_exists($assets_path . 'css/style.css') ? filemtime($assets_path . 'css/style.css') : time();
    ?>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&family=Poppins:wght@400;600;700&family=Inter:wght@400;600&family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <link href="<?php echo $assets_path; ?>css/style.css?v=<?php echo $css_ver; ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- AOS Animation Library -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>
<body>

    <!-- Top Bar (Hijra Inspired) -->
    <div style="background: var(--primary-dark); color: white; padding: 10px 0; font-size: 0.85rem; border-bottom: 1px solid rgba(255,255,255,0.1);" class="header-top-bar">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex gap-4 mobile-gap-2">
                <span><i class="fas fa-phone-alt me-2 text-accent"></i> +92-302-270-2808</span>
                <span class="d-none d-sm-inline"><i class="fas fa-envelope me-2 text-accent"></i> info@baitulislam.org</span>
            </div>
            <div class="d-flex gap-3 social-top d-none d-md-flex">
                <a href="#" class="text-white"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="text-white"><i class="fab fa-instagram"></i></a>
                <a href="#" class="text-white"><i class="fab fa-youtube"></i></a>
                <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
    </div>

    <?php 
    $is_home = (basename($_SERVER['PHP_SELF']) == 'index.php');
    ?>
    <nav class="navbar <?php echo $is_home ? 'navbar-home' : ''; ?>" style="background: <?php echo $is_home ? 'transparent' : 'var(--primary)'; ?>; padding: 15px 0; transition: all 0.3s ease;">
        <div class="container">
            <a href="index.php" class="logo">
                <img src="<?php echo $assets_path; ?>images/logo.png" alt="Baitul Islam Logo" style="height: 60px; filter: brightness(0) invert(1);">
            </a>
            
            <div class="nav-links" id="nav-links">
                <a href="index.php" class="nav-item-link">Home</a>
                
                <!-- Drodown Menu -->
                <div class="dropdown-container">
                    <a href="courses.php" class="nav-item-link">Courses <i class="fas fa-chevron-down" style="font-size: 0.8rem; margin-left: 5px;"></i></a>
                    <div class="dropdown-menu">
                        <div class="dropdown-content-simple">
                            <a href="curriculum.php" class="dropdown-item-simple">
                                <span>Curriculum</span>
                                <i class="fas fa-chevron-right" style="font-size: 0.8rem; opacity: 0.5;"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <a href="about.php" class="nav-item-link">About Us</a>
                <a href="blog.php" class="nav-item-link">Blog</a>
                <a href="contact.php" class="nav-item-link">Contact</a>
                
                <div class="auth-btns-mobile d-lg-none mt-4 w-100 p-3">
                    <?php if(isset($_SESSION['user_id'])): ?>
                         <a href="<?php echo ($_SESSION['user_role'] == 'tutor' ? 'tutor_dashboard.php' : 'student_dashboard.php'); ?>" class="btn-premium-gold d-block text-center mb-2">Dashboard</a>
                         <a href="logout.php" class="btn-premium-outline d-block text-center" style="color: #ef4444; border-color: #ef4444;">Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="btn-premium-outline d-block text-center mb-2">Login</a>
                        <a href="register.php" class="btn-premium-gold d-block text-center">Join Now</a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="auth-btns d-none d-lg-flex align-items-center gap-3">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <div class="user-pill dropdown">
                        <a href="#" class="d-flex align-items-center gap-2 text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                            <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['user_name']); ?>&background=D4AF37&color=fff" style="width: 35px; height: 35px; border-radius: 50%;">
                            <span><?php echo explode(' ', $_SESSION['user_name'])[0]; ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow border-0" style="border-radius: 12px; margin-top: 15px;">
                            <li><a class="dropdown-item py-2 px-3" href="<?php echo ($_SESSION['user_role'] == 'tutor' ? 'tutor_dashboard.php' : 'student_dashboard.php'); ?>"><i class="fas fa-th-large me-2"></i> Dashboard</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item py-2 px-3 text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="btn-premium-outline" style="padding: 10px 25px; font-size: 0.9rem;">Log in</a>
                    <a href="register.php" class="btn-premium-gold" style="padding: 10px 25px; font-size: 0.9rem;">Get Started</a>
                <?php endif; ?>
            </div>

            <!-- Mobile Toggle -->
            <div class="nav-toggle d-lg-none" id="nav-toggle" style="cursor: pointer; color: white; font-size: 1.5rem;">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>

    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="<?php echo $assets_path; ?>js/main.js"></script>
    <script>
        AOS.init({
            duration: 800,
            easing: 'ease-in-out',
            once: true,
            mirror: false
        });
    </script>
