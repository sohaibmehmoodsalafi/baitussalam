<?php
require 'includes/db.php';
session_start();
require 'includes/stripe_config.php';
require 'includes/enrollment_security.php';

$session_id = $_GET['session_id'] ?? '';
$error_msg = "";
$success_msg = "";

if ($session_id) {
    // Verify Payment via Stripe API
    $stripe_url = "https://api.stripe.com/v1/checkout/sessions/$session_id";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $stripe_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERPWD, STRIPE_SECRET_KEY . ':');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    $result = curl_exec($ch);
    $session = json_decode($result, true);
    curl_close($ch);

    if (isset($session['payment_status']) && $session['payment_status'] == 'paid') {
        $course_id = $session['metadata']['course_id'] ?? null;
        $student_id = $session['metadata']['student_id'] ?? null;

        if ($course_id && $student_id) {
            // Use secure enrollment system
            $enrollmentSecurity = new EnrollmentSecurity($pdo);
            $result = $enrollmentSecurity->createEnrollment($student_id, $course_id, 'paid', $session_id);
            
            if ($result['success']) {
                $success_msg = $result['message'];
            } else {
                $error_msg = implode('<br>', $result['errors']);
            }
        } else {
            $error_msg = "Missing course or student information.";
        }
    } else {
        $error_msg = "Payment verification failed or was not completed.";
    }
}

include 'includes/header.php';
?>

<div class="container" style="padding: 150px 0; text-align: center;">
    <div style="max-width: 600px; margin: 0 auto; background: white; padding: 50px; border-radius: 20px; box-shadow: 0 20px 50px rgba(0,0,0,0.05); border: 1px solid #eef2f3;">
        <?php if ($error_msg): ?>
            <div style="width: 80px; height: 80px; background: #ef4444; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 30px; font-size: 2.5rem;">
                <i class="fas fa-times"></i>
            </div>
            <h1 style="color: #ef4444; font-weight: 900; margin-bottom: 15px;">Verification Issue</h1>
            <p style="color: #64748b; font-size: 1.1rem; line-height: 1.8; margin-bottom: 40px;">
                <?php echo $error_msg; ?>
            </p>
        <?php else: ?>
            <div style="width: 80px; height: 80px; background: #10b981; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 30px; font-size: 2.5rem; animation: pulse 2s infinite;">
                <i class="fas fa-check"></i>
            </div>
            <h1 style="color: var(--primary); font-weight: 900; margin-bottom: 15px;">Payment Successful!</h1>
            <p style="color: #64748b; font-size: 1.1rem; line-height: 1.8; margin-bottom: 40px;">
                Thank you for enrolling in the Baitul Islam. Your payment has been processed successfully. You can now access your dashboard and start booking classes.
            </p>
        <?php endif; ?>
        
        <div style="display: flex; gap: 15px; justify-content: center;">
            <a href="student_dashboard.php" class="btn btn-primary" style="padding: 15px 35px; border-radius: 12px; font-weight: 700;">Go to Dashboard</a>
            <a href="index.php" class="btn btn-outline" style="padding: 15px 35px; border-radius: 12px; font-weight: 700; color: var(--primary); border: 2px solid #eee;">Back Home</a>
        </div>
        
        <div style="margin-top: 40px; border-top: 1px solid #f1f5f9; padding-top: 20px;">
            <p style="font-size: 0.85rem; color: #94a3b8;">
                Transaction ID: <span style="color: #1a202c; font-weight: 600;"><?php echo htmlspecialchars($session_id); ?></span>
            </p>
        </div>
    </div>
</div>

<style>
@keyframes pulse {
    0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4); }
    70% { transform: scale(1.05); box-shadow: 0 0 0 15px rgba(16, 185, 129, 0); }
    100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
}
</style>

<?php include 'includes/footer.php'; ?>
