<?php
session_start();
require_once 'includes/db.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    
    if (empty($username)) {
        $error = "Please enter your username.";
    } else {
        // Check if admin exists
        $stmt = $pdo->prepare("SELECT id, username FROM admins WHERE username = ?");
        $stmt->execute([$username]);
        $admin = $stmt->fetch();
        
        if ($admin) {
            // Generate reset token
            $reset_token = bin2hex(random_bytes(32));
            $reset_expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Store token in database
            $stmt = $pdo->prepare("UPDATE admins SET reset_token = ?, reset_token_expiry = ? WHERE username = ?");
            $stmt->execute([$reset_token, $reset_expiry, $username]);
            
            // Create reset link
            $reset_link = "http://" . $_SERVER['HTTP_HOST'] . "/Qutor/admin_reset_password.php?token=" . $reset_token;
            
            // For development - show the link directly (since email might not be configured)
            $message = "Password reset link generated successfully!<br><br><strong>Use this link to reset your password:</strong><br><br><a href='$reset_link' style='color: #D4AF37; font-weight: bold; word-break: break-all;'>$reset_link</a><br><br><small style='color: #666;'>This link will expire in 1 hour.</small>";
        } else {
            $error = "No admin account found with this username.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Password Reset - Peace Institute</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #0F5132;
            --primary-dark: #082F1D;
            --accent: #D4AF37;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Outfit', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: radial-gradient(circle at center, var(--primary) 0%, var(--primary-dark) 100%);
            padding: 20px;
            position: relative;
        }

        /* Decorative Orbs */
        .orb {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            z-index: 1;
        }
        .orb-1 { width: 400px; height: 400px; background: rgba(212, 175, 55, 0.15); top: -100px; left: -100px; }
        .orb-2 { width: 300px; height: 300px; background: rgba(15, 81, 50, 0.5); bottom: -50px; right: -50px; }

        .reset-card {
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            padding: 50px;
            border-radius: 24px;
            box-shadow: 0 25px 50px rgba(0,0,0,0.3);
            width: 100%;
            max-width: 500px;
            position: relative;
            z-index: 10;
            border: 1px solid rgba(255,255,255,0.2);
        }

        .reset-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .brand-icon {
            width: 70px;
            height: 70px;
            background: var(--primary);
            color: var(--accent);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            margin: 0 auto 20px;
            box-shadow: 0 10px 20px rgba(15, 81, 50, 0.2);
        }

        .reset-header h1 {
            font-size: 1.8rem;
            font-weight: 800;
            color: var(--primary-dark);
            margin-bottom: 8px;
        }

        .reset-header p {
            color: #64748b;
            font-size: 0.95rem;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            font-weight: 700;
            color: var(--primary-dark);
            margin-bottom: 10px;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-control {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #f1f5f9;
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s;
            background: #f8fafc;
        }

        .form-control:focus {
            border-color: var(--primary);
            background: white;
            outline: none;
            box-shadow: 0 0 0 4px rgba(15, 81, 50, 0.05);
        }

        .btn-reset {
            width: 100%;
            padding: 16px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 800;
            cursor: pointer;
            transition: all 0.3s;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-top: 10px;
        }

        .btn-reset:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(15, 81, 50, 0.2);
        }

        .success-alert {
            background: #d4edda;
            color: #155724;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 0.9rem;
            text-align: center;
            border: 1px solid #c3e6cb;
            line-height: 1.6;
        }

        .error-alert {
            background: #fee2e2;
            color: #991b1b;
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 25px;
            font-size: 0.9rem;
            font-weight: 600;
            text-align: center;
            border: 1px solid #fecaca;
        }

        .back-link {
            text-align: center;
            margin-top: 30px;
        }

        .back-link a {
            color: #64748b;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: 0.3s;
        }

        .back-link a:hover {
            color: var(--primary);
        }

        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196F3;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            font-size: 0.9rem;
        }

        .info-box i {
            color: #2196F3;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="orb orb-1"></div>
    <div class="orb orb-2"></div>

    <div class="reset-card">
        <div class="reset-header">
            <div class="brand-icon">
                <i class="fas fa-key"></i>
            </div>
            <h1>Admin Password Reset</h1>
            <p>Enter your username to reset your password</p>
        </div>

        <?php if($message): ?>
            <div class="success-alert">
                <i class="fas fa-check-circle"></i> <?php echo $message; ?>
            </div>
            <div class="back-link">
                <a href="admin_login.php">
                    <i class="fas fa-sign-in-alt"></i> Back to Admin Login
                </a>
            </div>
        <?php else: ?>
            <?php if($error): ?>
                <div class="error-alert">
                    <i class="fas fa-circle-exclamation"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <div class="info-box">
                <i class="fas fa-info-circle"></i>
                <strong>Security Notice:</strong> Enter your admin username and we'll generate a password reset link for you.
            </div>

            <form method="POST">
                <div class="form-group">
                    <label class="form-label">Admin Username</label>
                    <input type="text" name="username" class="form-control" placeholder="Enter your admin username" required autofocus>
                </div>
                <button type="submit" class="btn-reset">
                    <i class="fas fa-paper-plane"></i> Generate Reset Link
                </button>
            </form>

            <div class="back-link">
                <a href="admin_login.php"><i class="fas fa-arrow-left"></i> Back to Login</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
