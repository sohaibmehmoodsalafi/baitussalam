<!-- Shared Sidebar Component -->
<div class="glass-sidebar" id="sidebar-wrapper">
    <div class="sidebar-heading">
        <div class="brand-box">
            <i class="fas fa-layer-group"></i> Admin Panel
        </div>
    </div>
    <div class="list-group list-group-flush my-1">
        <a href="admin_panel.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_panel.php' ? 'active' : ''; ?>">
            <i class="fas fa-home"></i> <span>Dashboard</span>
        </a>
        
        <div class="menu-label">PEOPLE & COURSES</div>
        <a href="admin_tutors.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_tutors.php' ? 'active' : ''; ?>">
            <i class="fas fa-chalkboard-teacher"></i> <span>Tutors</span>
        </a>
        <a href="admin_students.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_students.php' ? 'active' : ''; ?>">
            <i class="fas fa-user-graduate"></i> <span>Students</span>
        </a>
        <a href="admin_enrollments.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_enrollments.php' ? 'active' : ''; ?>">
            <i class="fas fa-calendar-check"></i> <span>Enrollments</span>
        </a>
        <a href="admin_courses.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_courses.php' ? 'active' : ''; ?>">
            <i class="fas fa-book"></i> <span>Manage Courses</span>
        </a>

        <div class="menu-label">FINANCIALS</div>
        <a href="admin_salaries.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_salaries.php' ? 'active' : ''; ?>">
            <i class="fas fa-money-bill-wave"></i> <span>Teacher Payroll</span>
        </a>
        
        <div class="menu-label">WEBSITE CONTENT</div>
         <a href="admin_settings.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_settings.php' ? 'active' : ''; ?>">
            <i class="fas fa-cog"></i> <span>Site Settings</span>
        </a>
        <a href="admin_content.php" class="sidebar-link <?php echo basename($_SERVER['PHP_SELF']) == 'admin_content.php' ? 'active' : ''; ?>">
            <i class="fas fa-edit"></i> <span>Manage Content</span>
        </a>

        <div class="logout-container">
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
</div>
