<?php
// Stripe Configuration
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51SfhjjH3s2kjemSMqoDBB9xiSECQ1KikRc8KXNNGZZcckvn2dmd7gW8CH0HLlSaucn3cMdx4L3TKjzo3gdf4MtLG00WDAIiVfC');
// User provided Secret Key
define('STRIPE_SECRET_KEY', 'sk_test_51SfhjjH3s2kjemSMPGQS4f4wjJmFjBd8i0tdhxaAKcsmPYdrwBcDUTsGbRRheHD4dg5PgHFR7hpDjqEnYiERPYCA00hwRooUMD'); 
?>
