<?php
require 'includes/db.php';
require 'includes/session_security.php';

// Start secure session
SessionSecurity::startSecureSession();
SessionSecurity::preventCaching();

// Prevent logged-in users from accessing login page
SessionSecurity::preventLoggedInAccess();

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = SessionSecurity::sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password.';
    } elseif (!SessionSecurity::validateEmail($email)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Strict Role Check based on the Tab selected
        $login_type = isset($_GET['type']) && $_GET['type'] == 'tutor' ? 'tutor' : 'student';
        
        if ($login_type === 'tutor') {
            $stmt = $pdo->prepare("SELECT * FROM tutors WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            $role = 'tutor';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM students WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            $role = 'student';
        }
        
        if ($user && password_verify($password, $user['password'])) {
            if ($user['is_verified'] == 0) {
                // If not verified, redirect to verification page
                $code = $user['verification_code'];
                $redirect_query = isset($_GET['redirect']) ? '&redirect=' . urlencode($_GET['redirect']) : '';
                header("Location: verify.php?email=" . urlencode($email) . "&type=" . $role . "&msg=Code: " . $code . $redirect_query);
                exit;
            }

            // Check if Tutor is Approved by Admin
            if ($role === 'tutor' && $user['status'] !== 'approved') {
                if ($user['status'] === 'pending') {
                    $error = 'Your registration is pending admin approval. You will receive an email once approved.';
                } else {
                    $error = 'Your account has been rejected or disabled. Please contact support.';
                }
            } else {
                // Login Success - Set session variables securely
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_role'] = $role;
                $_SESSION['user_email'] = $user['email'];
                
                // Regenerate session ID to prevent session fixation
                session_regenerate_id(true);
                
                $redirect = SessionSecurity::sanitizeInput($_POST['redirect'] ?? $_GET['redirect'] ?? '');
                if ($redirect) {
                    header("Location: " . $redirect);
                } else {
                    if ($role == 'student') {
                        header("Location: student_dashboard.php");
                    } else {
                        header("Location: tutor_dashboard.php");
                    }
                }
                exit;
            }
        } else {
            $error = 'Invalid email or password for ' . ucfirst($login_type) . ' account.';
        }
    }

}
include 'includes/header.php'; ?>

<style>
    .auth-container {
        max-width: 500px;
        margin: 60px auto;
        padding: 50px;
        background: white;
        border-radius: 20px;
        box-shadow: 0 30px 70px rgba(0,0,0,0.1);
        border: 1px solid rgba(0,0,0,0.03);
    }
    .auth-header {
        text-align: center;
        margin-bottom: 30px;
    }
    .auth-header h1 {
        font-size: 2rem;
        color: var(--primary);
        font-weight: 800;
        margin-bottom: 10px;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: var(--primary);
        font-size: 0.95rem;
    }
    .form-control {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid #e2e8f0;
        border-radius: 8px;
        font-size: 1rem;
        transition: border-color 0.3s ease;
        background: #f8fafc;
    }
    .form-control:focus {
        border-color: var(--accent);
        outline: none;
        background: white;
    }
    .btn-auth {
        width: 100%;
        padding: 16px;
        background: var(--primary);
        color: white;
        border: none;
        border-radius: 12px;
        font-size: 1.1rem;
        font-weight: 800;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        box-shadow: 0 10px 20px rgba(13, 81, 50, 0.15);
    }
    .btn-auth:hover {
        background: var(--primary-dark);
        transform: translateY(-3px);
        box-shadow: 0 15px 30px rgba(13, 81, 50, 0.25);
    }
    .auth-switch {
        margin-top: 20px;
        text-align: center;
        font-size: 0.95rem;
        color: var(--text-muted);
    }
    .auth-switch a {
        color: var(--accent);
        font-weight: 600;
        text-decoration: none;
    }
    
    /* Toggle Switch */
    .type-toggle {
        display: flex;
        background: #f1f5f9;
        padding: 6px;
        border-radius: 12px;
        margin-bottom: 35px;
    }
    .type-toggle a {
        flex: 1;
        text-align: center;
        padding: 12px;
        border-radius: 9px;
        text-decoration: none;
        color: #64748b;
        font-weight: 700;
        transition: all 0.3s ease;
    }
    .type-toggle a.active {
        background: white;
        color: var(--primary);
        box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
</style>

<div class="container">
    <div class="auth-container">
        <div class="auth-header">
            <h1>Welcome Back</h1>
            <p style="color: var(--text-muted);">Login to manage your account</p>
        </div>
        
        <?php if(isset($_GET['msg'])): ?>
            <div style="background: #f0fdf4; color: #166534; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #dcfce7; font-weight: 600;">
                <i class="fas fa-check-circle me-2"></i> <?php echo htmlspecialchars($_GET['msg']); ?>
            </div>
        <?php endif; ?>

        <?php $type = isset($_GET['type']) && $_GET['type'] == 'tutor' ? 'tutor' : 'student'; ?>
        <div class="type-toggle">
            <a href="?type=student" class="<?php echo $type == 'student' ? 'active' : ''; ?>">As Student</a>
            <a href="?type=tutor" class="<?php echo $type == 'tutor' ? 'active' : ''; ?>">As Tutor</a>
        </div>

        <?php if($error): ?>
            <div style="background: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form method="POST">
            <?php if(isset($_GET['redirect'])): ?>
                <input type="hidden" name="redirect" value="<?php echo htmlspecialchars($_GET['redirect']); ?>">
            <?php endif; ?>
            <div class="form-group">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="name@example.com" required>
            </div>

            <div class="form-group">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
            </div>

            <div style="text-align: right; margin-bottom: 20px;">
                <a href="forgot_password_otp.php" style="color: var(--accent); text-decoration: none; font-size: 0.9rem; font-weight: 600;">
                    <i class="fas fa-key"></i> Forgot Password?
                </a>
            </div>

            <button type="submit" class="btn-auth">Login</button>
        </form>

        <div class="auth-switch">
            <?php 
                $redirect_param = isset($_GET['redirect']) ? '&redirect=' . urlencode($_GET['redirect']) : '';
                $signup_link = "register.php" . ($type=='tutor' ? '?type=tutor' : '?type=student') . $redirect_param;
            ?>
            Don't have an account? <a href="<?php echo $signup_link; ?>">Sign Up</a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
