<?php
require 'includes/db.php';

// Handle Reset/Drop if requested (You might want to remove this in prod)
if (isset($_GET['reset_db'])) {
    $pdo->exec("DROP TABLE IF EXISTS tutors");
    $pdo->exec("DROP TABLE IF EXISTS students");
    // header("Location: setup_db.php"); // Assuming setup_db handles creation
    // But since we can't redirect to a script that outputs text easily, let's just re-include setup logic or rely on the user running setup_db.php separately.
    // For now, let's just continue.
}

if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Generate simple math challenge for verification
$num1 = rand(1, 9);
$num2 = rand(1, 9);
if (!isset($_SESSION['captcha_sum'])) {
    $_SESSION['captcha_sum'] = $num1 + $num2;
    $_SESSION['captcha_text'] = "$num1 + $num2";
}

$type = isset($_GET['type']) && $_GET['type'] == 'tutor' ? 'tutor' : 'student';
$pageTitle = $type == 'tutor' ? 'Become a Tutor' : 'Join as Student';

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $country = $_POST['country'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $gender = $_POST['gender'] ?? '';

    // Human Verification Check
    $user_answer = $_POST['captcha_answer'] ?? '';
    $correct_answer = $_SESSION['captcha_sum'] ?? 0;
    
    // Reset captcha for next attempt if failed or successful
    unset($_SESSION['captcha_sum']); 


    // List of blocked dummy/fake domains for OTP protection
    $blocked_domains = ['test.com', 'dummy.com', 'example.com', 'mailinator.com', 'tempmail.com', 'fake.com', 'yopmail.com', '10minutemail.com', 'guerrillamail.com', 'trashmail.com', 'dispostable.com', 'tutor.com', 'student.com'];
    $email_parts = explode('@', $email);
    $domain = count($email_parts) > 1 ? end($email_parts) : '';
    $local_part = $email_parts[0] ?? '';

    // 1. Pattern Check (Blocked common placeholders)
    $dummy_patterns = ['test', 'dummy', 'demo', 'asdf', 'ghjk', 'qwerty', '123456', 'aaaa', 'user', 'fake'];
    $is_dummy = false;
    foreach($dummy_patterns as $p) {
        if(str_contains(strtolower($local_part), $p) || str_contains(strtolower($name), $p)) {
            $is_dummy = true;
            break;
        }
    }

    // 2. Length & Quality Check
    $is_too_short = (strlen($local_part) < 3);

    // Basic Validation
    if (empty($name) || empty($email) || empty($password)) {
        $error_msg = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_msg = 'Please enter a valid email format.';
    } elseif (in_array(strtolower($domain), $blocked_domains) || $is_dummy || $is_too_short) {
        $error_msg = 'Registration restricted. Please use a real, personal email address.';
    } elseif (!empty($domain) && !checkdnsrr($domain, "MX") && !in_array($domain, ['localhost', '127.0.0.1'])) {
        $error_msg = 'This email domain does not appear to be real or cannot receive mail.';
    } else {
        try {
            // Hash Password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Generate 6-digit code AND a unique token for direct link
            $verification_code = rand(100000, 999999);
            $token = bin2hex(random_bytes(32));
            $base_url = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']);
            
            if ($type == 'tutor') {
                // Check if email exists
                $stmt = $pdo->prepare("SELECT id, status, rejected_at FROM tutors WHERE email = ?");
                $stmt->execute([$email]);
                $existing_tutor = $stmt->fetch();

                if ($existing_tutor) {
                    if ($existing_tutor['status'] === 'approved') {
                        $error_msg = 'This email is already registered and approved. Please try logging in.';
                    } elseif ($existing_tutor['status'] === 'pending') {
                        $error_msg = 'Your previous application is still pending review. Please wait for admin approval.';
                    } elseif ($existing_tutor['status'] === 'rejected') {
                        // Check Cooldown (1 week = 7 days)
                        $rejected_at = strtotime($existing_tutor['rejected_at'] ?? '2000-01-01');
                        $one_week_ago = strtotime('-7 days');
                        
                        if ($rejected_at > $one_week_ago) {
                            $days_left = ceil(($rejected_at - $one_week_ago) / (24 * 3600));
                            $error_msg = "Your previous application was not approved. You can try again in $days_left days.";
                        }
                    }
                }

                if (empty($error_msg)) {
                    // Handle File Uploads
                    $cert_path = '';
                    $video_path = '';
                    $madrassa = $_POST['madrassa'] ?? '';

                    if (isset($_FILES['certificate']) && $_FILES['certificate']['error'] == 0) {
                        $ext = pathinfo($_FILES['certificate']['name'], PATHINFO_EXTENSION);
                        $cert_path = 'uploads/certificates/' . uniqid('cert_') . '.' . $ext;
                        move_uploaded_file($_FILES['certificate']['tmp_name'], $cert_path);
                    }

                    if (isset($_FILES['qirat_video']) && $_FILES['qirat_video']['error'] == 0) {
                        $ext = pathinfo($_FILES['qirat_video']['name'], PATHINFO_EXTENSION);
                        $video_path = 'uploads/videos/' . uniqid('video_') . '.' . $ext;
                        move_uploaded_file($_FILES['qirat_video']['tmp_name'], $video_path);
                    }

                    if ($existing_tutor) {
                        // UPDATE existing record for resubmission
                        $sql = "UPDATE tutors SET name = ?, password = ?, country = ?, phone = ?, gender = ?, madrassa = ?, status = 'pending', rejected_at = NULL";
                        $params = [$name, $hashed_password, $country, $phone, $gender, $madrassa];
                        
                        if ($cert_path) {
                            $sql .= ", certificate_path = ?";
                            $params[] = $cert_path;
                        }
                        if ($video_path) {
                            $sql .= ", qirat_video_path = ?";
                            $params[] = $video_path;
                        }
                        
                        $sql .= " WHERE id = ?";
                        $params[] = $existing_tutor['id'];
                        
                        $stmt = $pdo->prepare($sql);
                        $stmt->execute($params);
                        $success_msg = "Your application has been updated and sent to the admin for review.";
                    } else {
                        // INSERT new record
                        $stmt = $pdo->prepare("INSERT INTO tutors (name, email, password, country, phone, gender, madrassa, certificate_path, qirat_video_path, status, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 0)");
                        $stmt->execute([$name, $email, $hashed_password, $country, $phone, $gender, $madrassa, $cert_path, $video_path]);
                        $success_msg = "Registration successful! Your application has been sent to the admin for review.";
                    }
                    
                    // Redirect to login with a special message
                    $redirect_query = isset($_GET['redirect']) ? '&redirect=' . urlencode($_GET['redirect']) : '';
                    header("Location: login.php?type=tutor&msg=" . urlencode($success_msg . " You will receive an email once approved.") . $redirect_query);
                    exit;
                }
            } else {
                // Check if email exists
                $stmt->execute([$email]);
                $existing_student = $stmt->fetch();

                if ($existing_student && $existing_student['is_verified'] == 1) {
                    $error_msg = 'Email already registered and verified. Please login.';
                } elseif ($existing_student) {
                    // Update existing unverified student with new code
                    $stmt = $pdo->prepare("UPDATE students SET name = ?, password = ?, country = ?, phone = ?, verification_code = ?, verification_token = ? WHERE email = ?");
                    $stmt->execute([$name, $hashed_password, $country, $phone, $verification_code, $token, $email]);
                    
                    $verify_link = "$base_url/verify.php?email=" . urlencode($email) . "&token=$token&type=student";
                    require_once 'includes/verification_email.php';
                    sendVerificationEmail($email, $name, $verification_code, $verify_link, 'student');
                    
                    header("Location: verify.php?email=" . urlencode($email) . "&type=student&msg=New verification code sent! Check your inbox.");
                    exit;
                } else {
                    $stmt = $pdo->prepare("INSERT INTO students (name, email, password, country, phone, verification_code, verification_token, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?, 0)");
                    $stmt->execute([$name, $email, $hashed_password, $country, $phone, $verification_code, $token]);
                    
                    $verify_link = "$base_url/verify.php?email=" . urlencode($email) . "&token=$token&type=student";

                    // Send verification email using PHPMailer
                    require_once 'includes/verification_email.php';
                    $emailResult = sendVerificationEmail($email, $name, $verification_code, $verify_link, 'student');
                    
                    $redirect_query = isset($_GET['redirect']) ? '&redirect=' . urlencode($_GET['redirect']) : '';
                    if ($emailResult['success']) {
                        header("Location: verify.php?email=" . urlencode($email) . "&type=student&msg=Verification email sent! Check your inbox." . $redirect_query);
                    } else {
                        // Even if email fails, show verification page with code
                        header("Location: verify.php?email=" . urlencode($email) . "&type=student&code=$verification_code&msg=Registration successful! Use code: $verification_code" . $redirect_query);
                    }
                    exit;
                }
            }
        } catch (PDOException $e) {
            $error_msg = 'Database Error: ' . $e->getMessage();
        }
    }
}
?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/css/intlTelInput.css">
<?php include 'includes/header.php'; ?>


<style>
    .auth-container {
        max-width: 550px;
        margin: 60px auto;
        padding: 50px;
        background: white;
        border-radius: 20px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.08);
        border: 1px solid rgba(0,0,0,0.03);
    }
    .auth-header {
        text-align: center;
        margin-bottom: 30px;
    }
    .auth-header h2 {
        font-size: 2rem;
        color: var(--primary);
        margin-bottom: 10px;
    }
    .auth-header p {
        color: #666;
    }
    .form-group {
        margin-bottom: 20px;
    }
    .form-group label {
        display: block;
        margin-bottom: 8px;
        color: #444;
        font-weight: 600;
        font-size: 0.95rem;
    }
    .form-control {
        width: 100%;
        padding: 12px 15px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 1rem;
        transition: border-color 0.3s;
    }
    .form-control:focus {
        border-color: var(--primary);
        box-shadow: 0 5px 15px rgba(13, 81, 50, 0.05);
        outline: none;
        background: white;
    }
    .btn-block {
        display: block;
        width: 100%;
        padding: 14px;
        font-size: 1.1rem;
        margin-top: 10px;
    }
    .auth-switch {
        text-align: center;
        margin-top: 25px;
        padding-top: 20px;
        border-top: 1px solid #eee;
        color: #666;
    }
    .auth-switch a {
        color: var(--primary);
        font-weight: 700;
        text-decoration: underline;
    }
    .alert {
        padding: 15px;
        border-radius: 6px;
        margin-bottom: 20px;
        font-size: 0.95rem;
    }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-danger { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }

    /* Fix for intl-tel-input UI */
    .iti {
        width: 100%;
        display: block;
    }
    .iti__country-list {
        z-index: 1000 !important;
        border-radius: 12px !important;
        border: 1px solid #eee !important;
        box-shadow: 0 15px 35px rgba(0,0,0,0.1) !important;
        overflow-x: hidden;
    }
    .iti--separate-dial-code .iti__selected-dial-code {
        font-weight: 700;
        color: var(--primary);
        margin-left: 8px;
    }
    .iti__flag-container {
        padding: 5px;
    }
    .iti--separate-dial-code input.form-control {
        padding-top: 14px !important;
        padding-bottom: 14px !important;
        border-radius: 50px !important;
        padding-left: 95px !important; /* Proper space for flag + dial code */
        height: 60px;
        background: #f8fafc;
        border: 2px solid #f1f5f9 !important;
        transition: all 0.3s;
    }
    .iti--separate-dial-code input.form-control:focus {
        background: white;
        border-color: var(--primary) !important;
        box-shadow: 0 10px 25px rgba(15, 81, 50, 0.1) !important;
    }
    .iti--separate-dial-code .iti__selected-dial-code {
        font-weight: 800;
        color: var(--primary);
        font-size: 1rem;
        margin-left: 8px;
    }
    .iti__country-list {
        border-radius: 15px !important;
        border: none !important;
        box-shadow: 0 15px 40px rgba(0,0,0,0.15) !important;
        margin-top: 10px !important;
    }
</style>

<div class="container">
    <div class="auth-container">
        <div class="auth-header">
            <h2><?php echo $pageTitle; ?></h2>
            <p>Create your account to get started</p>
        </div>

        <?php if($success_msg): ?>
            <div class="alert alert-success"><?php echo $success_msg; ?></div>
        <?php endif; ?>
        
        <?php if($error_msg): ?>
            <div class="alert alert-danger"><?php echo $error_msg; ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="name" class="form-control" required placeholder="Enter your full name">
            </div>

            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" required placeholder="Enter your email address">
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required placeholder="Enter your password">
            </div>

            <div class="form-group">
                <label>Phone Number</label>
                <input type="tel" id="phone" name="phone" class="form-control" placeholder="Enter your phone number">
                <input type="hidden" id="country_code" name="country_code">
            </div>

            <!-- Auto-populate country from phone -->
            <div class="form-group">
                <label>Country</label>
                <input type="text" id="country" name="country" class="form-control" placeholder="Auto-detected from phone" readonly style="background: #f8f9fa;">
            </div>
            
            <?php if($type == 'tutor'): ?>
            <div class="form-group">
                <label>Gender</label>
                <select name="gender" class="form-control" required>
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>

            <div class="form-group">
                <label>Madrassa / Educational Institute</label>
                <input type="text" name="madrassa" class="form-control" required placeholder="Name of your Madrassa">
            </div>

            <div class="form-group">
                <label>Upload Certificate (PDF/Image)</label>
                <input type="file" name="certificate" class="form-control" required accept=".pdf,image/*">
                <small class="text-muted">Upload your educational certificate or Ijazah.</small>
            </div>

            <div class="form-group">
                <label>Short Qirat Video</label>
                <input type="file" name="qirat_video" class="form-control" required accept="video/*">
                <small class="text-muted">Upload a short clip of your Qirat recitation.</small>
            </div>
            <?php endif; ?>

            <!-- Modern Human Verification (Triggers on Click) -->
            <div id="verify-box" class="form-group" style="display: none; justify-content: center; margin-bottom: 25px;">
                <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 15px 40px; border-radius: 12px; display: flex; align-items: center; gap: 15px; width: 100%; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
                    <div class="loader-spinner"></div>
                    <span style="font-weight: 700; color: #166534; font-size: 0.95rem;">Securing your connection...</span>
                </div>
            </div>

            <style>
                .loader-spinner { width: 20px; height: 20px; border: 3px solid #166534; border-top-color: transparent; border-radius: 50%; animation: spin 0.8s linear infinite; }
                @keyframes spin { to { transform: rotate(360deg); } }
                .reg-btn:disabled { opacity: 0.7; cursor: not-allowed; transform: none !important; }
            </style>

            <button type="button" id="submit-btn" onclick="startVerification()" class="btn-premium-gold w-100" style="padding: 18px; border-radius: 50px; font-weight: 800; box-shadow: 0 10px 20px rgba(15, 81, 50, 0.15); margin-bottom: 30px; transition: 0.3s; border: none; font-size: 1.1rem;">
                <span id="btn-text">Create Account & Join</span>
            </button>

            <script>
                function startVerification() {
                    const btn = document.getElementById('submit-btn');
                    const btnText = document.getElementById('btn-text');
                    const verifyBox = document.getElementById('verify-box');
                    const form = btn.closest('form');

                    // Check basic validation first
                    if(!form.checkValidity()) {
                        form.reportValidity();
                        return;
                    }

                    // Start "Verification"
                    btn.disabled = true;
                    btnText.innerHTML = '<i class="fas fa-shield-alt"></i> Verifying...';
                    verifyBox.style.display = 'flex';
                    
                    // Simulate Security Check
                    setTimeout(() => {
                        btnText.innerHTML = '<i class="fas fa-check-circle"></i> Human Verified';
                        btn.style.background = '#166534';
                        
                        setTimeout(() => {
                            form.submit();
                        }, 500);
                    }, 1500);
                }
            </script>

            <!-- Modern Human Verification (Triggers on Click) -->
            <script src="https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/intlTelInput.min.js"></script>
            <script>
                const phoneInput = document.querySelector("#phone");
                const countryInput = document.querySelector("#country");
                const countryCodeInput = document.querySelector("#country_code");
                const registerForm = document.querySelector("form");
                
                const iti = window.intlTelInput(phoneInput, {
                    initialCountry: "pk",
                    preferredCountries: ["pk", "sa", "ae", "us", "gb"],
                    separateDialCode: true,
                    utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/utils.js"
                });

                // Auto-update country when user selects from dropdown
                phoneInput.addEventListener("countrychange", function() {
                    const countryData = iti.getSelectedCountryData();
                    countryInput.value = countryData.name;
                    countryCodeInput.value = countryData.dialCode;
                    // Clear any previous error
                    phoneInput.style.borderColor = "";
                });

                // Set initial country
                const initialCountry = iti.getSelectedCountryData();
                countryInput.value = initialCountry.name;
                countryCodeInput.value = initialCountry.dialCode;
                
                // Validate phone number on form submit
                registerForm.addEventListener("submit", function(e) {
                    // Get the full number with country code
                    const fullNumber = iti.getNumber();
                    
                    // Check if number is valid
                    if (!iti.isValidNumber()) {
                        e.preventDefault();
                        
                        // Show error
                        phoneInput.style.borderColor = "#dc3545";
                        phoneInput.style.boxShadow = "0 0 0 0.2rem rgba(220, 53, 69, 0.25)";
                        
                        // Get error code
                        const errorCode = iti.getValidationError();
                        let errorMessage = "Invalid phone number";
                        
                        switch(errorCode) {
                            case 1:
                                errorMessage = "Invalid country code";
                                break;
                            case 2:
                                errorMessage = "Phone number is too short";
                                break;
                            case 3:
                                errorMessage = "Phone number is too long";
                                break;
                            case 4:
                                errorMessage = "Invalid phone number format";
                                break;
                            default:
                                errorMessage = "Please enter a valid phone number for " + countryInput.value;
                        }
                        
                        alert("❌ " + errorMessage + "\n\nPlease check your phone number and try again.");
                        phoneInput.focus();
                        return false;
                    }
                    
                    // If valid, set the full international number
                    phoneInput.value = fullNumber;
                    
                    // Reset border
                    phoneInput.style.borderColor = "#28a745";
                    phoneInput.style.boxShadow = "0 0 0 0.2rem rgba(40, 167, 69, 0.25)";
                });
                
                // Real-time validation feedback
                phoneInput.addEventListener("blur", function() {
                    if (phoneInput.value.trim() !== "") {
                        if (iti.isValidNumber()) {
                            phoneInput.style.borderColor = "#28a745";
                            phoneInput.style.boxShadow = "0 0 0 0.2rem rgba(40, 167, 69, 0.25)";
                        } else {
                            phoneInput.style.borderColor = "#dc3545";
                            phoneInput.style.boxShadow = "0 0 0 0.2rem rgba(220, 53, 69, 0.25)";
                        }
                    }
                });
                
                // Clear error on input
                phoneInput.addEventListener("input", function() {
                    if (phoneInput.style.borderColor === "rgb(220, 53, 69)") {
                        phoneInput.style.borderColor = "";
                        phoneInput.style.boxShadow = "";
                    }
                });
            </script>
        </form>

        <div class="auth-switch">
             <?php 
                $redirect_param = isset($_GET['redirect']) ? '?redirect=' . urlencode($_GET['redirect']) : '';
            ?>
            Already have an account? <a href="login.php<?php echo $redirect_param; ?>">Log In</a>
        </div>
        
        <?php if($type != 'tutor'): ?>
            <div style="text-align: center; margin-top: 15px;">
                <a href="register.php?type=tutor" style="font-size: 0.9rem; color: var(--text-muted);">Want to become a tutor?</a>
            </div>
        <?php else: ?>
             <div style="text-align: center; margin-top: 15px;">
                <a href="register.php?type=student" style="font-size: 0.9rem; color: var(--text-muted);">Join as a student</a>
            </div>
        <?php endif; ?>

    </div>
</div>

<?php include 'includes/footer.php'; ?>
