<?php
require 'includes/db.php';
require 'includes/session_security.php';
require 'includes/enrollment_security.php';

// Start secure session
SessionSecurity::startSecureSession();
SessionSecurity::preventCaching();
SessionSecurity::setSecureHeaders();

// Require student login
SessionSecurity::requireLogin('login.php');
SessionSecurity::requireRole('student', 'index.php');

// Security: Only allow access if student has at least one 'paid' enrollment
$user_id = SessionSecurity::getUserId();
$enrollmentSecurity = new EnrollmentSecurity($pdo);
$student_enrollments = $enrollmentSecurity->getStudentEnrollments($user_id);

// Check if student has any paid enrollments
$has_paid_enrollment = false;
foreach ($student_enrollments as $enrollment) {
    if ($enrollment['payment_status'] === 'paid') {
        $has_paid_enrollment = true;
        break;
    }
}

if (!$has_paid_enrollment) {
    header("Location: courses.php?msg=Please purchase a course to access your dashboard.");
    exit;
}

$user_id = $_SESSION['user_id'];
date_default_timezone_set('Asia/Karachi');

// ---------------------------------------------------------
// Handle Complaints via Dashboard
// ---------------------------------------------------------
$complaint_success = '';
$complaint_error = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_complaint'])) {
    $tutor_id = !empty($_POST['tutor_id']) ? $_POST['tutor_id'] : null;
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);

    if (empty($subject) || empty($message)) {
        $complaint_error = "Please fill in all required fields.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO complaints (student_id, tutor_id, subject, message) VALUES (?, ?, ?, ?)");
            $stmt->execute([$user_id, $tutor_id, $subject, $message]);
            $complaint_success = "Your complaint has been submitted. We'll get back to you soon!";
        } catch (PDOException $e) {
            $complaint_error = "Could not submit complaint. Try again.";
        }
    }
}

// ---------------------------------------------------------
// Fetch Data
// ---------------------------------------------------------
$success_msg = isset($_GET['success']) ? 'You have successfully enrolled!' : '';

// Fetch Enrolled Courses - include tutor online status and meeting link
$stmt = $pdo->prepare("
    SELECT courses.title, courses.schedule_days, courses.schedule_time, 
           tutors.name as tutor_name, tutors.is_online, tutors.last_seen, 
           enrollments.id, enrollments.status as enroll_status, enrollments.payment_status,
           courses.meeting_url
    FROM enrollments 
    JOIN courses ON enrollments.course_id = courses.id 
    JOIN tutors ON courses.tutor_id = tutors.id 
    WHERE enrollments.student_id = ?
");
$stmt->execute([$user_id]);
$my_courses = $stmt->fetchAll();

// Fetch Tutors for the complaint dropdown
$stmt_tutors = $pdo->prepare("SELECT DISTINCT t.id, t.name FROM tutors t JOIN courses c ON t.id = c.tutor_id JOIN enrollments e ON c.id = e.course_id WHERE e.student_id = ?");
$stmt_tutors->execute([$user_id]);
$enrolled_tutors = $stmt_tutors->fetchAll();

include 'includes/header.php';
?>

<div class="container section-padding">
    <style>
        .dashboard-grid {
            display: grid;
            grid-template-columns: 320px 1fr;
            gap: 40px;
        }
        .nav-link-tab {
            display: flex; align-items: center; gap: 15px; padding: 15px 20px; border-radius: 12px; font-weight: 700; color: #64748b; text-decoration: none; transition: 0.3s; margin-bottom: 8px; border: 1px solid transparent;
        }
        .nav-link-tab:hover { background: #f8fafc; color: var(--primary); }
        .nav-item-active { background: var(--primary) !important; color: white !important; box-shadow: 0 10px 20px rgba(15, 81, 50, 0.1); }
        .tab-content { display: none; }
        .tab-content.active { display: block; }

        .course-card-premium {
            background: white; padding: 35px; border-radius: 25px; border: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; transition: 0.4s cubic-bezier(0.165, 0.84, 0.44, 1); box-shadow: 0 5px 15px rgba(0,0,0,0.02);
        }
        .course-card-premium:hover { transform: translateY(-7px); box-shadow: 0 20px 40px rgba(0,0,0,0.06); border-color: var(--accent); }
        
        .status-pill { padding: 6px 14px; border-radius: 50px; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; }
        .status-paid { background: #dcfce7; color: #166534; }
        .status-pending { background: #fef9c3; color: #854d0e; }

        @media (max-width: 992px) {
            .dashboard-grid { grid-template-columns: 1fr; }
            .section-padding { padding: 40px 15px; }
        }
        @media (max-width: 768px) {
            .course-card-premium { flex-direction: column; align-items: flex-start !important; gap: 25px; }
            .course-card-premium div:last-child { width: 100%; text-align: left !important; }
        }

        .live-badge {
            background: #ef4444; color: white; padding: 4px 10px; border-radius: 6px; font-size: 0.7rem; font-weight: 900; text-transform: uppercase; animation: blinker 1.5s linear infinite; display: inline-flex; align-items: center; gap: 5px; margin-left: 10px;
        }
        @keyframes blinker {
            50% { opacity: 0.3; }
        }
    </style>

    <div class="dashboard-grid">
        <!-- Sidebar -->
        <div class="dashboard-sidebar">
            <div style="background: white; padding: 40px 30px; border-radius: 30px; border: 1px solid #f1f5f9; box-shadow: 0 10px 40px rgba(0,0,0,0.03); position: sticky; top: 100px;">
                <div class="text-center" style="margin-bottom: 40px;">
                    <div class="avatar-circle" style="width: 100px; height: 100px; font-size: 2.5rem; margin: 0 auto 20px; background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; border: 5px solid #f8fafc; box-shadow: 0 10px 20px rgba(0,0,0,0.05);">
                        <?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?>
                    </div>
                    <p style="font-size: 0.8rem; color: #94a3b8; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 5px;">Welcome</p>
                    <h3 style="font-size: 1.5rem; font-weight: 900; color: var(--primary-dark); margin-bottom: 8px;"><?php echo htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]); ?></h3>
                    <p style="color: #64748b; font-weight: 600; font-size: 0.85rem;">Student ID: #STU-<?php echo str_pad($user_id, 4, '0', STR_PAD_LEFT); ?></p>
                </div>

                <nav>
                    <a href="javascript:void(0)" onclick="switchTab('courses', this)" class="nav-link-tab nav-item-active">
                        <i class="fas fa-home-alt"></i> My Dashboard
                    </a>
                    <a href="classroom.php" class="nav-link-tab" style="color: var(--primary);">
                        <i class="fas fa-video"></i> My Live Class
                    </a>
                    <a href="courses.php" class="nav-link-tab">
                        <i class="fas fa-compass"></i> Find Teachers
                    </a>
                    <a href="javascript:void(0)" onclick="switchTab('support', this)" class="nav-link-tab">
                        <i class="fas fa-question-circle"></i> Help Center
                    </a>
                    <div style="margin-top: 30px; border-top: 1px solid #f1f5f9; padding-top: 25px;">
                        <a href="logout.php" style="color: #ef4444; font-weight: 700; text-decoration: none; padding: 10px 20px; display: flex; align-items: center; gap: 12px; border-radius: 12px; transition: 0.3s;" onmouseover="this.style.background='#fef2f2'" onmouseout="this.style.background='transparent'">
                            <i class="fas fa-arrow-right-from-bracket"></i> Sign Out
                        </a>
                    </div>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="dashboard-content">
            
            <!-- Tab: My Courses -->
            <div id="courses" class="tab-content active" data-aos="fade-up">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 40px;">
                    <div>
                        <h2 style="font-size: 2.2rem; font-weight: 900; color: var(--primary-dark); margin-bottom: 5px;">My Classroom</h2>
                        <p style="color: #64748b; font-weight: 600;">You have <?php echo count($my_courses); ?> active enrollments</p>
                    </div>
                </div>

                <div style="display: grid; gap: 25px;">
                    <?php 
                    $curr_day = date('D');
                    $curr_time = date('H:i:s');
                    
                    if (empty($my_courses)): ?>
                        <div style="text-align: center; padding: 100px 40px; background: white; border-radius: 40px; border: 2px dashed #e2e8f0;">
                            <div style="font-size: 4rem; color: #e2e8f0; margin-bottom: 25px;"><i class="fas fa-book-open"></i></div>
                            <h3 style="color: var(--primary-dark); font-weight: 800; margin-bottom: 15px;">No courses found</h3>
                            <p style="color: #94a3b8; max-width: 350px; margin: 0 auto 30px; font-weight: 600; line-height: 1.6;">Start your spiritual journey today. Enroll in your first course to see it here.</p>
                            <a href="courses.php" class="btn-premium-gold" style="display: inline-block; text-decoration: none; padding: 15px 40px;">Browse Catalog</a>
                        </div>
                    <?php else: 
                        foreach($my_courses as $course): 
                            $is_paid = ($course['payment_status'] == 'paid');
                            $days = explode(',', $course['schedule_days']);
                            $is_today = in_array($curr_day, $days);
                            
                            // Buffer check
                            $start_buffer = date('H:i:s', strtotime('-15 minutes', strtotime($course['time_start'] ?? '00:00:00')));
                            $end_buffer = date('H:i:s', strtotime('+15 minutes', strtotime($course['time_end'] ?? '23:59:59')));
                            $is_time = ($curr_time >= $start_buffer && $curr_time <= $end_buffer);
                            $can_join = $is_paid && ($is_today && $is_time);
                    ?>
                        <div class="course-card-premium">
                            <div style="flex: 1;">
                                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 15px;">
                                    <span class="status-pill <?php echo ($course['enroll_status'] == 'active' && $is_paid) ? 'status-paid' : ($course['enroll_status'] == 'pending' ? 'status-pending' : 'status-pending'); ?>" style="<?php echo $course['enroll_status'] == 'pending' ? 'background: #fef3c7; color: #92400e;' : ''; ?>">
                                        <?php 
                                            if($course['enroll_status'] == 'pending') echo '<i class="fas fa-clock me-1"></i> Assignment Pending';
                                            elseif($is_paid) echo '<i class="fas fa-check-circle me-1"></i> Paid';
                                            else echo '<i class="fas fa-clock me-1"></i> Pending Payment';
                                        ?>
                                    </span>
                                    <span style="font-weight: 800; font-size: 0.8rem; color: #94a3b8;"><i class="fas fa-hashtag me-1"></i> EP-<?php echo $course['id']; ?></span>
                                </div>
                                <h3 style="color: var(--primary-dark); font-weight: 900; margin-bottom: 10px; font-size: 1.6rem; letter-spacing: -0.5px;"><?php echo htmlspecialchars($course['title']); ?></h3>
                                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 25px;">
                                    <div style="width: 25px; height: 25px; background: #eee; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.7rem; font-weight: 900; color: #64748b;"><?php echo substr($course['tutor_name'], 0, 1); ?></div>
                                    <p style="margin: 0; color: #64748b; font-weight: 700; font-size: 0.95rem;">Instructor: <span style="color: var(--primary);"><?php echo htmlspecialchars($course['tutor_name']); ?></span></p>
                                    <?php 
                                        // Check if tutor was seen in the last 5 minutes
                                        $last_seen = strtotime($course['last_seen']);
                                        $is_active_now = (time() - $last_seen < 300); // 5 minutes
                                        if ($is_active_now && $course['is_online']):
                                    ?>
                                        <span class="live-badge"><i class="fas fa-circle" style="font-size: 0.5rem;"></i> Live Now</span>
                                    <?php endif; ?>
                                </div>
                                
                                <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                                    <div style="background: #f8fafc; padding: 12px 18px; border-radius: 12px; font-weight: 700; font-size: 0.85rem; color: #475569; border: 1px solid #f1f5f9; display: flex; align-items: center; gap: 10px;">
                                        <i class="fas fa-calendar-day" style="color: var(--accent); font-size: 1rem;"></i> <?php echo htmlspecialchars($course['schedule_days']); ?>
                                    </div>
                                    <div style="background: #f8fafc; padding: 12px 18px; border-radius: 12px; font-weight: 700; font-size: 0.85rem; color: #475569; border: 1px solid #f1f5f9; display: flex; align-items: center; gap: 10px;">
                                        <i class="fas fa-clock-three" style="color: var(--accent); font-size: 1rem;"></i> <?php echo htmlspecialchars($course['schedule_time']); ?>
                                    </div>
                                    <?php if($course['enroll_status'] == 'pending'): ?>
                                    <div style="background: #fffbeb; padding: 12px 18px; border-radius: 12px; font-weight: 700; font-size: 0.85rem; color: #92400e; border: 1px solid #fef3c7; display: flex; align-items: center; gap: 10px; width: 100%; margin-top: 10px;">
                                        <i class="fas fa-info-circle"></i> Waiting for Administrator to assign a teacher
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div style="text-align: right; min-width: 220px;">
                                <?php if($can_join && $course['enroll_status'] == 'active'): ?>
                                    <div style="display: flex; flex-direction: column; gap: 10px; align-items: flex-end;">
                                        <a href="classroom.php?room=PeaceRoom_<?php echo $course['id']; ?>_<?php echo md5($course['tutor_name']); ?>" class="btn-premium-gold pulse" style="display: inline-block; text-decoration: none; padding: 15px 35px; border-radius: 15px; font-size: 0.95rem; box-shadow: 0 15px 35px rgba(192, 141, 61, 0.25); width: 100%; text-align: center;">
                                            <i class="fas fa-video me-2"></i> Join Jitsi Class
                                        </a>
                                        <?php if(!empty($course['meeting_url'])): ?>
                                            <a href="<?php echo htmlspecialchars($course['meeting_url']); ?>" target="_blank" class="btn" style="display: inline-block; text-decoration: none; padding: 15px 35px; border-radius: 15px; font-size: 0.95rem; background: #2563eb; color: white; border: none; font-weight: 700; width: 100%; text-align: center;">
                                                <i class="fas fa-external-link-alt me-2"></i> Join Zoom/Meet
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php elseif($course['enroll_status'] == 'pending'): ?>
                                    <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 10px;">
                                        <span style="font-size: 0.75rem; font-weight: 800; color: #d97706; text-transform: uppercase; letter-spacing: 1px;">Assignment Pending</span>
                                        <button disabled style="background: #fffbeb; color: #d97706; padding: 18px 40px; border-radius: 18px; border: 2px dashed #fcd34d; font-weight: 800; cursor: not-allowed; min-width: 200px;">
                                            <i class="fas fa-user-clock me-2"></i> Pending
                                        </button>
                                    </div>
                                <?php elseif(!$is_paid): ?>
                                    <a href="payment.php?course_id=<?php echo $course['id']; ?>" class="btn-premium-gold" style="display: inline-block; text-decoration: none; padding: 15px 35px; border-radius: 15px; background: #ef4444; border: none; box-shadow: 0 10px 20px rgba(239, 68, 68, 0.2);">
                                        <i class="fas fa-credit-card me-2"></i> Complete Payment
                                    </a>
                                <?php else: ?>
                                    <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 10px;">
                                        <span style="font-size: 0.75rem; font-weight: 800; color: #94a3b8; text-transform: uppercase; letter-spacing: 1px;">Session Offline</span>
                                        <button disabled style="background: #f8fafc; color: #cbd5e1; padding: 18px 40px; border-radius: 18px; border: 2px dashed #e2e8f0; font-weight: 800; cursor: not-allowed; min-width: 200px;">
                                            <i class="fas fa-lock me-2"></i> Locked
                                        </button>
                                        <p style="font-size: 0.75rem; color: #94a3b8; margin: 0; font-weight: 600;">Opens 15m before class</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>

            <!-- Tab: Support -->
            <div id="support" class="tab-content">
                <div style="margin-bottom: 30px;">
                    <h2 style="font-size: 1.8rem; font-weight: 800; color: var(--primary-dark);">Support & Complaints</h2>
                    <p style="color: var(--text-muted); font-weight: 600;">Report an issue or ask for help regarding your courses.</p>
                </div>

                <?php if($complaint_success): ?>
                    <div style="background: #dcfce7; color: #166534; padding: 18px; border-radius: 15px; margin-bottom: 30px; border: 1px solid #bbf7d0;">
                        <i class="fas fa-check-circle"></i> <?php echo $complaint_success; ?>
                    </div>
                <?php endif; ?>

                <?php if($complaint_error): ?>
                    <div style="background: #fee2e2; color: #991b1b; padding: 18px; border-radius: 15px; margin-bottom: 30px; border: 1px solid #fecaca;">
                        <i class="fas fa-times-circle"></i> <?php echo $complaint_error; ?>
                    </div>
                <?php endif; ?>

                <div class="card" style="background: white; padding: 40px; border-radius: 20px; border: 1px solid #f1f5f9; box-shadow: 0 10px 40px rgba(0,0,0,0.02);">
                    <form method="POST">
                        <input type="hidden" name="submit_complaint" value="1">
                        <div style="margin-bottom: 25px;">
                            <label style="display: block; font-weight: 800; color: var(--primary-dark); margin-bottom: 10px; font-size: 0.9rem; text-transform: uppercase;">Issue Subject</label>
                            <input type="text" name="subject" required class="form-control" placeholder="Brief summary of the issue" style="width: 100%; padding: 15px; border: 2px solid #f1f5f9; border-radius: 12px; background: #f8fafc; font-weight: 600;">
                        </div>
                        <div style="margin-bottom: 25px;">
                            <label style="display: block; font-weight: 800; color: var(--primary-dark); margin-bottom: 10px; font-size: 0.9rem; text-transform: uppercase;">Related Instructor</label>
                            <select name="tutor_id" style="width: 100%; padding: 15px; border: 2px solid #f1f5f9; border-radius: 12px; background: #f8fafc; font-weight: 600;">
                                <option value="">General Support / No Specific Instructor</option>
                                <?php foreach($enrolled_tutors as $t): ?>
                                    <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div style="margin-bottom: 30px;">
                            <label style="display: block; font-weight: 800; color: var(--primary-dark); margin-bottom: 10px; font-size: 0.9rem; text-transform: uppercase;">Detailed Message</label>
                            <textarea name="message" rows="6" required class="form-control" placeholder="Please describe your problem here..." style="width: 100%; padding: 15px; border: 2px solid #f1f5f9; border-radius: 12px; background: #f8fafc; font-weight: 600; resize: none;"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary" style="width: 100%; padding: 20px; font-weight: 800; font-size: 1.1rem; border-radius: 15px; background: #e53e3e; border: none; box-shadow: 0 10px 30px rgba(229, 62, 62, 0.2);">
                            Send Feedback / Report Issue
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
function switchTab(tabId, el) {
    // Switch tabs
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.getElementById(tabId).classList.add('active');
    
    // Update nav styles
    document.querySelectorAll('.nav-link-tab').forEach(nav => {
        nav.classList.remove('nav-item-active');
        nav.style.background = 'transparent';
        nav.style.color = 'var(--text-dark)';
    });
    
    el.classList.add('nav-item-active');
    el.style.color = 'white';
}
</script>

<?php include 'includes/footer.php'; ?>
