<?php
session_start();
require 'includes/db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Stats Logic (Enhanced)
// 1. Total Students
$stmt = $pdo->query("SELECT COUNT(*) FROM students");
$total_students = $stmt->fetchColumn();

// 2. Active Tutors (Approved)
$stmt = $pdo->query("SELECT COUNT(*) FROM tutors WHERE status='approved'");
$active_tutors = $stmt->fetchColumn();

// 3. Pending Approvals
$stmt = $pdo->query("SELECT COUNT(*) FROM tutors WHERE status='pending'");
$pending_tutors = $stmt->fetchColumn();

// 3a. Pending Courses
$stmt = $pdo->query("SELECT COUNT(*) FROM courses WHERE status='pending'");
$pending_courses = $stmt->fetchColumn();

// 4. Total Revenue (Mock Calculation + Real from Enrollments if any paid)
// Calculate potential revenue from active enrollments (Assuming monthly avg $80)
$stmt = $pdo->query("SELECT COUNT(*) FROM enrollments WHERE status='active'");
$active_enrollments = $stmt->fetchColumn();
$estimated_revenue = $active_enrollments * 80; 

// Recent Activity (Mock + Real)
$stmt = $pdo->query("SELECT name, created_at, 'student' as type FROM students ORDER BY created_at DESC LIMIT 5");
$recent_students = $stmt->fetchAll();

$stmt = $pdo->query("SELECT name, created_at, 'tutor' as type FROM tutors ORDER BY created_at DESC LIMIT 5");
$recent_tutors = $stmt->fetchAll();

include 'includes/admin_header_layout.php';
?>

<!-- Include Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="d-flex" id="wrapper">
    
    <?php include 'includes/admin_sidebar.php'; ?>

    <!-- Main Content -->
    <div id="page-content-wrapper">
        <!-- Top Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 px-4 mb-4 border-bottom shadow-sm">
            <div class="container-fluid">
                <div class="d-flex align-items-center">
                    <button class="btn btn-light d-lg-none me-3" id="menu-toggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h4 class="fw-bold mb-0 text-dark">Dashboard Overview</h4>
                </div>
                
                <div class="d-flex align-items-center gap-4">
                    <div class="search-bar d-none d-md-flex align-items-center bg-light px-3 py-2 rounded-pill">
                        <i class="fas fa-search text-muted me-2"></i>
                        <input type="text" class="border-0 bg-transparent" placeholder="Search data..." style="outline: none; font-size: 0.9rem; width: 200px;">
                    </div>
                    
                    <div class="notifications position-relative cursor-pointer">
                        <i class="fas fa-bell fs-5 text-muted"></i>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.5rem;">
                            3+
                        </span>
                    </div>

                    <div class="user-profile">
                        <img src="https://ui-avatars.com/api/?name=Admin&background=0F5132&color=fff" class="avatar">
                        <div class="user-info d-none d-sm-flex">
                            <span class="name">Administrator</span>
                            <span class="role text-muted">Super Admin</span>
                        </div>
                        <i class="fas fa-chevron-down ms-2 text-muted small"></i>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid px-4">
            
            <!-- Welcome Banner -->
            <div class="welcome-banner mb-4 p-4 rounded-4 shadow-sm">
                <div class="row align-items-center">
                    <div class="col-lg-8 text-white">
                        <h2 class="fw-bold mb-2">Welcome Back, Admin! 👋</h2>
                        <p class="opacity-75 mb-0">Here's what is happening with Baitul Islam today. 
                            You have <span class="text-warning fw-bold"><?php echo $pending_tutors; ?> pending tutor approvals</span> 
                            and <span class="text-warning fw-bold"><?php echo $pending_courses; ?> pending course requests</span> that need your attention.
                        </p>
                    </div>
                    <div class="col-lg-4 text-end d-none d-lg-block">
                        <i class="fas fa-chart-line text-white opacity-25" style="font-size: 5rem;"></i>
                    </div>
                </div>
            </div>
            
            <!-- Expanded Stats Grid -->
            <div class="row g-4 mb-2">
                <!-- Stat 1: Revenue -->
                <div class="col-xl-3 col-sm-6">
                    <div class="stat-widget h-100 p-4 bg-white border-0 shadow-sm rounded-4 position-relative overflow-hidden transition-all">
                        <div class="d-flex justify-content-between mb-3">
                            <div class="stat-icon bg-success-subtle text-success p-2 rounded-3">
                                <i class="fas fa-wallet fa-lg"></i>
                            </div>
                            <i class="fas fa-ellipsis-h text-muted"></i>
                        </div>
                        <h3 class="fw-bold mb-1">$<?php echo number_format($estimated_revenue); ?></h3>
                        <p class="text-muted small mb-0 fw-medium">Estimated Revenue</p>
                        <div class="mt-3 d-flex align-items-center">
                            <span class="badge bg-success-subtle text-success rounded-pill px-2 py-1 me-2" style="font-size: 0.7rem;">
                                <i class="fas fa-arrow-up me-1"></i> 12.5%
                            </span>
                            <span class="text-muted small">vs last month</span>
                        </div>
                    </div>
                </div>

                <!-- Stat 2: Students -->
                <div class="col-xl-3 col-sm-6">
                    <div class="stat-widget h-100 p-4 bg-white border-0 shadow-sm rounded-4 position-relative overflow-hidden transition-all">
                        <div class="d-flex justify-content-between mb-3">
                            <div class="stat-icon bg-primary-subtle text-primary p-2 rounded-3">
                                <i class="fas fa-user-graduate fa-lg"></i>
                            </div>
                            <i class="fas fa-ellipsis-h text-muted"></i>
                        </div>
                        <h3 class="fw-bold mb-1"><?php echo $total_students; ?></h3>
                        <p class="text-muted small mb-0 fw-medium">Total Students</p>
                        <div class="mt-3 d-flex align-items-center">
                            <span class="badge bg-primary-subtle text-primary rounded-pill px-2 py-1 me-2" style="font-size: 0.7rem;">
                                <i class="fas fa-plus me-1"></i> 5 new
                            </span>
                            <span class="text-muted small">joined today</span>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-sm-6">
                    <div class="stat-widget h-100 p-4 bg-white border-0 shadow-sm rounded-4 position-relative overflow-hidden transition-all">
                        <div class="d-flex justify-content-between mb-3">
                            <div class="stat-icon bg-warning-subtle text-warning p-2 rounded-3">
                                <i class="fas fa-chalkboard-teacher fa-lg"></i>
                            </div>
                            <i class="fas fa-ellipsis-h text-muted"></i>
                        </div>
                        <h3 class="fw-bold mb-1"><?php echo $active_tutors; ?></h3>
                        <p class="text-muted small mb-0 fw-medium">Active Tutors</p>
                        <div class="mt-3 d-flex align-items-center">
                            <span class="badge bg-warning-subtle text-warning rounded-pill px-2 py-1 me-2" style="font-size: 0.7rem;">
                                <?php echo $pending_tutors; ?> Tutor | <?php echo $pending_courses; ?> Course PDG
                            </span>
                        </div>
                    </div>
                </div>

                <!-- Stat 4: Enrollments -->
                <div class="col-xl-3 col-sm-6">
                    <div class="stat-widget h-100 p-4 bg-white border-0 shadow-sm rounded-4 position-relative overflow-hidden transition-all">
                        <div class="d-flex justify-content-between mb-3">
                            <div class="stat-icon bg-info-subtle text-info p-2 rounded-3">
                                <i class="fas fa-calendar-check fa-lg"></i>
                            </div>
                            <i class="fas fa-ellipsis-h text-muted"></i>
                        </div>
                        <h3 class="fw-bold mb-1"><?php echo $active_enrollments; ?></h3>
                        <p class="text-muted small mb-0 fw-medium">Active Enrollments</p>
                        <div class="mt-3 d-flex align-items-center">
                            <span class="badge bg-info-subtle text-info rounded-pill px-2 py-1 me-2" style="font-size: 0.7rem;">
                                <i class="fas fa-check me-1"></i> High
                            </span>
                            <span class="text-muted small">Engagement rate</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts & Activity Grid -->
            <div class="row g-4 mb-2">
                <!-- Analytics Chart -->
                <div class="col-lg-8">
                    <div class="bg-white p-4 rounded-4 shadow-sm border-0 h-100">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div>
                                <h5 class="fw-bold text-dark mb-1">Growth Analytics</h5>
                                <p class="text-muted small mb-0">Monthly revenue and enrollment trends</p>
                            </div>
                            <select class="form-select form-select-sm w-auto border-0 bg-light rounded-3">
                                <option>Last 6 Months</option>
                            </select>
                        </div>
                        <div style="height: 320px;">
                            <canvas id="revenueChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="col-lg-4">
                    <div class="bg-white p-4 rounded-4 shadow-sm border-0 h-100">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="fw-bold text-dark mb-0">Recent Activity</h5>
                            <a href="#" class="text-decoration-none small fw-bold" style="color: #0F5132;">See More</a>
                        </div>
                        <div class="activity-timeline">
                            <?php 
                            $activities = array_merge(
                                array_map(function($s){ return ['type'=>'student', 'name'=>$s['name'], 'time'=>$s['created_at'], 'action'=>'Registered as a new student']; }, $recent_students),
                                array_map(function($t){ return ['type'=>'tutor', 'name'=>$t['name'], 'time'=>$t['created_at'], 'action'=>'Applied for a tutor position']; }, $recent_tutors)
                            );
                            usort($activities, function($a, $b){ return strtotime($b['time']) - strtotime($a['time']); });
                            foreach(array_slice($activities, 0, 6) as $act): ?>
                                <div class="timeline-item d-flex gap-3 mb-4">
                                    <div class="d-flex flex-column align-items-center">
                                        <div class="timeline-icon bg-<?php echo $act['type'] == 'student' ? 'primary' : 'warning'; ?> p-2 rounded-2 text-white" style="width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; font-size: 0.8rem;">
                                            <i class="fas <?php echo $act['type'] == 'student' ? 'fa-user-plus' : 'fa-chalkboard-teacher'; ?>"></i>
                                        </div>
                                        <div class="flex-grow-1 bg-light mt-2" style="width: 2px;"></div>
                                    </div>
                                    <div>
                                        <h6 class="fw-bold mb-1 text-dark" style="font-size: 0.9rem;"><?php echo htmlspecialchars($act['name']); ?></h6>
                                        <p class="text-muted small mb-1"><?php echo $act['action']; ?></p>
                                        <span class="text-muted opacity-75" style="font-size: 0.75rem;"><i class="far fa-clock me-1"></i> <?php echo date('M d, h:i A', strtotime($act['time'])); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="row g-4 mb-2">
                <div class="col-12">
                     <div class="bg-white p-4 rounded-4 shadow-sm border-0">
                        <h5 class="fw-bold text-dark mb-4">Quick Management</h5>
                        <div class="row g-3 text-center">
                            <div class="col-md-3 col-6">
                                <a href="admin_tutors.php" class="d-block p-3 rounded-4 border border-light-subtle text-decoration-none transition-all hover-bg-light">
                                    <div class="bg-success-subtle text-success p-3 rounded-circle d-inline-block mb-2">
                                        <i class="fas fa-check-double fa-lg"></i>
                                    </div>
                                    <span class="d-block fw-bold small text-dark">Approve Tutors</span>
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="admin_enrollments.php" class="d-block p-3 rounded-4 border border-light-subtle text-decoration-none transition-all hover-bg-light">
                                    <div class="bg-primary-subtle text-primary p-3 rounded-circle d-inline-block mb-2">
                                        <i class="fas fa-users-cog fa-lg"></i>
                                    </div>
                                    <span class="d-block fw-bold small text-dark">Enrollments</span>
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="admin_settings.php" class="d-block p-3 rounded-4 border border-light-subtle text-decoration-none transition-all hover-bg-light">
                                    <div class="bg-warning-subtle text-warning p-3 rounded-circle d-inline-block mb-2">
                                        <i class="fas fa-sliders-h fa-lg"></i>
                                    </div>
                                    <span class="d-block fw-bold small text-dark">Settings</span>
                                </a>
                            </div>
                            <div class="col-md-3 col-6">
                                <a href="admin_content.php" class="d-block p-3 rounded-4 border border-light-subtle text-decoration-none transition-all hover-bg-light">
                                    <div class="bg-info-subtle text-info p-3 rounded-circle d-inline-block mb-2">
                                        <i class="fas fa-layer-group fa-lg"></i>
                                    </div>
                                    <span class="d-block fw-bold small text-dark">CMS Editor</span>
                                </a>
                            </div>
                        </div>
                     </div>
                </div>
            </div>

        </div>
    </div>
</div>

<style>
    :root {
        --sidebar-bg: #0F5132;
        --sidebar-text: rgba(255,255,255,0.8);
        --accent-gold: #D4AF37;
        --bg-body: #f8fafc;
    }
    
    body { background-color: var(--bg-body); font-family: 'Outfit', sans-serif; overflow-x: hidden; color: #334155; }
    
    #page-content-wrapper {
        flex-grow: 1;
        min-width: 0;
        transition: 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    .welcome-banner {
        background: linear-gradient(135deg, #0F5132 0%, #166534 100%);
        position: relative; overflow: hidden;
    }
    .welcome-banner::after {
        content: ''; position: absolute; top: -50%; right: -10%; width: 300px; height: 300px;
        background: rgba(255,255,255,0.05); border-radius: 50%;
    }

    .stat-widget:hover { transform: translateY(-5px); }
    .transition-all { transition: all 0.3s ease; }
    .hover-bg-light:hover { background-color: #f8fafc; border-color: #0F5132 !important; }

    @media (max-width: 992px) {
        #page-content-wrapper { margin-left: 0; width: 100%; }
        #sidebar-wrapper { margin-left: -280px; position: fixed; height: 100vh; z-index: 1050; }
        #wrapper.toggled #sidebar-wrapper { margin-left: 0; }
    }

    .user-profile {
        display: flex; align-items: center; background: #fff; padding: 6px 12px;
        border-radius: 12px; transition: 0.3s; cursor: pointer; border: 1px solid #f1f5f9;
    }
    .user-profile:hover { background: #f8fafc; }
    .avatar { width: 36px; height: 36px; border-radius: 10px; object-fit: cover; }
    .user-info .name { font-weight: 700; font-size: 0.85rem; color: #1e293b; }
    .user-info .role { font-size: 0.7rem; }
</style>

<script>
    // Revenue & Signups Chart
    const ctx = document.getElementById('revenueChart').getContext('2d');
    const gradRevenue = ctx.createLinearGradient(0, 0, 0, 300);
    gradRevenue.addColorStop(0, 'rgba(15, 81, 50, 0.15)');
    gradRevenue.addColorStop(1, 'rgba(15, 81, 50, 0.0)');

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [
                {
                    label: 'Revenue ($)',
                    data: [1200, 1900, 3000, 5000, 4500, <?php echo $estimated_revenue > 0 ? $estimated_revenue : 6000; ?>],
                    borderColor: '#0F5132',
                    backgroundColor: gradRevenue,
                    borderWidth: 3,
                    tension: 0.4,
                    fill: true,
                    pointRadius: 4,
                    pointBackgroundColor: '#fff',
                    pointBorderWidth: 2
                },
                {
                    label: 'New Students',
                    type: 'bar',
                    data: [5, 12, 19, 25, 20, <?php echo $total_students > 0 ? $total_students : 30; ?>],
                    backgroundColor: '#D4AF37',
                    borderRadius: 6,
                    barThickness: 15
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'top', align: 'end', labels: { boxWidth: 10, usePointStyle: true, font: { family: 'Outfit', weight: '600' } } }
            },
            scales: {
                y: { grid: { color: '#f1f5f9' }, ticks: { font: { family: 'Outfit' } } },
                x: { grid: { display: false }, ticks: { font: { family: 'Outfit' } } }
            }
        }
    });

    // Sidebar Toggle
    document.getElementById("menu-toggle")?.addEventListener("click", function(e) {
        e.preventDefault();
        document.getElementById("wrapper").classList.toggle("toggled");
    });
</script>

<?php include 'includes/admin_footer.php'; ?>
