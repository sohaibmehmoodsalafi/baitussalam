<?php
session_start();
require 'includes/db.php';

// Force error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

$course_id = $_REQUEST['id'] ?? $_POST['course_id_hidden'] ?? null;
if (!$course_id) { die("Fatal Error: Missing Course ID."); }

$msg = '';
$msg_type = '';

// 💥 THE BIG UPDATE LOGIC
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_force'])) {
    try {
        $sql = "UPDATE courses SET 
                title = ?, 
                description = ?, 
                tutor_id = ?, 
                price = ?, 
                schedule_days = ?, 
                schedule_time = ?, 
                status = ? 
                WHERE id = ?";
        
        $stmt = $pdo->prepare($sql);
        $res = $stmt->execute([
            $_POST['title'],
            $_POST['description'],
            $_POST['tutor_id'],
            $_POST['price'],
            $_POST['schedule_days'],
            $_POST['schedule_time'],
            $_POST['status'],
            $course_id
        ]);

        if ($res) {
            $msg = "🎉 UPDATE SUCCESSFUL! Timing is now: " . $_POST['schedule_time'];
            $msg_type = "success";
        } else {
            $msg = "❌ DATABASE REJECTED UPDATE.";
            $msg_type = "danger";
        }
    } catch (Exception $e) {
        $msg = "❌ SYSTEM ERROR: " . $e->getMessage();
        $msg_type = "danger";
    }
}

// FRESH FETCH
$stmt = $pdo->prepare("SELECT c.*, t.name as tutor_name FROM courses c JOIN tutors t ON c.tutor_id = t.id WHERE c.id = ?");
$stmt->execute([$course_id]);
$course = $stmt->fetch();
if (!$course) { die("Course not found."); }

$tutors = $pdo->query("SELECT id, name FROM tutors ORDER BY name ASC")->fetchAll();
include 'includes/admin_header_layout.php';
?>

<div class="d-flex" id="wrapper">
    <?php include 'includes/admin_sidebar.php'; ?> 
    <div id="page-content-wrapper">
        <div class="container-fluid p-4">
            
            <?php if ($msg): ?>
                <div class="alert alert-<?php echo $msg_type; ?> shadow-lg border-0 p-4 mb-4">
                    <h3 class="fw-bold"><?php echo $msg; ?></h3>
                    <p>Current Time in DB: <strong><?php echo $course['schedule_time']; ?></strong></p>
                </div>
            <?php endif; ?>

            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-header bg-dark text-white p-3">
                    <h5 class="mb-0">FORCE EDITOR (ID: #<?php echo $course['id']; ?>)</h5>
                </div>
                <div class="card-body p-4">
                    <form method="POST">
                        <input type="hidden" name="course_id_hidden" value="<?php echo $course['id']; ?>">
                        
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="fw-bold">Course Title</label>
                                <input type="text" name="title" class="form-control" value="<?php echo htmlspecialchars($course['title']); ?>">
                            </div>
                            
                            <div class="col-md-6">
                                <label class="fw-bold text-danger">Schedule Days (ENTER NEW HERE)</label>
                                <input type="text" name="schedule_days" class="form-control border-danger" value="<?php echo htmlspecialchars($course['schedule_days']); ?>">
                            </div>

                            <div class="col-md-6">
                                <label class="fw-bold text-danger">Schedule Time (ENTER NEW HERE)</label>
                                <input type="text" name="schedule_time" class="form-control border-danger" value="<?php echo htmlspecialchars($course['schedule_time']); ?>">
                            </div>

                            <div class="col-md-6">
                                <label class="fw-bold">Instructor</label>
                                <select name="tutor_id" class="form-select">
                                    <?php foreach($tutors as $t): ?>
                                        <option value="<?php echo $t['id']; ?>" <?php echo $t['id'] == $course['tutor_id'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($t['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-6">
                                <label class="fw-bold">Price</label>
                                <input type="number" name="price" class="form-control" value="<?php echo $course['price']; ?>">
                            </div>

                            <div class="col-12">
                                <label class="fw-bold">Description</label>
                                <textarea name="description" class="form-control" rows="3"><?php echo htmlspecialchars($course['description']); ?></textarea>
                            </div>

                            <div class="col-md-6">
                                <label class="fw-bold">Status</label>
                                <select name="status" class="form-select">
                                    <option value="approved">Approved</option>
                                    <option value="pending">Pending</option>
                                </select>
                            </div>

                            <div class="col-12 text-center mt-5">
                                <button type="submit" name="submit_force" class="btn btn-warning btn-lg px-5 py-3 fw-bold shadow-lg" style="background:#ff5722; color:white; border:none; font-size: 1.5rem;">
                                    🔥 CLICK TO FORCE UPDATE
                                </button>
                                <br>
                                <small class="text-muted">If this button is ORANGE, you are using the correct file.</small>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'includes/admin_footer.php'; ?>
