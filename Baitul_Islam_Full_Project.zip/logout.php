<?php
require_once 'includes/session_security.php';

// Start session and logout securely
SessionSecurity::startSecureSession();
SessionSecurity::logout('index.php');
?>
