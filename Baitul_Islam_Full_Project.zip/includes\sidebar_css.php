/* Shared Sidebar CSS - Enhanced Premium Look */
:root {
    --sidebar-bg: #0F5132;
    --sidebar-grad: linear-gradient(180deg, #0F5132 0%, #062c1a 100%);
    --sidebar-text: rgba(255,255,255,0.7);
    --accent-gold: #D4AF37;
    --accent-gold-soft: rgba(212, 175, 55, 0.1);
}

#wrapper { overflow-x: hidden; }

.glass-sidebar {
    width: 280px;
    min-height: 100vh;
    background: var(--sidebar-grad);
    color: white;
    display: flex;
    flex-direction: column;
    box-shadow: 10px 0 30px rgba(0,0,0,0.1);
    z-index: 1000;
}

.sidebar-heading { padding: 30px 25px; }
.brand-box {
    font-size: 1.5rem; font-weight: 800; color: #fff;
    display: flex; align-items: center; gap: 12px;
    padding: 12px; border-radius: 15px;
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
}
.brand-box i { color: var(--accent-gold); font-size: 1.8rem; }

.sidebar-link {
    display: flex; align-items: center; 
    padding: 14px 20px; color: var(--sidebar-text); text-decoration: none;
    font-weight: 500; font-size: 0.95rem; margin: 4px 20px; border-radius: 12px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.sidebar-link i { font-size: 1.1rem; width: 25px; margin-right: 12px; transition: transform 0.3s; }

.sidebar-link:hover {
    background: rgba(255,255,255,0.08); color: #fff; transform: translateX(5px);
}
.sidebar-link:hover i { transform: scale(1.1); }

.sidebar-link.active {
    background: var(--accent-gold); color: #0F5132; font-weight: 700;
    box-shadow: 0 10px 20px rgba(212, 175, 55, 0.2);
}
.sidebar-link.active i { color: #0F5132; }

.menu-label {
    font-size: 0.75rem; color: rgba(255,255,255,0.3); text-transform: uppercase;
    font-weight: 700; letter-spacing: 1.5px; padding: 25px 25px 8px;
}

.logout-container { margin-top: auto; padding: 30px 20px; }
.logout-btn {
    display: flex; align-items: center; justify-content: center; gap: 10px;
    width: 100%; padding: 14px;
    background: rgba(239, 68, 68, 0.1); color: #ef4444; border-radius: 12px;
    text-decoration: none; font-weight: 600; transition: all 0.3s;
    border: 1px solid rgba(239, 68, 68, 0.1);
}
.logout-btn:hover { background: #ef4444; color: white; transform: translateY(-3px); box-shadow: 0 10px 20px rgba(239, 68, 68, 0.2); }
