<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/send_email.php';

$message = '';
$error = '';
$step = isset($_GET['step']) ? $_GET['step'] : 'email';

// Step 1: Email Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_email'])) {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $user_type = $_POST['user_type'] ?? 'student';
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        $table = ($user_type === 'tutor') ? 'tutors' : 'students';
        $stmt = $pdo->prepare("SELECT id, name, email FROM $table WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user) {
            // Generate 6-digit OTP
            $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
            $otp_expiry = date('Y-m-d H:i:s', strtotime('+10 minutes'));
            
            // Store OTP in database
            $stmt = $pdo->prepare("UPDATE $table SET reset_otp = ?, reset_otp_expiry = ? WHERE email = ?");
            $stmt->execute([$otp, $otp_expiry, $email]);
            
            // Send OTP via email
            $emailResult = sendOTPEmail($email, $user['name'], $otp);
            if ($emailResult['success']) {
                $_SESSION['reset_email'] = $email;
                $_SESSION['reset_user_type'] = $user_type;
                header("Location: forgot_password_otp.php?step=verify");
                exit;
            } else {
                $error = "Failed to send OTP email: " . $emailResult['message'];
            }
        } else {
            $error = "No account found with this email address.";
        }
    }
}

// Step 2: OTP Verification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_otp'])) {
    $entered_otp = $_POST['otp'];
    $email = $_SESSION['reset_email'] ?? '';
    $user_type = $_SESSION['reset_user_type'] ?? 'student';
    
    if (empty($email)) {
        header("Location: forgot_password_otp.php");
        exit;
    }
    
    $table = ($user_type === 'tutor') ? 'tutors' : 'students';
    $stmt = $pdo->prepare("SELECT id, name, reset_otp, reset_otp_expiry FROM $table WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user && $user['reset_otp'] === $entered_otp && strtotime($user['reset_otp_expiry']) > time()) {
        // OTP verified, generate reset token
        $reset_token = bin2hex(random_bytes(32));
        $reset_expiry = date('Y-m-d H:i:s', strtotime('+30 minutes'));
        
        $stmt = $pdo->prepare("UPDATE $table SET reset_token = ?, reset_token_expiry = ?, reset_otp = NULL, reset_otp_expiry = NULL WHERE email = ?");
        $stmt->execute([$reset_token, $reset_expiry, $email]);
        
        header("Location: reset_password.php?token=" . $reset_token . "&type=" . $user_type);
        exit;
    } else {
        $error = "Invalid or expired OTP. Please try again.";
        $step = 'verify';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Peace Institute</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Outfit', sans-serif;
            background: linear-gradient(135deg, #0F5132 0%, #167448 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 500px;
            width: 100%;
            padding: 40px;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo h1 {
            color: #0F5132;
            font-size: 2rem;
            margin-bottom: 5px;
        }
        .logo p {
            color: #666;
            font-size: 0.9rem;
        }
        .form-group {
            margin-bottom: 25px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }
        input, select {
            width: 100%;
            padding: 14px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s;
        }
        input:focus, select:focus {
            outline: none;
            border-color: #D4AF37;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        .otp-input {
            text-align: center;
            font-size: 1.5rem;
            letter-spacing: 10px;
            font-weight: bold;
            font-family: 'Courier New', monospace;
        }
        .btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #0F5132, #167448);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(15, 81, 50, 0.3);
        }
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            color: #0F5132;
            text-decoration: none;
            font-weight: 600;
        }
        .back-link a:hover {
            color: #D4AF37;
        }
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196F3;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .info-box i {
            color: #2196F3;
            margin-right: 10px;
        }
        .footer {
            background: rgba(255,255,255,0.95);
            border-radius: 15px;
            padding: 25px;
            margin-top: 30px;
            max-width: 500px;
            width: 100%;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .footer h3 {
            color: #0F5132;
            margin-bottom: 15px;
            font-size: 1.2rem;
        }
        .footer-info {
            display: grid;
            grid-template-columns: 1fr;
            gap: 10px;
            margin-top: 15px;
        }
        .footer-item {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            color: #555;
            font-size: 0.9rem;
        }
        .footer-item i {
            color: #D4AF37;
            width: 20px;
        }
        .footer-item a {
            color: #0F5132;
            text-decoration: none;
        }
        .footer-item a:hover {
            color: #D4AF37;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <h1><i class="fas fa-key"></i> Forgot Password</h1>
            <p><?php echo $step === 'verify' ? 'Enter OTP Code' : 'Enter your email to reset password'; ?></p>
        </div>

        <?php if($message): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if($error): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <?php if ($step === 'email'): ?>
            <div class="info-box">
                <i class="fas fa-info-circle"></i>
                <strong>Secure Process:</strong> We'll send a 6-digit OTP to your email for verification.
            </div>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="user_type">
                        <i class="fas fa-user-tag"></i> I am a:
                    </label>
                    <select name="user_type" id="user_type" required>
                        <option value="student">Student</option>
                        <option value="tutor">Tutor</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="email">
                        <i class="fas fa-envelope"></i> Email Address
                    </label>
                    <input 
                        type="email" 
                        id="email" 
                        name="email" 
                        placeholder="Enter your registered email"
                        required
                    >
                </div>

                <button type="submit" name="submit_email" class="btn">
                    <i class="fas fa-paper-plane"></i> Send OTP
                </button>
            </form>
        <?php elseif ($step === 'verify'): ?>
            <div class="info-box">
                <i class="fas fa-envelope-open-text"></i>
                <strong>Check your email!</strong> We've sent a 6-digit OTP to <strong><?php echo htmlspecialchars($_SESSION['reset_email'] ?? ''); ?></strong>
            </div>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="otp">
                        <i class="fas fa-lock"></i> Enter OTP Code
                    </label>
                    <input 
                        type="text" 
                        id="otp" 
                        name="otp" 
                        class="otp-input"
                        placeholder="000000"
                        maxlength="6"
                        pattern="[0-9]{6}"
                        required
                        autofocus
                    >
                    <small style="display: block; margin-top: 5px; color: #666; text-align: center;">
                        OTP valid for 10 minutes
                    </small>
                </div>

                <button type="submit" name="verify_otp" class="btn">
                    <i class="fas fa-check-circle"></i> Verify OTP
                </button>
            </form>

            <div class="back-link">
                <a href="forgot_password_otp.php">
                    <i class="fas fa-arrow-left"></i> Request New OTP
                </a>
            </div>
        <?php endif; ?>

        <div class="back-link">
            <a href="login.php">
                <i class="fas fa-sign-in-alt"></i> Back to Login
            </a>
        </div>
    </div>

    <div class="footer">
        <h3><i class="fas fa-graduation-cap"></i> <?php echo ORG_NAME; ?></h3>
        <div class="footer-info">
            <div class="footer-item">
                <i class="fas fa-envelope"></i>
                <a href="mailto:<?php echo ORG_EMAIL; ?>"><?php echo ORG_EMAIL; ?></a>
            </div>
            <div class="footer-item">
                <i class="fas fa-phone"></i>
                <span><?php echo ORG_PHONE; ?></span>
            </div>
            <div class="footer-item">
                <i class="fas fa-map-marker-alt"></i>
                <span><?php echo ORG_ADDRESS; ?></span>
            </div>
            <div class="footer-item">
                <i class="fas fa-globe"></i>
                <a href="http://<?php echo ORG_WEBSITE; ?>" target="_blank"><?php echo ORG_WEBSITE; ?></a>
            </div>
        </div>
    </div>

    <script>
        // Auto-format OTP input
        const otpInput = document.getElementById('otp');
        if (otpInput) {
            otpInput.addEventListener('input', function(e) {
                this.value = this.value.replace(/[^0-9]/g, '');
            });
        }
    </script>
</body>
</html>
