<?php include 'includes/header.php'; ?>

<!-- Luxury Scroll Progress Bar -->
<div id="scroll-progress" style="position: fixed; top: 0; left: 0; width: 0%; height: 5px; background: linear-gradient(to right, var(--accent), var(--accent-light)); z-index: 10000; transition: width 0.1s ease-out;"></div>

<!-- Premium Blog Hero Section - Ultra Luxury -->
<section style="
    background: linear-gradient(rgba(0, 33, 71, 0.94), rgba(0, 8, 20, 0.96)), url('assets/images/page_header_bg.png');
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    padding: 220px 0 160px;
    text-align: center;
    color: white;
    position: relative;
    overflow: hidden;
">
    <!-- Sophisticated Animated Background Layers -->
    <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: radial-gradient(circle at 50% 50%, rgba(253,200,0,0.06) 0%, transparent 80%); pointer-events: none;"></div>
    
    <!-- Moving Light Rays -->
    <div style="position: absolute; top: -50%; left: -50%; width: 200%; height: 200%; background: conic-gradient(from 0deg at 50% 50%, transparent, rgba(253,200,0,0.015) 15deg, transparent 30deg); animation: rotate-slow 100s infinite linear; pointer-events: none; opacity: 0.6;"></div>

    <!-- Luxury Floating Particles & Icons -->
    <div class="particle" style="position: absolute; top: 15%; left: 10%; width: 4px; height: 4px; background: var(--accent); border-radius: 50%; box-shadow: 0 0 15px var(--accent); animation: float-up 12s infinite;"></div>
    <div class="particle" style="position: absolute; top: 40%; left: 85%; width: 6px; height: 6px; background: rgba(255,255,255,0.2); border-radius: 50%; animation: float-up 18s infinite;"></div>
    
    <!-- Floating Islamic Motifs (Refined) -->
    <i class="fas fa-quran" style="position: absolute; top: 15%; right: 12%; font-size: 3rem; color: rgba(253,200,0,0.05); animation: float-slow 10s infinite ease-in-out;"></i>
    <i class="fas fa-kaaba" style="position: absolute; bottom: 25%; left: 10%; font-size: 3.5rem; color: rgba(255,255,255,0.03); animation: float-slow 12s infinite ease-in-out reverse;"></i>
    <i class="fas fa-mosque" style="position: absolute; top: 20%; left: 20%; font-size: 2.5rem; color: rgba(253,200,0,0.04); animation: float-slow 15s infinite ease-in-out 1s;"></i>

    <!-- Large Geometric Mandalas (Enhanced) -->
    <div style="position: absolute; top: -150px; right: -200px; width: 800px; height: 800px; background: url('assets/images/hero_pattern.png'); background-size: contain; opacity: 0.12; filter: brightness(2) invert(1); animation: rotate-slow 100s infinite linear;"></div>
    <div style="position: absolute; bottom: -200px; left: -250px; width: 700px; height: 700px; background: url('assets/images/hero_pattern.png'); background-size: contain; opacity: 0.08; filter: brightness(2) invert(1); animation: rotate-slow 80s infinite linear reverse;"></div>
    
    <!-- Luxury Glow Orbs -->
    <div class="glow-orb" style="position: absolute; top: 10%; left: 5%; width: 600px; height: 600px; background: radial-gradient(circle, rgba(253,200,0,0.1) 0%, transparent 70%); border-radius: 50%; filter: blur(100px); animation: float 18s infinite alternate;"></div>
    <div class="glow-orb" style="position: absolute; bottom: 0%; right: 5%; width: 500px; height: 500px; background: radial-gradient(circle, rgba(0, 174, 239, 0.08) 0%, transparent 70%); border-radius: 50%; filter: blur(80px); animation: float 22s infinite alternate-reverse;"></div>
    
    <!-- Grainy / Texture Overlay -->
    <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: url('https://www.transparenttextures.com/patterns/stardust.png'); opacity: 0.3; pointer-events: none; mix-blend-mode: soft-light;"></div>
    
    <!-- Premium Bottom Gradient Blur -->
    <div style="position: absolute; bottom: 0; left: 0; width: 100%; height: 250px; background: linear-gradient(to top, #ffffff 0%, rgba(255,255,255,0.8) 20%, transparent 100%); z-index: 1;"></div>
    
    <div class="container" style="position: relative; z-index: 5;">
        <div data-aos="fade-down" style="display: inline-flex; align-items: center; gap: 15px; padding: 12px 35px; background: rgba(255,255,255,0.04); backdrop-filter: blur(40px); border-radius: 100px; border: 1px solid rgba(255,255,255,0.15); margin-bottom: 30px; box-shadow: 0 20px 40px rgba(0,0,0,0.3); position: relative; overflow: hidden;">
            <div style="position: absolute; inset: 0; background: linear-gradient(90deg, transparent, rgba(253,200,0,0.1), transparent); animation: shimmer 4s infinite;"></div>
            <i class="fas fa-sparkles" style="color: var(--accent); font-size: 0.9rem; position: relative; z-index: 2;"></i>
            <span style="font-weight: 800; font-size: 0.85rem; color: #fff; text-transform: uppercase; letter-spacing: 5px; position: relative; z-index: 2;">Knowledge & Spiritual Excellence</span>
        </div>
        
        <div style="margin-bottom: 35px;">
            <h2 data-aos="fade-up" data-aos-delay="100" style="font-size: 2.2rem; font-weight: 400; color: rgba(255,255,255,0.8); margin: 0; letter-spacing: 15px; text-transform: uppercase; font-family: 'Outfit', sans-serif;">Baitul Islam</h2>
            <h1 data-aos="zoom-in" data-aos-duration="1200" style="font-size: 7.5rem; font-weight: 950; margin: 5px 0 0; line-height: 1; letter-spacing: -4px; text-shadow: 0 30px 60px rgba(0,0,0,0.7); font-family: 'Outfit', sans-serif;">
                <span style="background: linear-gradient(135deg, #FDC800 0%, #FFD633 50%, #FDC800 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; filter: drop-shadow(0 0 40px rgba(253,200,0,0.5));">Enlightened Blog</span>
            </h1>
        </div>
        
        <div data-aos="fade-up" data-aos-delay="300" style="max-width: 850px; margin: 0 auto; padding: 45px; position: relative; background: rgba(255,255,255,0.02); backdrop-filter: blur(25px); border-radius: 40px; border: 1px solid rgba(255,255,255,0.1); box-shadow: 0 40px 100px rgba(0,0,0,0.4);">
            <!-- Decorative Corners -->
            <div style="position: absolute; top: 20px; left: 20px; width: 30px; height: 30px; border-top: 1px solid var(--accent); border-left: 1px solid var(--accent); border-radius: 8px 0 0 0; opacity: 0.4;"></div>
            <div style="position: absolute; bottom: 20px; right: 20px; width: 30px; height: 30px; border-bottom: 1px solid var(--accent); border-right: 1px solid var(--accent); border-radius: 0 0 8px 0; opacity: 0.4;"></div>
            
            <p style="font-size: 1.8rem; color: #cbd5e1; line-height: 1.6; font-weight: 300; margin: 0; font-family: 'Outfit', sans-serif; position: relative; z-index: 2;">
                Embark on a <span style="color: white; font-weight: 500;">sanctuary of knowledge</span> through scholarly insights, 
                precise <span style="color: var(--accent); font-weight: 700;">Tajweed wisdom</span>, 
                and chronicles of <span style="color: var(--accent); font-weight: 700;">spiritual excellence</span>.
            </p>
        </div>
        
        <div data-aos="fade-up" data-aos-delay="500" style="margin-top: 50px;">
            <a href="#featured-journal" class="btn-premium-gold" style="padding: 18px 50px; font-size: 1.1rem; border-radius: 100px; text-transform: uppercase; letter-spacing: 2px;">
                Explore Journal <i class="fas fa-arrow-down ms-2" style="animation: bounce 2s infinite;"></i>
            </a>
        </div>
    </div>

</section>



<style>
@keyframes float {
    0% { transform: translate(0, 0) scale(1); }
    100% { transform: translate(30px, 40px) scale(1.1); }
}
@keyframes float-slow {
    0%, 100% { transform: translateY(0) translateX(0); }
    50% { transform: translateY(-20px) translateX(10px); }
}
@keyframes pulse {
    0% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.1); opacity: 0.7; }
    100% { transform: scale(1); opacity: 1; }
}
@keyframes float-up {
    0% { transform: translateY(0) rotate(0deg); opacity: 0; }
    20% { opacity: 1; }
    100% { transform: translateY(-100px) rotate(360deg); opacity: 0; }
}
@keyframes bounce {
    0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
    40% { transform: translateY(-10px); }
    60% { transform: translateY(-5px); }
}
@keyframes shimmer {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}
@keyframes rotate-slow {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}
/* Premium Custom Scrollbar */
::-webkit-scrollbar {
    width: 10px;
}
::-webkit-scrollbar-track {
    background: #f1f5f9;
}
::-webkit-scrollbar-thumb {
    background: var(--primary);
    border-radius: 10px;
    border: 3px solid #f1f5f9;
}
::-webkit-scrollbar-thumb:hover {
    background: var(--accent);
}

.glow-text {
    text-shadow: 0 0 20px rgba(253,200,0,0.4), 0 0 40px rgba(253,200,0,0.2);
}
</style>

<!-- Compact Premium Featured Section -->
<section id="featured-journal" style="background: #ffffff; padding: 20px 0 60px; margin-top: -80px; position: relative; z-index: 20;">
    <div class="container">
        <div class="row" data-aos="fade-up">
            <div class="col-12">
                <div class="featured-outer-compact" style="
                    background: rgba(255,255,255,0.7); 
                    backdrop-filter: blur(25px); 
                    border-radius: 40px; 
                    box-shadow: 0 40px 80px rgba(0,33,71,0.12); 
                    border: 1px solid rgba(255,255,255,0.8);
                    overflow: hidden;
                ">
                    <div class="row g-0 align-items-stretch">
                        <!-- Left: Image Section (Compact) -->
                        <div class="col-lg-5" style="position: relative; min-height: 380px; overflow: hidden;">
                            <img src="assets/images/blog_featured.png" alt="Featured Quran" style="width: 100%; height: 100%; object-fit: cover; transition: 1.5s ease-in-out;" class="featured-img-hover">
                            <div style="position: absolute; inset: 0; background: linear-gradient(to right, rgba(0,0,0,0.2), transparent);"></div>
                            
                            <!-- Balanced Badges -->
                            <div style="position: absolute; top: 25px; left: 25px; display: flex; flex-direction: column; gap: 8px;">
                                <div style="background: var(--primary); color: white; padding: 6px 18px; border-radius: 50px; font-weight: 800; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 2px;">Editors Choice</div>
                                <div style="background: var(--accent); color: var(--primary); padding: 5px 15px; border-radius: 50px; font-weight: 800; font-size: 0.65rem; text-transform: uppercase; letter-spacing: 1.5px;">Most Read</div>
                            </div>
                        </div>

                        <!-- Right: Content Section (Polished) -->
                        <div class="col-lg-7" style="padding: 45px 55px; background: white; display: flex; flex-direction: column; justify-content: center;">
                            <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 20px;">
                                <span style="color: var(--accent-dark); font-weight: 900; font-size: 0.8rem; text-transform: uppercase; letter-spacing: 2px;">Masterclass</span>
                                <div style="width: 30px; height: 1px; background: #e2e8f0;"></div>
                                <span style="color: #94a3b8; font-size: 0.85rem; font-weight: 600;"><i class="far fa-clock me-1"></i> 12 MIN READ</span>
                            </div>

                            <h2 style="font-size: 2.2rem; font-weight: 900; color: var(--primary); margin-bottom: 20px; line-height: 1.2; letter-spacing: -1px; font-family: 'Outfit', sans-serif;">
                                The Spiritual Essence of <span style="color: var(--accent-dark);">Tajweed Masterclass</span>
                            </h2>

                            <p style="font-size: 1.1rem; color: #526484; line-height: 1.7; margin-bottom: 35px; font-weight: 400; font-family: 'Outfit', sans-serif;">
                                Discover how the rhythmic beauty of Quranic recitation transforms the human heart and soul beyond just articulated rules.
                            </p>

                            <!-- Compact Footer -->
                            <div style="display: flex; align-items: center; justify-content: space-between; border-top: 1px solid #f1f5f9; padding-top: 30px; margin-top: auto;">
                                <a href="#" class="p-blog-link" style="color: var(--primary); font-weight: 900; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 1px;">
                                    Read Article <i class="fas fa-arrow-right ms-2" style="font-size: 0.8rem;"></i>
                                </a>

                                <div style="display: flex; align-items: center; gap: 12px; text-align: right;">
                                    <div>
                                        <div style="font-weight: 800; font-size: 0.95rem; color: var(--primary);">Dr. Sulaiman</div>
                                        <div style="color: #94a3b8; font-size: 0.75rem; font-weight: 700; text-transform: uppercase;">Dean Faculty</div>
                                    </div>
                                    <img src="https://ui-avatars.com/api/?name=Sulaiman&background=002147&color=fff" style="width: 42px; height: 42px; border-radius: 12px;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
.featured-img-hover:hover { transform: scale(1.05); }
@media (max-width: 991px) {
    [style*="padding: 45px 55px"] { padding: 35px 25px !important; }
    h2 { font-size: 1.8rem !important; }
}
</style>




<!-- Blog Main Section -->
<section style="background: #ffffff; padding: 100px 0 120px;">
    <div class="container">
        <div class="row g-5">
            <!-- Blog Posts -->
            <div class="col-lg-8">
                <div class="row g-4" id="blog-posts-container">
                    <!-- Post 1 -->
                    <div class="col-md-6 blog-post" data-page="1" data-aos="fade-up">
                        <article class="premium-blog-card">
                            <div class="p-blog-thumb">
                                <img src="https://images.unsplash.com/photo-1542810634-71277d95dcbb?auto=format&fit=crop&w=800&q=80" onerror="this.src='assets/images/course-1.png'" alt="Learning">
                                <div class="p-card-overlay"></div>
                                <span class="p-blog-tag" style="background: var(--primary); color: white;">Academy News</span>
                            </div>
                            <div class="p-blog-body">
                                <h3 class="p-blog-title"><a href="#">Digital Learning: The Future of Islamic Education</a></h3>
                                <p class="p-blog-desc">How virtual classrooms are preserving sacred traditions while embracing modern innovation for the next generation.</p>
                                <div class="p-blog-footer">
                                    <div class="p-date"><i class="far fa-calendar-alt"></i> Oct 22, 2025</div>
                                    <a href="#" class="p-blog-link">Read More <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </article>
                    </div>

                    <!-- Post 2 -->
                    <div class="col-md-6 blog-post" data-page="1" data-aos="fade-up" data-aos-delay="150">
                        <article class="premium-blog-card">
                            <div class="p-blog-thumb">
                                <img src="https://images.unsplash.com/photo-1519781542704-957ef19f9c26?auto=format&fit=crop&w=800&q=80" onerror="this.src='assets/images/course-2.png'" alt="Art">
                                <div class="p-card-overlay"></div>
                                <span class="p-blog-tag" style="background: var(--accent); color: white;">Tradition</span>
                            </div>
                            <div class="p-blog-body">
                                <h3 class="p-blog-title"><a href="#">Mastering the Art of Calligraphic Script</a></h3>
                                <p class="p-blog-desc">Explore the meditative practice of Arabic calligraphy and its role in early Quranic preservation.</p>
                                <div class="p-blog-footer">
                                    <div class="p-date"><i class="far fa-calendar-alt"></i> Oct 20, 2025</div>
                                    <a href="#" class="p-blog-link">Read More <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </article>
                    </div>

                    <!-- Post 3 -->
                    <div class="col-md-6 blog-post" data-page="1" data-aos="fade-up">
                        <article class="premium-blog-card">
                            <div class="p-blog-thumb">
                                <img src="https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?auto=format&fit=crop&w=800&q=80" onerror="this.src='assets/images/course-3.png'" alt="Children">
                                <div class="p-card-overlay"></div>
                                <span class="p-blog-tag" style="background: #4A90E2; color: white;">Kids Hub</span>
                            </div>
                            <div class="p-blog-body">
                                <h3 class="p-blog-title"><a href="#">Engaging Young Minds with Quranic Stories</a></h3>
                                <p class="p-blog-desc">Transform standard lessons into captivating adventures that stay with children for a lifetime.</p>
                                <div class="p-blog-footer">
                                    <div class="p-date"><i class="far fa-calendar-alt"></i> Oct 18, 2025</div>
                                    <a href="#" class="p-blog-link">Read More <i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </article>
                    </div>

                    <!-- Post 4 -->
                    <div class="col-md-6 blog-post" data-page="1" data-aos="fade-up" data-aos-delay="150">
                        <article class="premium-blog-card">
                            <div class="p-blog-thumb">
                                <img src="https://images.unsplash.com/photo-1585829365294-bb7c63b3ecda?auto=format&fit=crop&w=800&q=80" onerror="this.src='assets/images/course-4.png'" alt="Strategy">
                                <div class="p-card-overlay"></div>
                                <span class="p-blog-tag" style="background: #E02424; color: white;">Hifz Guide</span>
                            </div>
                            <div class="p-blog-body">
                                <h3 class="p-blog-title"><a href="#">The Science of Memorization: A Hifz Framework</a></h3>
                                <p class="p-blog-desc">Using cognitive science and ancient techniques to accelerate your journey to becoming a Hafiz.</p>
                                <div class="p-blog-footer">
                                    <div class="p-date"><i class="far fa-calendar-alt"></i> Oct 15, 2025</div>
                                    <a href="#" class="p-blog-link">Read More <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </article>
                    </div>

                    <!-- Post 5 (Page 2 Mock) -->
                    <div class="col-md-6 blog-post" data-page="2" style="display: none;">
                        <article class="premium-blog-card">
                            <div class="p-blog-thumb">
                                <img src="https://images.unsplash.com/photo-1455849318743-b2233052fcff?auto=format&fit=crop&w=800&q=80" onerror="this.src='assets/images/feature_class.png'" alt="Advanced">
                                <div class="p-card-overlay"></div>
                                <span class="p-blog-tag" style="background: #6366f1; color: white;">Advanced</span>
                            </div>
                            <div class="p-blog-body">
                                <h3 class="p-blog-title"><a href="#">Deep Dive into Classical Arabic Grammar</a></h3>
                                <p class="p-blog-desc">Understanding the complex nuances of Nahw and Sarf for high-level Quranic comprehension.</p>
                                <div class="p-blog-footer">
                                    <div class="p-date"><i class="far fa-calendar-alt"></i> Oct 10, 2025</div>
                                    <a href="#" class="p-blog-link">Read More <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </article>
                    </div>

                    <!-- Post 6 (Page 2 Mock) -->
                    <div class="col-md-6 blog-post" data-page="2" style="display: none;">
                        <article class="premium-blog-card">
                            <div class="p-blog-thumb">
                                <img src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=800&q=80" onerror="this.src='assets/images/feature_kids.png'" alt="Parenting">
                                <div class="p-card-overlay"></div>
                                <span class="p-blog-tag" style="background: #ec4899; color: white;">Academy News</span>
                            </div>
                            <div class="p-blog-body">
                                <h3 class="p-blog-title"><a href="#">The Role of Parents in Hifz Success</a></h3>
                                <p class="p-blog-desc">How a supportive home environment can double the speed of Quranic memorization for children.</p>
                                <div class="p-blog-footer">
                                    <div class="p-date"><i class="far fa-calendar-alt"></i> Oct 05, 2025</div>
                                    <a href="#" class="p-blog-link">Read More <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>

                <!-- Professional Pagination System -->
                <div style="margin-top: 80px; display: flex; flex-direction: column; align-items: center; gap: 20px;">
                    <div style="color: #64748b; font-weight: 600; font-size: 0.95rem; background: #f1f5f9; padding: 5px 20px; border-radius: 50px;">
                        Showing <span style="color: var(--primary);" id="rendered-count">4</span> of 24 results
                    </div>
                    <div class="blog-pagination-wrapper" style="display: flex; align-items: center; gap: 15px;">
                        <a href="javascript:void(0)" id="prev-btn" class="p-nav-btn disabled" style="background: #f8fafc; color: #cbd5e1; cursor: not-allowed; transition: 0.3s; border-radius: 12px; padding: 10px 20px; text-decoration: none; font-weight: 800; border: 1px solid #eee;"><i class="fas fa-chevron-left me-2"></i> Prev</a>
                        <div class="blog-pagination" id="pagination-numbers">
                            <a href="javascript:void(0)" class="page-num active" data-page="1">1</a>
                            <a href="javascript:void(0)" class="page-num" data-page="2">2</a>
                            <a href="javascript:void(0)" class="page-num" data-page="3">3</a>
                            <span>...</span>
                            <a href="javascript:void(0)" class="page-num" data-page="6">6</a>
                        </div>
                        <a href="javascript:void(0)" id="next-btn" class="p-nav-btn" style="background: white; color: var(--primary); transition: 0.3s; border-radius: 12px; padding: 10px 20px; text-decoration: none; font-weight: 800; border: 1px solid #eee;">Next <i class="fas fa-chevron-right ms-2"></i></a>
                    </div>
                </div>
            </div>


            <!-- Sidebar -->
            <div class="col-lg-4">
                <div class="blog-sidebar" style="position: sticky; top: 120px;">
                    <!-- Search Widget -->
                    <div class="sidebar-widget">
                        <h4 class="widget-title">Search Journal</h4>
                        <div class="blog-search-box">
                            <input type="text" placeholder="What are you looking for?">
                            <button><i class="fas fa-search"></i></button>
                        </div>
                    </div>

                    <!-- Categories Widget -->
                    <div class="sidebar-widget">
                        <h4 class="widget-title">Categories</h4>
                        <ul class="sidebar-list">
                            <li><a href="#">Quranic Mastery <span>12</span></a></li>
                            <li><a href="#">Tajweed Secrets <span>08</span></a></li>
                            <li><a href="#">Islamic Parenting <span>15</span></a></li>
                            <li><a href="#">Student Stories <span>20</span></a></li>
                            <li><a href="#">Academy News <span>10</span></a></li>
                        </ul>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<!-- Luxury Full-Width Newsletter Section -->
<section style="padding: 120px 0; background: #fafafa; position: relative; overflow: hidden;">
    <div style="position: absolute; top:0; left:0; width:100%; height:100%; background: url('assets/images/hero_pattern.png'); background-size: 400px; opacity: 0.02;"></div>
    
    <div class="container">
        <div style="background: linear-gradient(135deg, var(--primary), var(--primary-dark)); border-radius: 50px; padding: 100px 60px; position: relative; overflow: hidden; box-shadow: 0 40px 100px rgba(0,33,71,0.3);" data-aos="zoom-in">
            <!-- Decorative Glows -->
            <div style="position: absolute; top: -50px; right: -50px; width: 250px; height: 250px; background: radial-gradient(circle, rgba(253,200,0,0.1) 0%, transparent 70%); border-radius: 50%;"></div>
            
            <div class="row align-items-center">
                <div class="col-lg-7 text-white">
                    <h2 style="font-size: 3.5rem; color: white; margin-bottom: 25px; line-height: 1; letter-spacing: -2px;">Become Part of <span style="color: var(--accent);">Our Legacy</span></h2>
                    <p style="font-size: 1.2rem; color: rgba(255,255,255,0.8); line-height: 1.8; margin-bottom: 40px; max-width: 600px;">
                        Subscribe to our exclusive journal and receive scholarly deep-dives, academy updates, and spiritual gems directly to your heart.
                    </p>
                    <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                        <input type="email" placeholder="Enter your sacred email address" style="flex: 1; min-width: 300px; padding: 22px 35px; border-radius: 100px; border: 1px solid rgba(255,255,255,0.2); background: rgba(255,255,255,0.05); color: white; outline: none; font-size: 1.1rem; backdrop-filter: blur(10px);">
                        <button class="btn-subscribe-wide">Join Now <i class="fas fa-paper-plane ms-2"></i></button>
                    </div>
                </div>
                <div class="col-lg-5 d-none d-lg-block">
                    <div style="position: relative; text-align: center;">
                        <i class="fas fa-mosque" style="font-size: 12rem; color: var(--accent); opacity: 0.15; transform: rotate(-10deg);"></i>
                        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                            <i class="fas fa-heart" style="font-size: 6rem; color: white; animation: heart-pulse 2s infinite;"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<style>
@keyframes heart-pulse {
    0% { transform: scale(1); opacity: 0.8; }
    50% { transform: scale(1.1); opacity: 1; }
    100% { transform: scale(1); opacity: 0.8; }
}
.btn-subscribe-wide {
    background: var(--accent);
    color: var(--primary);
    padding: 22px 50px;
    border-radius: 100px;
    font-weight: 800;
    border: none;
    font-size: 1.1rem;
    cursor: pointer;
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    box-shadow: 0 15px 35px rgba(253,200,0,0.3);
    text-transform: uppercase;
    letter-spacing: 1px;
}
.btn-subscribe-wide:hover {
    transform: translateY(-5px) scale(1.05);
    box-shadow: 0 25px 50px rgba(253,200,0,0.4);
    background: white;
}
</style>

<style>
    /* Blog Search Box UI */
    .blog-search-box {
        position: relative;
        background: #f8fafc;
        border: 1px solid #f1f5f9;
        border-radius: 12px;
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    .blog-search-box:focus-within {
        border-color: var(--primary);
        box-shadow: 0 10px 25px rgba(0, 33, 71, 0.1);
        transform: translateY(-2px);
        background: white;
    }
    .blog-search-box input {
        width: 100%;
        padding: 15px 50px 15px 20px;
        border: none;
        background: transparent;
        font-size: 0.95rem;
        outline: none;
        color: #1a202c;
    }
    .blog-search-box button {
        position: absolute;
        right: 15px;
        top: 50%;
        transform: translateY(-50%);
        border: none;
        background: none;
        color: var(--primary);
        font-size: 1.1rem;
        transition: 0.3s;
    }
    .blog-search-box:focus-within button {
        color: var(--accent);
        transform: translateY(-50%) scale(1.1);
    }

    /* Featured Card Button */
    .btn-read-featured {
        background: var(--primary);
        color: white;
        padding: 18px 40px;
        border-radius: 15px;
        font-weight: 800;
        text-decoration: none;
        display: inline-block;
        transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        box-shadow: 0 15px 30px rgba(0, 33, 71, 0.3);
    }
    .btn-read-featured:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 40px rgba(0, 33, 71, 0.4);
        color: white;
    }

    /* Sub-Blog Cards */
    .premium-blog-card {
        background: white;
        border-radius: 35px;
        overflow: hidden;
        border: 1px solid rgba(0,0,0,0.04);
        transition: all 0.6s cubic-bezier(0.16, 1, 0.3, 1);
        height: 100%;
        display: flex;
        flex-direction: column;
        box-shadow: 0 10px 40px rgba(0,0,0,0.02);
        position: relative;
    }
    .premium-blog-card::before {
        content: '';
        position: absolute;
        top: 0; left: 0; width: 100%; height: 100%;
        background: linear-gradient(135deg, var(--accent) 0%, transparent 100%);
        opacity: 0;
        transition: 0.6s;
        z-index: 1;
        pointer-events: none;
    }
    .premium-blog-card:hover {
        transform: translateY(-15px) scale(1.02);
        box-shadow: 0 40px 80px rgba(0, 33, 71, 0.12);
        border-color: rgba(253,200,0,0.3);
    }
    .premium-blog-card:hover::before {
        opacity: 0.03;
    }
    .p-blog-thumb {
        height: 260px;
        overflow: hidden;
        position: relative;
        z-index: 2;
    }
    .p-blog-thumb img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: 1.2s cubic-bezier(0.19, 1, 0.22, 1);
    }
    .premium-blog-card:hover .p-blog-thumb img {
        transform: scale(1.1);
    }
    .p-blog-tag {
        position: absolute;
        top: 25px;
        right: 25px;
        padding: 8px 20px;
        border-radius: 100px;
        font-weight: 900;
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        z-index: 5;
        box-shadow: 0 10px 20px rgba(0,0,0,0.2);
    }
    .p-blog-body {
        padding: 40px;
        flex: 1;
        display: flex;
        flex-direction: column;
        position: relative;
        z-index: 2;
    }
    .p-blog-title {
        font-size: 1.6rem;
        font-weight: 850;
        margin-bottom: 18px;
        line-height: 1.3;
        color: var(--primary);
        font-family: 'Outfit', sans-serif;
    }
    .p-blog-title a {
        text-decoration: none;
        color: inherit;
        transition: 0.3s;
    }
    .p-blog-title a:hover {
        color: var(--accent-dark);
    }
    .p-blog-desc {
        color: #64748b;
        font-size: 1.05rem;
        line-height: 1.7;
        margin-bottom: 30px;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        font-weight: 400;
    }
    .p-blog-footer {
        margin-top: auto;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: 25px;
        border-top: 1px solid #f8fafc;
    }
    .p-date {
        font-size: 0.85rem;
        color: #94a3b8;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .p-date i { color: var(--accent); font-size: 0.9rem; }
    .p-blog-link {
        font-weight: 900;
        color: var(--primary);
        text-decoration: none;
        font-size: 0.9rem;
        transition: 0.3s;
        display: flex;
        align-items: center;
        gap: 8px;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    .p-blog-link i {
        font-size: 0.75rem;
        transition: transform 0.3s;
    }
    .p-blog-link:hover {
        color: var(--accent-dark);
    }
    .p-blog-link:hover i {
        transform: translateX(5px);
    }

    /* Widgets & Sidebar */
    .sidebar-widget {
        background: rgba(255,255,255,0.7);
        backdrop-filter: blur(15px);
        padding: 40px;
        border-radius: 35px;
        border: 1px solid rgba(255,255,255,0.5);
        margin-bottom: 40px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.03);
        transition: 0.3s;
    }
    .sidebar-widget:hover {
        background: white;
        transform: translateY(-5px);
        box-shadow: 0 30px 60px rgba(0,33,71,0.08);
    }
    .widget-title {
        font-size: 1.3rem;
        font-weight: 900;
        margin-bottom: 30px;
        color: var(--primary);
        position: relative;
        padding-bottom: 15px;
        border-bottom: 2px solid #f1f5f9;
    }
    .widget-title::after {
        content: '';
        position: absolute;
        bottom: -2px;
        left: 0;
        width: 50px;
        height: 2px;
        background: var(--accent);
    }
    .sidebar-list {
        list-style: none;
        padding: 0;
    }
    .sidebar-list li { margin-bottom: 15px; }
    .sidebar-list li a {
        display: flex;
        justify-content: space-between;
        color: #64748b;
        font-weight: 700;
        text-decoration: none;
        transition: 0.3s;
    }
    .sidebar-list li a span {
        background: #f1f5f9;
        color: var(--primary);
        padding: 2px 10px;
        border-radius: 5px;
        font-size: 0.75rem;
    }
    .sidebar-list li a:hover {
        color: var(--primary);
        transform: translateX(5px);
    }

    /* Pagination */
    .blog-pagination a {
        display: inline-flex;
        width: 55px;
        height: 55px;
        background: white;
        border-radius: 15px;
        align-items: center;
        justify-content: center;
        margin: 0 8px;
        color: #1a202c;
        font-weight: 800;
        text-decoration: none;
        transition: all 0.3s;
        box-shadow: 0 10px 20px rgba(0,0,0,0.03);
    }
    .blog-pagination a.active {
        background: var(--primary);
        color: white;
        box-shadow: 0 15px 35px rgba(0, 33, 71, 0.3);
        border: 2px solid var(--accent);
    }

    /* RESPONSIVE FIXES */
    @media (max-width: 1200px) {
        .container { max-width: 95% !important; }
        .featured-blog-card h2 { font-size: 2.5rem !important; }
    }

    @media (max-width: 991px) {
        .blog-sidebar { margin-top: 50px; position: relative !important; top: 0 !important; }
        .featured-blog-card { flex-direction: column; }
        .featured-blog-card > div:first-child { height: 350px !important; flex: none !important; width: 100%; }
        .featured-blog-card > div:last-child { padding: 40px !important; }
        h1 { font-size: 4rem !important; }
    }

    @media (max-width: 768px) {
        h1 { font-size: 3rem !important; }
        .hero-stats { flex-wrap: wrap; gap: 20px !important; }
        .hero-stats > div { flex: 1 1 40% !important; }
        .featured-outer { padding: 10px !important; border-radius: 20px !important; }
        .featured-blog-card { border-radius: 15px !important; }
        .blog-pagination a { width: 45px; height: 45px; margin: 0 4px; }
        .p-nav-btn { padding: 8px 15px !important; font-size: 0.8rem !important; }
        .btn-subscribe-wide { width: 100%; padding: 15px !important; }
        [style*="padding: 100px 60px"] { padding: 40px 20px !important; border-radius: 30px !important; }
        [style*="font-size: 3.5rem"] { font-size: 2rem !important; }
    }

    @media (max-width: 480px) {
        h1 { font-size: 2.2rem !important; }
        .hero-stats { flex-direction: column; align-items: center !important; }
        .p-blog-title { font-size: 1.3rem !important; }
        .sidebar-widget { padding: 25px !important; }
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Scroll Progress logic
    window.addEventListener('scroll', () => {
        const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
        const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        const scrolled = (winScroll / height) * 100;
        document.getElementById("scroll-progress").style.width = scrolled + "%";
    });

    // Back to Top Logic
    const backToTop = document.createElement('div');
    backToTop.innerHTML = '<i class="fas fa-chevron-up"></i>';
    backToTop.style.cssText = "position: fixed; bottom: 40px; right: 40px; width: 60px; height: 60px; background: var(--accent); color: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; cursor: pointer; z-index: 9999; box-shadow: 0 10px 30px rgba(253,200,0,0.4); opacity: 0; visibility: hidden; transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);";
    document.body.appendChild(backToTop);

    window.addEventListener('scroll', () => {
        if(window.scrollY > 500) {
            backToTop.style.opacity = "1";
            backToTop.style.visibility = "visible";
        } else {
            backToTop.style.opacity = "0";
            backToTop.style.visibility = "hidden";
        }
    });

    backToTop.onclick = () => window.scrollTo({top: 0, behavior: 'smooth'});

    const posts = document.querySelectorAll('.blog-post');
    const pageButtons = document.querySelectorAll('.page-num');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    const renderedCount = document.getElementById('rendered-count');
    let currentPage = 1;

    function updatePagination(page) {
        currentPage = page;
        
        // Hide all posts
        posts.forEach(post => post.style.display = 'none');
        
        // Show posts for current page
        const activePosts = document.querySelectorAll(`.blog-post[data-page="${page}"]`);
        activePosts.forEach(post => post.style.display = 'block');
        
        // Update count text
        renderedCount.innerText = activePosts.length;
        
        // Update active class on buttons
        pageButtons.forEach(btn => {
            if(parseInt(btn.getAttribute('data-page')) === page) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });

        // Update Prev button state
        if(currentPage === 1) {
            prevBtn.classList.add('disabled');
            prevBtn.style.background = '#f8fafc';
            prevBtn.style.color = '#cbd5e1';
            prevBtn.style.cursor = 'not-allowed';
        } else {
            prevBtn.classList.remove('disabled');
            prevBtn.style.background = 'white';
            prevBtn.style.color = 'var(--primary)';
            prevBtn.style.cursor = 'pointer';
        }

        // Update Next button state (simulated max page 2 for this demo)
        if(currentPage === 2) {
            nextBtn.classList.add('disabled');
            nextBtn.style.background = '#f8fafc';
            nextBtn.style.color = '#cbd5e1';
            nextBtn.style.cursor = 'not-allowed';
        } else {
            nextBtn.classList.remove('disabled');
            nextBtn.style.background = 'white';
            nextBtn.style.color = 'var(--primary)';
            nextBtn.style.cursor = 'pointer';
        }

        // Scroll to top of posts with offset for header
        window.scrollTo({
            top: document.getElementById('blog-posts-container').offsetTop - 250,
            behavior: 'smooth'
        });
    }

    pageButtons.forEach(button => {
        button.addEventListener('click', function() {
            const page = parseInt(this.getAttribute('data-page'));
            if(page && page <= 2) { // Limited to 2 for demo
                updatePagination(page);
            }
        });
    });

    prevBtn.addEventListener('click', () => {
        if(currentPage > 1) updatePagination(currentPage - 1);
    });

    nextBtn.addEventListener('click', () => {
        if(currentPage < 2) updatePagination(currentPage + 1);
    });
});
</script>

<style>
    .p-nav-btn:hover:not(.disabled) {
        background: var(--primary) !important;
        color: white !important;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 33, 71, 0.2);
    }
</style>

<?php include 'includes/footer.php'; ?>
