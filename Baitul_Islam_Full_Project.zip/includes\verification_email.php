<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/email_config.php';

/**
 * Send verification email to new users
 */
function sendVerificationEmail($to, $name, $verification_code, $verify_link, $user_type = 'student', $is_resend = false) {
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->SMTPDebug = 0; // Disable debug output for production
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to, $name);
        
        // Content
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        
        if ($user_type === 'tutor') {
            $mail->Subject = ($is_resend ? "[NEW CODE] " : "") . "Verify Your Tutor Account - Peace Institute (Ref: " . time() . ")";
            $button_color = '#D4AF37';
            $button_text_color = '#0F5132';
            $welcome_text = "Welcome to Peace Institute as a Tutor!";
        } else {
            $mail->Subject = ($is_resend ? "[NEW CODE] " : "") . "Verify Your Student Account - Peace Institute (Ref: " . time() . ")";
            $button_color = '#0F5132';
            $button_text_color = '#D4AF37';
            $welcome_text = "Welcome to Peace Institute!";
        }
        
        // Add a hidden timestamp to the subject to force Gmail to show it as a new email
        $mail->Subject .= " (" . date('h:i:s A') . ")";
        
        $mail->Body = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: 'Segoe UI', Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { 
                    background: linear-gradient(135deg, #0F5132, #167448); 
                    color: white; 
                    padding: 40px 30px; 
                    text-align: center; 
                    border-radius: 15px 15px 0 0; 
                }
                .header h1 { 
                    color: #D4AF37; 
                    margin: 0 0 10px 0; 
                    font-size: 2rem; 
                    font-weight: 900; 
                }
                .content { 
                    background: #f9f9f9; 
                    padding: 40px 30px; 
                    border-radius: 0 0 15px 15px; 
                }
                .welcome-text {
                    font-size: 1.3rem;
                    color: #0F5132;
                    font-weight: 700;
                    margin-bottom: 20px;
                }
                .verification-box { 
                    background: white; 
                    border: 3px solid $button_color; 
                    padding: 30px; 
                    text-align: center; 
                    margin: 30px 0; 
                    border-radius: 15px; 
                    box-shadow: 0 5px 20px rgba(0,0,0,0.05);
                }
                .verification-code { 
                    font-size: 2.5rem; 
                    font-weight: 900; 
                    color: #0F5132; 
                    letter-spacing: 8px; 
                    font-family: 'Courier New', monospace; 
                    margin: 20px 0;
                }
                .verify-button { 
                    display: inline-block;
                    background: $button_color; 
                    color: $button_text_color; 
                    padding: 18px 45px; 
                    text-decoration: none; 
                    border-radius: 50px; 
                    font-weight: 800; 
                    font-size: 1.1rem; 
                    margin: 20px 0;
                    box-shadow: 0 10px 25px rgba(15, 81, 50, 0.2);
                }
                .footer { 
                    text-align: center; 
                    margin-top: 30px; 
                    padding: 25px; 
                    background: #f0f0f0; 
                    border-radius: 10px; 
                    font-size: 0.9rem; 
                    color: #666; 
                }
                .footer a { color: #0F5132; text-decoration: none; font-weight: 600; }
                .info-box { 
                    background: #e7f3ff; 
                    border-left: 4px solid #2196F3; 
                    padding: 15px; 
                    margin: 20px 0; 
                    border-radius: 5px; 
                }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h1>PEACE INSTITUTE</h1>
                    <p style='margin: 0; font-size: 1.1rem; opacity: 0.9;'>$welcome_text</p>
                </div>
                <div class='content'>
                    <p class='welcome-text'>Assalamu Alaikum " . htmlspecialchars($name) . ",</p>
                    <p>Thank you for registering with Peace Institute. To complete your registration and activate your account, please verify your email address.</p>
                    
                    <div class='verification-box'>
                        <p style='margin: 0; color: #666; font-size: 0.95rem;'>Click the button below to verify:</p>
                        <a href='$verify_link' class='verify-button'>VERIFY MY ACCOUNT</a>
                        <p style='margin: 20px 0 10px 0; color: #666; font-size: 0.9rem;'>Or enter this code manually:</p>
                        <div class='verification-code'>$verification_code</div>
                    </div>
                    
                    <div class='info-box'>
                        <strong>📌 Important:</strong>
                        <ul style='margin: 10px 0 0 0; padding-left: 20px;'>
                            <li>This verification code is valid for 24 hours</li>
                            <li>If you didn't create this account, please ignore this email</li>
                            <li>For security, do not share this code with anyone</li>
                        </ul>
                    </div>
                    
                    <p style='margin-top: 30px;'>If you have any questions, feel free to contact our support team.</p>
                    <p>JazakAllah Khair,<br><strong>Peace Institute Team</strong></p>
                </div>
                
                <div class='footer'>
                    <p><strong>" . ORG_NAME . "</strong></p>
                    <p>📧 Email: <a href='mailto:" . ORG_EMAIL . "'>" . ORG_EMAIL . "</a></p>
                    <p>📱 Phone: " . ORG_PHONE . "</p>
                    <p>📍 Address: " . ORG_ADDRESS . "</p>
                    <p>🌐 Website: <a href='http://" . ORG_WEBSITE . "'>" . ORG_WEBSITE . "</a></p>
                    <hr style='border: none; border-top: 1px solid #ddd; margin: 15px 0;'>
                    <p style='font-size: 0.85rem; color: #999;'>
                        This is an automated email. Please do not reply to this message.
                    </p>
                </div>
            </div>
        </body>
        </html>
        ";
        
        $mail->send();
        return ['success' => true, 'message' => 'Verification email sent successfully'];
    } catch (Exception $e) {
        $errorMsg = "Email sending failed: " . $mail->ErrorInfo;
        error_log($errorMsg);
        return ['success' => false, 'message' => $errorMsg];
    }
}
?>
