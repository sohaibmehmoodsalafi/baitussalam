<?php 
include 'includes/db.php';
include 'includes/header.php'; 
?>

<!-- Premium Hero Section -->
<section style="
    background: url('assets/images/hero-bg.webp') no-repeat center center/cover;
    background-attachment: fixed;
    position: relative;
    padding: 220px 0 150px;
    color: white;
    overflow: hidden;">
    
    <!-- Advanced Gradient Overlay -->
    <div class="hero-overlay-gradient" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;"></div>
    
    <!-- Animated Particles/Pattern -->
    <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: url('assets/images/hero-overlay.png') repeat center center; opacity: 0.15; animation: moveBackground 20s linear infinite;"></div>

    <div class="container" style="position: relative; z-index: 1; text-align: center;">
        <div data-aos="fade-down" style="display: inline-block; padding: 10px 25px; background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border-radius: 50px; border: 1px solid rgba(255,255,255,0.2); margin-bottom: 30px;">
            <span style="color: var(--accent-light); font-weight: 600; text-transform: uppercase; letter-spacing: 1px; font-size: 0.9rem;">Start Your Journey Today</span>
        </div>
        
        <h1 data-aos="fade-up" style="font-size: 4.5rem; margin-bottom: 25px; line-height: 1.1; font-weight: 700; text-shadow: 0 10px 30px rgba(0,0,0,0.3);">
            Master Quranic <br>
            <span style="color: var(--accent-light); position: relative; display: inline-block;">
                Arabic Online
                <svg width="100%" height="15" viewBox="0 0 200 15" style="position: absolute; bottom: 5px; left: 0; z-index: -1;">
                    <path d="M0,10 Q100,20 200,10" stroke="#F3C64F" stroke-width="8" fill="none" opacity="0.6" />
                </svg>
            </span>
        </h1>
        
        <p data-aos="fade-up" data-aos-delay="100" style="font-size: 1.25rem; margin-bottom: 50px; color: #e2e8f0; max-width: 750px; margin-left: auto; margin-right: auto; line-height: 1.8; font-weight: 300;">
            Experience the most comprehensive Arabic course designed for non-native speakers. Learn from certified tutors in a state-of-the-art virtual classroom.
        </p>
        
        <div data-aos="fade-up" data-aos-delay="200" style="display: flex; gap: 20px; justify-content: center;">
            <a href="register.php" class="btn btn-primary" style="padding: 18px 45px; font-size: 1.1rem; min-width: 220px;">
                Start Free Trial
            </a>
            <a href="#course-details" class="btn" style="padding: 18px 45px; font-size: 1.1rem; background: rgba(255,255,255,0.1); backdrop-filter: blur(5px); border: 1px solid rgba(255,255,255,0.3); color: white; min-width: 220px; border-radius: 50px;">
                View Curriculum
            </a>
        </div>
    </div>
</section>

<!-- Stats Section (Floating) -->
<section style="margin-top: -80px; position: relative; z-index: 10; padding-bottom: 100px;">
    <div class="container">
        <div class="glass-card" style="padding: 40px; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 30px; background: white; border: none; box-shadow: 0 20px 50px rgba(0,0,0,0.1);">
            <div style="text-align: center; border-right: 1px solid #f1f5f9;">
                <h3 style="font-size: 2.5rem; color: var(--primary); margin-bottom: 5px;">50k+</h3>
                <p style="color: var(--text-muted); font-weight: 500;">Active Students</p>
            </div>
            <div style="text-align: center; border-right: 1px solid #f1f5f9;">
                <h3 style="font-size: 2.5rem; color: var(--primary); margin-bottom: 5px;">4.9</h3>
                <p style="color: var(--text-muted); font-weight: 500;">Average Rating</p>
            </div>
             <div style="text-align: center; border-right: 1px solid #f1f5f9;">
                <h3 style="font-size: 2.5rem; color: var(--primary); margin-bottom: 5px;">24/7</h3>
                <p style="color: var(--text-muted); font-weight: 500;">Live Classes</p>
            </div>
            <div style="text-align: center;">
                <h3 style="font-size: 2.5rem; color: var(--primary); margin-bottom: 5px;">100%</h3>
                <p style="color: var(--text-muted); font-weight: 500;">Satisfaction</p>
            </div>
        </div>
    </div>
</section>

<!-- Course Features -->
<section id="course-details" class="section-padding" style="background: var(--bg-body);">
    <div class="container">
        <div style="text-align: center; max-width: 800px; margin: 0 auto 80px;">
            <span style="color: var(--primary); font-weight: 600; text-transform: uppercase; letter-spacing: 2px; font-size: 0.9rem; display: block; margin-bottom: 15px;">Why Choose Us</span>
            <h2 class="section-title">Everything You Need to Master Arabic</h2>
            <p style="font-size: 1.1rem; color: var(--text-muted);">Our curriculum is crafted by Al-Azhar University graduates to ensure you receive the highest quality education.</p>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 40px;">
            <!-- Feature 1 -->
            <div data-aos="fade-up" class="glass-card feature-card" style="padding: 50px 30px; text-align: center; background: white;">
                <div class="feature-icon-wrapper">
                    <i class="fas fa-book-reader"></i>
                </div>
                <h3 style="font-size: 1.5rem; margin-bottom: 15px; color: var(--text-main);">Structured Curriculum</h3>
                <p style="color: var(--text-muted); line-height: 1.7;">From alphabet mastery to complex grammar rules, our step-by-step approach ensures steady progress.</p>
            </div>

            <!-- Feature 2 -->
            <div data-aos="fade-up" data-aos-delay="100" class="glass-card feature-card" style="padding: 50px 30px; text-align: center; background: white;">
                <div class="feature-icon-wrapper">
                    <i class="fas fa-video"></i>
                </div>
                <h3 style="font-size: 1.5rem; margin-bottom: 15px; color: var(--text-main);">Interactive Sessions</h3>
                <p style="color: var(--text-muted); line-height: 1.7;">Live video sessions with screen sharing, digital whiteboard, and instant feedback from your tutor.</p>
            </div>

            <!-- Feature 3 -->
            <div data-aos="fade-up" data-aos-delay="200" class="glass-card feature-card" style="padding: 50px 30px; text-align: center; background: white;">
                <div class="feature-icon-wrapper">
                    <i class="fas fa-certificate"></i>
                </div>
                <h3 style="font-size: 1.5rem; margin-bottom: 15px; color: var(--text-main);">Certification</h3>
                <p style="color: var(--text-muted); line-height: 1.7;">Receive a recognized certificate upon course completion to validate your Arabic proficiency.</p>
            </div>
        </div>
    </div>
</section>

<!-- Curriculum Syllabus (Accordion Style Visuals) -->
<section class="section-padding" style="background: white; position: relative; overflow: hidden;">
    <!-- decorative blobs -->
    <div style="position: absolute; top: -100px; right: -100px; width: 400px; height: 400px; background: rgba(15, 81, 50, 0.03); border-radius: 50%; filter: blur(50px);"></div>
    <div style="position: absolute; bottom: -100px; left: -100px; width: 400px; height: 400px; background: rgba(212, 175, 55, 0.05); border-radius: 50%; filter: blur(50px);"></div>

    <div class="container">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div data-aos="fade-right">
                <h2 class="section-title" style="margin-bottom: 30px;">What You Will Learn</h2>
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    <!-- List Item 1 -->
                    <div style="display: flex; gap: 20px; align-items: flex-start;">
                        <div style="background: var(--primary-light); color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 5px;">1</div>
                        <div>
                            <h4 style="font-size: 1.2rem; margin-bottom: 5px;">Arabic Fundamentals</h4>
                            <p style="color: var(--text-muted);">Master reading, writing, and pronouncing Arabic letters correctly.</p>
                        </div>
                    </div>
                    <!-- List Item 2 -->
                     <div style="display: flex; gap: 20px; align-items: flex-start;">
                        <div style="background: var(--primary-light); color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 5px;">2</div>
                        <div>
                            <h4 style="font-size: 1.2rem; margin-bottom: 5px;">Grammar Rules (Nahw)</h4>
                            <p style="color: var(--text-muted);">Understand sentence structure, verb conjugations, and nouns.</p>
                        </div>
                    </div>
                     <!-- List Item 3 -->
                     <div style="display: flex; gap: 20px; align-items: flex-start;">
                        <div style="background: var(--primary-light); color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 5px;">3</div>
                        <div>
                            <h4 style="font-size: 1.2rem; margin-bottom: 5px;">Vocabulary Building</h4>
                            <p style="color: var(--text-muted);">Learn essential words and phrases for daily conversation and Quran understanding.</p>
                        </div>
                    </div>
                     <!-- List Item 4 -->
                     <div style="display: flex; gap: 20px; align-items: flex-start;">
                        <div style="background: var(--primary-light); color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; margin-top: 5px;">4</div>
                        <div>
                            <h4 style="font-size: 1.2rem; margin-bottom: 5px;">Quranic Application</h4>
                            <p style="color: var(--text-muted);">Apply your knowledge to translate and understand verses of the Quran.</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div data-aos="fade-left">
                <div style="position: relative;">
                    <div style="position: absolute; top: -20px; right: -20px; width: 100px; height: 100px; background: var(--accent); border-radius: 50%; opacity: 0.1;"></div>
                    <img src="assets/images/feature-main.png" alt="Learning Interface" style="border-radius: 20px; box-shadow: -30px 30px 0 rgba(15, 81, 50, 0.05); position: relative; z-index: 2; width: 100%;">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Premium CTA -->
<section style="padding: 120px 0; text-align: center; background: #0F5132; color: white; position: relative; overflow: hidden;">
    <div style="position: absolute; inset: 0; background: url('assets/images/pattern.png'); opacity: 0.1;"></div>
    <div class="container" style="position: relative; z-index: 2;">
        <h2 data-aos="fade-up" style="font-size: 3.5rem; margin-bottom: 25px;">Ready to Master Arabic?</h2>
        <p data-aos="fade-up" data-aos-delay="100" style="font-size: 1.4rem; color: rgba(255,255,255,0.8); margin-bottom: 50px; max-width: 700px; margin-left: auto; margin-right: auto;">
            Join thousands of students worldwide and start your journey with a free trial class today.
        </p>
        <a href="register.php" class="btn btn-primary" style="background: white; color: var(--primary); padding: 18px 50px; font-size: 1.2rem; box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
            Book Free Trial Class
        </a>
    </div>
</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/vanilla-tilt/1.8.0/vanilla-tilt.min.js"></script>
<?php include 'includes/footer.php'; ?>
