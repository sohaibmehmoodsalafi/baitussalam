<?php
session_start();
require 'includes/stripe_config.php';

// Set Content-Type to JSON for all responses
header('Content-Type: application/json');

// Get JSON data from frontend
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['error' => 'No data provided to the backend.']);
    exit;
}

$planName = $data['planName'] ?? 'Unnamed Plan';
$price = (float)($data['price'] ?? 0);
$period = $data['period'] ?? 'One-time'; 
$course_id = $data['course_id'] ?? null;
$student_id = $_SESSION['user_id'] ?? null;

// Stripe session creation via cURL (Direct API call)
$stripe_url = 'https://api.stripe.com/v1/checkout/sessions';

// Prepare base URL for redirects
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
$host = $_SERVER['HTTP_HOST'];
$base_uri = rtrim(dirname($_SERVER['REQUEST_URI']), '/\\');
$full_base_url = "$protocol://$host$base_uri";

$post_fields = [
    'payment_method_types[]' => 'card',
    'line_items[0][price_data][currency]' => 'usd',
    'line_items[0][price_data][product_data][name]' => "Peace Institute - $planName ($period)",
    'line_items[0][price_data][unit_amount]' => (int)round($price * 100), // Stripe uses cents
    'line_items[0][quantity]' => 1,
    'mode' => 'payment',
    'success_url' => "$full_base_url/payment_success.php?session_id={CHECKOUT_SESSION_ID}",
    'cancel_url' => "$full_base_url/pricing.php",
];

// Add metadata if course_id exists
if ($course_id) {
    $post_fields['metadata[course_id]'] = $course_id;
    $post_fields['metadata[student_id]'] = $student_id;
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $stripe_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_fields));
curl_setopt($ch, CURLOPT_USERPWD, STRIPE_SECRET_KEY . ':');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Important for some shared hosts
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

$headers = [
    'Content-Type: application/x-www-form-urlencoded'
];
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    $curl_err = curl_error($ch);
    echo json_encode(['error' => 'Connection Error (cURL): ' . $curl_err]);
    exit;
}

$response_data = json_decode($result, true);

if ($http_status !== 200) {
    $error_msg = $response_data['error']['message'] ?? 'Stripe API Error (Status ' . $http_status . ')';
    echo json_encode(['error' => $error_msg]);
} else {
    echo $result; // Success, return the Stripe Session object
}

curl_close($ch);
?>
