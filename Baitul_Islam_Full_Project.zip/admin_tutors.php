<?php
session_start();
require 'includes/db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}
require 'includes/send_email.php';

// Enable error reporting for admin tasks to catch issues
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Handle Actions
if (isset($_POST['action']) && isset($_POST['tutor_id'])) {
    $tutor_id = $_POST['tutor_id'];
    $action = $_POST['action'];
    
    if ($action == 'approve') {
        try {
            // 1. Fetch Tutor Details for Email
            $stmt = $pdo->prepare("SELECT name, email FROM tutors WHERE id = ?");
            $stmt->execute([$tutor_id]);
            $tutor = $stmt->fetch();

            if (!$tutor) {
                $msg = "Error: Tutor not found.";
            } else {
                // 2. Update status in Database FIRST
                $stmt = $pdo->prepare("UPDATE tutors SET status = 'approved', is_verified = 1 WHERE id = ?");
                $stmt->execute([$tutor_id]);
                $msg = "Tutor approved successfully! (Wait while email is being sent...)";

                // 3. Attempt to Send Approval Email
                $subject = 'Your Tutor Application Approved! - ' . ORG_NAME;
                $body = "
                    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e1e1e1; border-radius: 10px;'>
                        <h2 style='color: #0F5132;'>Congratulations, " . htmlspecialchars($tutor['name']) . "!</h2>
                        <p>We are pleased to inform you that your tutor application for <strong>" . ORG_NAME . "</strong> has been <strong>APPROVED</strong>.</p>
                        <p>You can now log in to your dashboard and start managing your profile and classes.</p>
                        <div style='text-align: center; margin: 30px 0;'>
                            <a href='http://" . $_SERVER['HTTP_HOST'] . "/Qutor/login.php?type=tutor' style='background: #D4AF37; color: #fff; padding: 12px 25px; text-decoration: none; border-radius: 5px; font-weight: bold;'>Log In to Your Dashboard</a>
                        </div>
                        <p>If you have any questions, feel free to contact us at " . ORG_EMAIL . ".</p>
                        <hr style='border: 0; border-top: 1px solid #eee; margin: 20px 0;'>
                        <p style='font-size: 0.8rem; color: #999;'>Peace Institute Global Team</p>
                    </div>";

                $emailResult = sendEmail($tutor['email'], $subject, $body);

                if ($emailResult['success']) {
                    $msg = "Tutor approved and welcome email sent successfully.";
                } else {
                    $msg = "Tutor approved in DB, but email failed: " . $emailResult['message'];
                }
            }
        } catch (PDOException $e) {
            $msg = "Database Error: " . $e->getMessage();
        }
    } elseif ($action == 'reject') {
        $stmt = $pdo->prepare("UPDATE tutors SET status = 'rejected', rejected_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$tutor_id]);
        $msg = "Tutor request rejected.";
    } elseif ($action == 'update_salary') {
        $type = $_POST['employment_type'];
        $salary = $_POST['fixed_salary'] ?? 0;
        $stmt = $pdo->prepare("UPDATE tutors SET employment_type = ?, fixed_salary = ? WHERE id = ?");
        $stmt->execute([$type, $salary, $tutor_id]);
        $msg = "Salary details updated.";
    }
}

// Fetch Pending
$stmt = $pdo->query("SELECT * FROM tutors WHERE status = 'pending' ORDER BY created_at DESC");
$pending_tutors = $stmt->fetchAll();

// Fetch Approved
$stmt = $pdo->query("SELECT * FROM tutors WHERE status = 'approved' ORDER BY name ASC");
$active_tutors = $stmt->fetchAll();

include 'includes/admin_header_layout.php';
?>

<div class="d-flex" id="wrapper">
    
    <?php include 'includes/admin_sidebar.php'; ?>

    <!-- Main Content -->
    <div id="page-content-wrapper">
        <!-- Top Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 px-4 mb-4 border-bottom shadow-sm">
            <div class="container-fluid">
                <div class="d-flex align-items-center">
                    <button class="btn btn-light d-lg-none me-3" id="menu-toggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h4 class="fw-bold mb-0 text-dark">Tutor Management</h4>
                </div>
                
                <div class="user-profile">
                    <img src="https://ui-avatars.com/api/?name=Admin&background=0F5132&color=fff" class="avatar">
                    <div class="user-info d-none d-sm-flex ms-2">
                        <span class="name">Administrator</span>
                        <span class="role text-muted small">Super Admin</span>
                    </div>
                </div>
            </div>
        </nav>

        <div class="container-fluid px-4">
            
            <?php if(isset($msg)): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4 shadow-sm border-0 mb-4" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?php echo $msg; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- PENDING REQUESTS -->
            <div class="row mb-5">
                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                        <div class="card-header bg-warning py-3">
                            <h5 class="mb-0 fw-bold text-dark"><i class="fas fa-clock me-2"></i> Pending Approval Requests</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="bg-light">
                                        <tr>
                                            <th class="ps-4">Tutor Profile</th>
                                            <th>Specialty</th>
                                            <th>Education (Madrassa)</th>
                                            <th>Review Documents</th>
                                            <th class="text-end pe-4">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(empty($pending_tutors)): ?>
                                            <tr>
                                                <td colspan="4" class="text-center py-5 text-muted">
                                                    <i class="fas fa-check-circle fa-3x mb-3 d-block opacity-25"></i>
                                                    No pending approval requests
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php foreach($pending_tutors as $t): ?>
                                        <tr>
                                            <td class="ps-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar-sm bg-primary-subtle text-primary rounded-pill d-flex align-items-center justify-content-center me-3" style="width:40px;height:40px; font-weight:bold;">
                                                        <?php echo strtoupper(substr($t['name'], 0, 1)); ?>
                                                    </div>
                                                    <div>
                                                        <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($t['name']); ?></h6>
                                                        <span class="text-muted small"><?php echo htmlspecialchars($t['email']); ?></span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><span class="badge bg-info-subtle text-info rounded-pill px-3"><?php echo htmlspecialchars($t['specialty'] ?: 'General'); ?></span></td>
                                            <td>
                                                <div class="small fw-bold text-dark"><?php echo htmlspecialchars($t['madrassa'] ?: 'Not Specified'); ?></div>
                                                <div class="text-muted smaller"><i class="fas fa-map-marker-alt me-1"></i> <?php echo htmlspecialchars($t['country']); ?></div>
                                            </td>
                                            <td>
                                                <div class="d-flex gap-2">
                                                    <?php if($t['certificate_path']): ?>
                                                        <a href="<?php echo $t['certificate_path']; ?>" target="_blank" class="btn btn-sm btn-outline-primary py-1 px-2" title="View Certificate">
                                                            <i class="fas fa-file-contract"></i> Cert
                                                        </a>
                                                    <?php endif; ?>
                                                    <?php if($t['qirat_video_path']): ?>
                                                        <button type="button" class="btn btn-sm btn-outline-danger py-1 px-2" data-bs-toggle="modal" data-bs-target="#videoModal<?php echo $t['id']; ?>" title="Watch Qirat Video">
                                                            <i class="fas fa-play-circle"></i> Video
                                                        </button>
                                                        
                                                        <!-- Video Modal -->
                                                        <div class="modal fade" id="videoModal<?php echo $t['id']; ?>" tabindex="-1">
                                                            <div class="modal-dialog modal-lg modal-dialog-centered">
                                                                <div class="modal-content rounded-4 border-0 shadow-lg overflow-hidden">
                                                                    <div class="modal-header border-0 bg-dark text-white">
                                                                        <h5 class="modal-title fw-bold">Qirat Video: <?php echo htmlspecialchars($t['name']); ?></h5>
                                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                                    </div>
                                                                    <div class="modal-body p-0 bg-black">
                                                                        <video controls class="w-100" style="max-height: 500px;">
                                                                            <source src="<?php echo $t['qirat_video_path']; ?>" type="video/mp4">
                                                                            Your browser does not support the video tag.
                                                                        </video>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td class="text-end pe-4">
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="tutor_id" value="<?php echo $t['id']; ?>">
                                                    <button type="submit" name="action" value="approve" class="btn btn-success btn-sm rounded-pill px-3 me-2">
                                                        <i class="fas fa-check me-1"></i> Approve
                                                    </button>
                                                    <button type="submit" name="action" value="reject" class="btn btn-outline-danger btn-sm rounded-pill px-3">
                                                        <i class="fas fa-times me-1"></i> Reject
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ACTIVE TUTORS & SALARY MANAGEMENT -->
            <div class="row">
                <div class="col-12">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                        <div class="card-header bg-white py-3 border-bottom">
                            <h5 class="mb-0 fw-bold text-dark"><i class="fas fa-users-cog me-2 text-primary"></i> Active Tutors Management</h5>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="bg-light">
                                        <tr>
                                            <th class="ps-4">Tutor</th>
                                            <th>Rate/Type</th>
                                            <th>Salary Settings</th>
                                            <th class="text-end pe-4">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($active_tutors as $t): ?>
                                        <form method="POST">
                                            <input type="hidden" name="tutor_id" value="<?php echo $t['id']; ?>">
                                            <input type="hidden" name="action" value="update_salary">
                                            <tr>
                                                <td class="ps-4">
                                                    <div class="d-flex align-items-center">
                                                        <div class="avatar-sm bg-success-subtle text-success rounded-pill d-flex align-items-center justify-content-center me-3" style="width:40px;height:40px; font-weight:bold;">
                                                            <?php echo strtoupper(substr($t['name'], 0, 1)); ?>
                                                        </div>
                                                        <div>
                                                            <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($t['name']); ?></h6>
                                                            <span class="text-muted small"><?php echo htmlspecialchars($t['email']); ?></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="fw-bold">$<?php echo number_format($t['price_hourly'], 2); ?>/hr</div>
                                                    <div class="text-muted small text-capitalize"><?php echo $t['employment_type']; ?></div>
                                                </td>
                                                <td>
                                                    <div class="row g-2">
                                                        <div class="col-auto">
                                                            <select name="employment_type" class="form-select form-select-sm border-light-subtle rounded-3" onchange="toggleSalaryInput(this)">
                                                                <option value="freelance" <?php echo $t['employment_type'] == 'freelance' ? 'selected' : ''; ?>>Freelance</option>
                                                                <option value="salaried" <?php echo $t['employment_type'] == 'salaried' ? 'selected' : ''; ?>>Salaried</option>
                                                            </select>
                                                        </div>
                                                        <div class="col">
                                                            <div class="input-group input-group-sm">
                                                                <span class="input-group-text bg-light">$</span>
                                                                <input type="number" step="0.01" name="fixed_salary" class="form-control border-light-subtle" value="<?php echo $t['fixed_salary']; ?>" <?php echo $t['employment_type'] == 'freelance' ? 'disabled' : ''; ?>>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="text-end pe-4">
                                                    <button type="submit" class="btn btn-primary btn-sm rounded-pill px-4 shadow-sm">
                                                        Update
                                                    </button>
                                                </td>
                                            </tr>
                                        </form>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<style>
    body { background-color: #f8fafc; font-family: 'Outfit', sans-serif; }
    #page-content-wrapper {
        flex-grow: 1;
        min-width: 0;
        transition: 0.3s;
        min-height: 100vh;
    }
    .user-profile {
        display: flex; align-items: center; background: #fff; padding: 6px 12px;
        border-radius: 12px; border: 1px solid #f1f5f9;
        cursor: pointer;
    }
    .avatar { width: 32px; height: 32px; border-radius: 8px; }
    
    .table thead th {
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 700;
        color: #64748b;
        border-top: none;
    }
    
    .form-select, .form-control {
        font-size: 0.85rem;
    }
    
    .btn-sm { font-weight: 600; font-size: 0.8rem; }
    
    @media (max-width: 992px) {
        #page-content-wrapper { margin-left: 0; width: 100%; }
        #sidebar-wrapper { margin-left: -280px; position: fixed; height: 100vh; z-index: 1050; }
        #wrapper.toggled #sidebar-wrapper { margin-left: 0; }
    }
</style>

<script>
function toggleSalaryInput(select) {
    const row = select.closest('tr');
    const salaryInput = row.querySelector('input[name="fixed_salary"]');
    if (select.value === 'salaried') {
        salaryInput.disabled = false;
        salaryInput.focus();
    } else {
        salaryInput.disabled = true;
    }
}

// Sidebar Toggle
document.getElementById("menu-toggle")?.addEventListener("click", function(e) {
    e.preventDefault();
    document.getElementById("wrapper").classList.toggle("toggled");
});
</script>

<?php include 'includes/admin_footer.php'; ?>
