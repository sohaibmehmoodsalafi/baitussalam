<?php
require 'includes/db.php';
session_start();

if (!isset($_GET['id'])) {
    header("Location: courses.php");
    exit;
}

$course_id = $_GET['id'];
$stmt = $pdo->prepare("SELECT courses.*, tutors.name as tutor_name, tutors.bio, tutors.image as tutor_image, tutors.rating as tutor_rating FROM courses JOIN tutors ON courses.tutor_id = tutors.id WHERE courses.id = ?");
$stmt->execute([$course_id]);
$course = $stmt->fetch();

if (!$course) {
    die("Course not found.");
}

// Image Override for Founder
if(stripos($course['tutor_name'], 'Abdullah Nasir Rehmani') !== false) {
    $course['tutor_image'] = 'assets/images/sheikh_abdullah.png';
}

// Store referral from course owner
$_SESSION['referred_by_tutor_id'] = $course['tutor_id'];

// Handle Enrollment Logic
if (isset($_POST['enroll'])) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: register.php?redirect=course_details.php?id=" . $course_id);
        exit;
    } else {
        if ($_SESSION['user_role'] != 'student') {
            $enroll_error = "Only students can enroll.";
        } else {
            require_once 'includes/enrollment_security.php';
            $security = new EnrollmentSecurity($pdo);
            $validation = $security->validateEnrollment($_SESSION['user_id'], $course_id);
            
            if (!$validation['valid']) {
                $enroll_error = $validation['errors'][0];
            } else {
                header("Location: payment.php?course_id=" . $course_id);
                exit;
            }
        }
    }
}

include 'includes/header.php';
?>

<!-- Course Banner -->
<div class="course-banner" style="
    background: linear-gradient(rgba(8, 47, 29, 0.9), rgba(8, 47, 29, 0.95)), url('<?php echo htmlspecialchars($course['banner_image'] ?? 'assets/images/header-bg.jpg'); ?>');
    background-size: cover;
    background-position: center;
    color: white;
    padding: 100px 0;
    position: relative;
">
    <div class="container">
        <div style="max-width: 800px;">
            <span class="badge" style="background: var(--accent); color: white; padding: 6px 15px; border-radius: 20px; font-size: 0.9rem; margin-bottom: 20px; display: inline-block;">
                <?php echo htmlspecialchars($course['status'] == 'approved' ? 'Featured Course' : 'Pending'); ?>
            </span>
            <h1 style="font-size: 3rem; margin-bottom: 20px; font-weight: 800;"><?php echo htmlspecialchars($course['title']); ?></h1>
            
            <div style="display: flex; gap: 30px; align-items: center; flex-wrap: wrap; margin-bottom: 30px;">
                <div style="display: flex; align-items: center;">
                    <img src="<?php echo htmlspecialchars($course['tutor_image']); ?>" style="width: 45px; height: 45px; border-radius: 50%; border: 2px solid white; margin-right: 12px;">
                    <div>
                        <small style="opacity: 0.8;">Instructor</small>
                        <div style="font-weight: 700;"><?php echo htmlspecialchars($course['tutor_name']); ?></div>
                    </div>
                </div>
                <div>
                     <small style="opacity: 0.8;">Rating</small>
                     <div style="color: var(--accent); font-weight: 700;">
                         <i class="fas fa-star"></i> <?php echo $course['tutor_rating']; ?>/5.0
                     </div>
                </div>
                <div>
                     <small style="opacity: 0.8;">Schedule</small>
                     <div style="font-weight: 700;"><?php echo htmlspecialchars($course['schedule_days']); ?></div>
                     <div style="font-size: 0.8rem; opacity: 0.9;"><?php echo htmlspecialchars($course['schedule_time']); ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container section-padding">
    <div class="course-details-grid">
        
        <!-- Main Content -->
        <div class="course-content">
            
            <!-- Description -->
            <div style="margin-bottom: 50px;">
                <h3 class="section-title">Course Overview</h3>
                <p style="font-size: 1.1rem; line-height: 1.8; color: #555;">
                    <?php echo nl2br(htmlspecialchars($course['description'])); ?>
                </p>
            </div>

            <!-- Benefits -->
            <?php if (!empty($course['benefits'])): ?>
            <div style="margin-bottom: 50px; background: #f8f9fa; padding: 30px; border-radius: 12px; border: 1px solid #eee;">
                <h3 class="section-title" style="margin-bottom: 20px;">What You'll Learn</h3>
                <ul style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; list-style: none; padding: 0;">
                    <?php 
                    $benefits = explode("\n", $course['benefits']);
                    foreach($benefits as $benefit) {
                        if(trim($benefit)) echo '<li style="display: flex; align-items: start;"><i class="fas fa-check-circle" style="color: var(--accent); margin-top: 5px; margin-right: 10px;"></i> <span>'.htmlspecialchars($benefit).'</span></li>';
                    }
                    ?>
                </ul>
            </div>
            <?php endif; ?>

            <!-- Instructor Bio -->
             <div style="margin-bottom: 50px;">
                <h3 class="section-title">Your Instructor</h3>
                <div style="display: flex; gap: 20px; align-items: start; background: white; padding: 25px; border-radius: 12px; box-shadow: var(--shadow-sm);">
                    <img src="<?php echo htmlspecialchars($course['tutor_image']); ?>" style="width: 100px; height: 100px; border-radius: 50%; object-fit: cover;">
                    <div>
                        <h4 style="margin-bottom: 10px;"><?php echo htmlspecialchars($course['tutor_name']); ?></h4>
                        <p style="color: #666; line-height: 1.6;"><?php echo htmlspecialchars($course['bio']); ?></p>
                    </div>
                </div>
            </div>

            <!-- FAQs -->
            <?php if (!empty($course['faqs'])): ?>
            <div style="margin-bottom: 50px;">
                <h3 class="section-title">Frequently Asked Questions</h3>
                <div>
                     <?php 
                     // Simple text format parsing for now: Q: ... A: ...
                     echo nl2br(htmlspecialchars($course['faqs'])); 
                     ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Reviews Mockup (Static for now as requested design) -->
            <div style="margin-bottom: 30px;">
                <h3 class="section-title">Student Reviews</h3>
                <div style="background: white; padding: 20px; border-radius: 8px; border-bottom: 1px solid #eee; margin-bottom: 15px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                        <strong>Abdullah K.</strong>
                        <span style="color: #ffc107;"><i class="fas fa-star"></i> 5.0</span>
                    </div>
                    <p style="color: #666; font-style: italic;">"Excellent course! The teacher explains everything so clearly. Highly recommended."</p>
                </div>
                <div style="background: white; padding: 20px; border-radius: 8px; border-bottom: 1px solid #eee;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                        <strong>Sarah M.</strong>
                        <span style="color: #ffc107;"><i class="fas fa-star"></i> 5.0</span>
                    </div>
                    <p style="color: #666; font-style: italic;">"Learning Tajweed has never been easier. I love the structure of the classes."</p>
                </div>
            </div>

        </div>

        <!-- Sidebar -->
        <div class="course-sidebar">
            <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); border: 1px solid #eee; position: sticky; top: 100px;">
                <div style="text-align: center; margin-bottom: 25px;">
                    <span style="font-size: 3rem; font-weight: 800; color: var(--primary);">$<?php echo number_format($course['price'], 0); ?></span>
                    <p style="color: #888;">One-time fee</p>
                </div>
                
                <form method="POST">
                    <button type="submit" name="enroll" class="btn btn-primary" style="width: 100%; padding: 18px; font-size: 1.1rem; border-radius: 50px; box-shadow: 0 5px 15px rgba(15, 81, 50, 0.3);">
                        <?php echo isset($_SESSION['user_id']) ? 'Enroll Now' : 'Register & Enroll'; ?>
                    </button>
                    <?php if(isset($enroll_error)): ?>
                        <p style="color: red; text-align: center; margin-top: 10px;"><?php echo $enroll_error; ?></p>
                    <?php endif; ?>
                </form>

                <div style="margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px;">
                    <ul style="list-style: none; padding: 0;">
                        <li style="margin-bottom: 15px; color: #555;"><i class="fas fa-clock" style="width: 20px; color: var(--accent);"></i> Duration: Flexible</li>
                        <li style="margin-bottom: 15px; color: #555;"><i class="fas fa-video" style="width: 20px; color: var(--accent);"></i> Live Video Classes</li>
                        <li style="margin-bottom: 15px; color: #555;"><i class="fas fa-infinity" style="width: 20px; color: var(--accent);"></i> Full Lifetime Access</li>
                        <li style="margin-bottom: 15px; color: #555;"><i class="fas fa-certificate" style="width: 20px; color: var(--accent);"></i> Certificate of Completion</li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</div>

<style>
    .section-title { font-size: 1.6rem; margin-bottom: 20px; color: #333; font-weight: 700; position: relative; padding-bottom: 10px; }
    .section-title::after { content: ''; position: absolute; left: 0; bottom: 0; width: 50px; height: 3px; background: var(--accent); }
    
    .course-details-grid {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 50px;
    }
    
    @media (max-width: 992px) {
        .course-details-grid {
            grid-template-columns: 1fr;
            gap: 30px;
        }
    }
</style>

<?php include 'includes/footer.php'; ?>
