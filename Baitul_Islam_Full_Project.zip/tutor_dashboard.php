<?php
require 'includes/db.php';
session_start();

// Ensure user is logged in and is a tutor
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'tutor') {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$success = '';
$error = '';

// Handle Course Addition
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_course'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $days = implode(',', $_POST['days'] ?? []);
    $time_start = $_POST['time_start'];
    $time_end = $_POST['time_end'];
    $time_label = date('h:i A', strtotime($time_start)) . ' - ' . date('h:i A', strtotime($time_end));

    if (empty($title) || empty($price) || empty($days) || empty($time_start) || empty($time_end)) {
        $error = "Please fill in all required fields.";
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO courses (tutor_id, title, description, price, schedule_days, schedule_time, time_start, time_end, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
            $stmt->execute([$user_id, $title, $description, $price, $days, $time_label, $time_start, $time_end]);
            $success = "Course added successfully! It is pending admin approval.";
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}

// Handle Meeting Link Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_meeting_link'])) {
    $course_id = $_POST['course_id'];
    $meeting_url = trim($_POST['meeting_url']);
    
    try {
        $stmt = $pdo->prepare("UPDATE courses SET meeting_url = ? WHERE id = ? AND tutor_id = ?");
        $stmt->execute([$meeting_url, $course_id, $user_id]);
        $success = "Meeting link updated successfully!";
    } catch (PDOException $e) {
        $error = "Update failed: " . $e->getMessage();
    }
}

// Update Online Status Heartbeat
$stmt_online = $pdo->prepare("UPDATE tutors SET is_online = 1, last_seen = CURRENT_TIMESTAMP WHERE id = ?");
$stmt_online->execute([$user_id]);

// Fetch Tutor Stats
$stmt_stats = $pdo->prepare("
    SELECT 
        (SELECT COUNT(*) FROM courses WHERE tutor_id = ?) as total_courses,
        (SELECT COUNT(*) FROM enrollments WHERE assigned_tutor_id = ? AND payment_status = 'paid') as total_students,
        (SELECT SUM(c3.price) FROM enrollments e JOIN courses c3 ON e.course_id = c3.id WHERE e.assigned_tutor_id = ? AND e.payment_status = 'paid') as total_earnings
");
$stmt_stats->execute([$user_id, $user_id, $user_id]);
$stats = $stmt_stats->fetch();

// Fetch Tutor's Courses with Student Count (where they are either owner or assigned)
$stmt = $pdo->prepare("
    SELECT c.*, 
    (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id AND e.assigned_tutor_id = ? AND e.payment_status = 'paid' AND e.status = 'active') as student_count 
    FROM courses c 
    WHERE c.tutor_id = ? OR c.id IN (SELECT course_id FROM enrollments WHERE assigned_tutor_id = ?)
    GROUP BY c.id
    ORDER BY c.created_at DESC
");
$stmt->execute([$user_id, $user_id, $user_id]);
$my_courses = $stmt->fetchAll();

// Fetch Tutor's Salary Slips
$stmt_slips = $pdo->prepare("SELECT * FROM salary_slips WHERE tutor_id = ? ORDER BY year DESC, month DESC");
$stmt_slips->execute([$user_id]);
$my_slips = $stmt_slips->fetchAll();

include 'includes/header.php';
?>

<div class="container section-padding">
    <style>
        .dashboard-grid {
            display: grid;
            grid-template-columns: 320px 1fr;
            gap: 40px;
        }
        .nav-link-tab {
            display: flex; align-items: center; gap: 15px; padding: 15px 20px; border-radius: 12px; font-weight: 700; color: #64748b; text-decoration: none; transition: 0.3s; margin-bottom: 8px; border: 1px solid transparent;
        }
        .nav-link-tab:hover { background: #f8fafc; color: var(--primary); }
        .nav-item-active { background: var(--primary) !important; color: white !important; box-shadow: 0 10px 20px rgba(15, 81, 50, 0.1); }
        .tab-content { display: none; }
        .tab-content.active { display: block; }

        .stat-card-premium {
            background: white; padding: 25px; border-radius: 20px; border: 1px solid #f1f5f9; box-shadow: 0 5px 15px rgba(0,0,0,0.02); display: flex; align-items: center; gap: 20px;
        }
        .stat-icon { width: 55px; height: 55px; border-radius: 15px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; }

        .course-card-tutor {
            background: white; border-radius: 25px; overflow: hidden; border: 1px solid #f1f5f9; transition: 0.4s cubic-bezier(0.165, 0.84, 0.44, 1); display: flex; flex-direction: column;
        }
        .course-card-tutor:hover { transform: translateY(-7px); box-shadow: 0 20px 40px rgba(0,0,0,0.06); border-color: var(--accent); }
        
        .status-badge { padding: 6px 14px; border-radius: 50px; font-size: 0.7rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; }
        
        @media (max-width: 992px) {
            .dashboard-grid { grid-template-columns: 1fr; }
        }
    </style>

    <div class="dashboard-grid">
        <!-- Sidebar -->
        <div class="dashboard-sidebar">
            <div style="background: white; padding: 40px 30px; border-radius: 30px; border: 1px solid #f1f5f9; box-shadow: 0 10px 40px rgba(0,0,0,0.03); position: sticky; top: 100px;">
                <div class="text-center" style="margin-bottom: 40px;">
                    <div class="avatar-circle" style="width: 100px; height: 100px; font-size: 2.5rem; margin: 0 auto 20px; background: linear-gradient(135deg, var(--accent), #b08130); color: white; border: 5px solid #f8fafc; box-shadow: 0 10px 20px rgba(0,0,0,0.05);">
                        <?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?>
                    </div>
                    <p style="font-size: 0.8rem; color: #94a3b8; font-weight: 800; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 5px;">Welcome</p>
                    <h3 style="font-size: 1.5rem; font-weight: 900; color: var(--primary-dark); margin-bottom: 8px;">Teacher <?php echo htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]); ?></h3>
                    <p style="color: #64748b; font-weight: 600; font-size: 0.85rem;">Instructor ID: #TTR-<?php echo str_pad($user_id, 4, '0', STR_PAD_LEFT); ?></p>
                </div>

                <nav>
                    <a href="javascript:void(0)" onclick="switchTab('overview', this)" class="nav-link-tab nav-item-active">
                        <i class="fas fa-th-large"></i> Dashboard Home
                    </a>
                    
                    <?php
                    // Check if tutor has at least one approved course
                    $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM courses WHERE tutor_id = ? AND status = 'approved'");
                    $stmt_check->execute([$user_id]);
                    $has_approved_course = $stmt_check->fetchColumn() > 0;
                    
                    if ($has_approved_course): 
                    ?>
                    <a href="classroom.php" class="nav-link-tab" style="color: var(--primary);">
                        <i class="fas fa-video"></i> Start Live Class
                    </a>
                    <?php endif; ?>
                    <a href="javascript:void(0)" onclick="switchTab('my-courses', this)" class="nav-link-tab">
                        <i class="fas fa-book-open"></i> Manage Courses
                    </a>
                    <a href="javascript:void(0)" onclick="switchTab('add-course', this)" class="nav-link-tab">
                        <i class="fas fa-plus-circle"></i> Create New Course
                    </a>
                    <a href="javascript:void(0)" onclick="switchTab('financials', this)" class="nav-link-tab" style="color: #059669;">
                        <i class="fas fa-file-invoice-dollar"></i> My Salary Slips
                    </a>
                    <div style="margin-top: 30px; border-top: 1px solid #f1f5f9; padding-top: 25px;">
                        <a href="logout.php" style="color: #ef4444; font-weight: 700; text-decoration: none; padding: 12px 20px; display: flex; align-items: center; gap: 12px; border-radius: 12px; transition: 0.3s;" onmouseover="this.style.background='#fef2f2'" onmouseout="this.style.background='transparent'">
                            <i class="fas fa-sign-out-alt"></i> Sign Out
                        </a>
                    </div>
                </nav>
            </div>
        </div>

        <!-- Main Content -->
        <div class="dashboard-content">

            <!-- Success/Error Messages -->
            <?php if($success): ?>
                <div class="alert success" style="background: #dcfce7; color: #166534; padding: 18px; border-radius: 12px; margin-bottom: 25px; border: 1px solid #bbf7d0; display: flex; align-items: center; gap: 12px; font-weight: 600;">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            <?php if($error): ?>
                <div class="alert error" style="background: #fee2e2; color: #991b1b; padding: 18px; border-radius: 12px; margin-bottom: 25px; border: 1px solid #fecaca; display: flex; align-items: center; gap: 12px; font-weight: 600;">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <!-- Tab: Overview -->
            <div id="overview" class="tab-content active" data-aos="fade-up">
                <h2 style="font-size: 2.2rem; font-weight: 900; color: var(--primary-dark); margin-bottom: 10px;">Teacher Portal</h2>
                <p style="color: #64748b; font-weight: 600; margin-bottom: 40px;">Professional Dashboard & Class Management</p>

                <!-- Stats Bar -->
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 40px;" class="stats-bar-responsive">
                    <div class="stat-card-premium">
                        <div class="stat-icon" style="background: #f0fdf4; color: #166534;"><i class="fas fa-user-graduate"></i></div>
                        <div>
                            <h4 style="font-size: 1.5rem; font-weight: 800; color: var(--primary-dark); margin: 0;"><?php echo $stats['total_students']; ?></h4>
                            <p style="color: #64748b; font-size: 0.85rem; font-weight: 700; margin: 0;">Total Students</p>
                        </div>
                    </div>
                    <div class="stat-card-premium">
                        <div class="stat-icon" style="background: #eff6ff; color: #1e40af;"><i class="fas fa-book-bookmark"></i></div>
                        <div>
                            <h4 style="font-size: 1.5rem; font-weight: 800; color: var(--primary-dark); margin: 0;"><?php echo $stats['total_courses']; ?></h4>
                            <p style="color: #64748b; font-size: 0.85rem; font-weight: 700; margin: 0;">Active Courses</p>
                        </div>
                    </div>
                    <div class="stat-card-premium">
                        <div class="stat-icon" style="background: #fffbeb; color: #92400e;"><i class="fas fa-wallet"></i></div>
                        <div>
                            <h4 style="font-size: 1.5rem; font-weight: 800; color: var(--primary-dark); margin: 0;">$<?php echo number_format($stats['total_earnings'] ?? 0, 0); ?></h4>
                            <p style="color: #64748b; font-size: 0.85rem; font-weight: 700; margin: 0;">Total Earnings</p>
                        </div>
                    </div>
                </div>

                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 25px;">
                    <h3 style="font-size: 1.4rem; font-weight: 800; color: var(--primary-dark);">Live Class Schedule</h3>
                    <a href="classroom.php" class="btn btn-primary" style="padding: 10px 20px; border-radius: 10px; font-size: 0.9rem;"><i class="fas fa-video me-2"></i> Join Global Room</a>
                </div>

                <div style="display: grid; gap: 20px;">
                    <?php if(empty($my_courses)): ?>
                         <div style="text-align: center; padding: 60px; background: white; border-radius: 20px; border: 2px dashed #e2e8f0;">
                            <p style="color: #94a3b8; font-weight: 600;">No live classes scheduled. Create a course to get started.</p>
                         </div>
                    <?php else: 
                        foreach($my_courses as $course): 
                    ?>
                        <div class="course-card-tutor" style="padding: 30px; flex-direction: row; justify-content: space-between; align-items: center;">
                            <div>
                                <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 12px;">
                                    <span class="status-badge" style="background: #dcfce7; color: #166534;">Active</span>
                                    <span style="font-weight: 800; font-size: 0.8rem; color: #94a3b8;"><i class="fas fa-clock me-1"></i> <?php echo $course['schedule_time']; ?></span>
                                </div>
                                <h3 style="font-size: 1.5rem; font-weight: 900; color: var(--primary-dark); margin-bottom: 8px;"><?php echo htmlspecialchars($course['title']); ?></h3>
                                <p style="color: #64748b; font-weight: 700; font-size: 0.9rem; margin: 0;">
                                    <i class="fas fa-user-group me-2" style="color: var(--accent);"></i> Enrolled: <span style="color: var(--primary); font-weight: 800;"><?php echo $course['student_count']; ?> Students</span>
                                </p>
                            </div>
                            <div style="text-align: right; min-width: 300px;">
                                <?php if($course['status'] == 'approved'): ?>
                                    <form method="POST" style="margin-bottom: 10px; display: flex; gap: 8px;">
                                        <input type="hidden" name="course_id" value="<?php echo $course['id']; ?>">
                                        <input type="url" name="meeting_url" value="<?php echo htmlspecialchars($course['meeting_url'] ?? ''); ?>" placeholder="Enter Zoom/Meet Link" style="flex: 1; padding: 8px 12px; border-radius: 8px; border: 1px solid #ddd; font-size: 0.85rem;">
                                        <button type="submit" name="update_meeting_link" class="btn" style="background: var(--primary); color: white; padding: 8px 15px; border-radius: 8px; font-weight: 700; font-size: 0.8rem;">Save Link</button>
                                    </form>
                                    <div style="display: flex; gap: 8px; justify-content: flex-end;">
                                        <a href="classroom.php?room=PeaceRoom_<?php echo $course['id']; ?>_<?php echo md5($course['tutor_id']); ?>" class="btn-premium-gold" style="display: inline-block; text-decoration: none; padding: 10px 20px; border-radius: 12px; font-weight: 800; font-size: 0.85rem;">
                                            <i class="fas fa-chalkboard-user me-2"></i> Start Jitsi
                                        </a>
                                        <?php if($course['meeting_url']): ?>
                                            <a href="<?php echo htmlspecialchars($course['meeting_url']); ?>" target="_blank" class="btn" style="background: #2563eb; color: white; padding: 10px 20px; border-radius: 12px; font-weight: 800; font-size: 0.85rem;">
                                                <i class="fas fa-video me-2"></i> Open Zoom/Meet
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <span class="badge" style="background: #fef3c7; color: #92400e; padding: 10px 20px; border-radius: 10px; font-weight: 800;">
                                        <i class="fas fa-clock me-2"></i> Pending Approval
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; endif; ?>
                </div>
            </div>

            <!-- Tab: My Catalog -->
            <div id="my-courses" class="tab-content" data-aos="fade-up">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 35px;">
                    <h2 style="font-size: 2rem; font-weight: 900; color: var(--primary-dark);">Course Catalog</h2>
                    <button onclick="switchTab('add-course')" class="btn btn-primary" style="padding: 12px 25px; border-radius: 50px;">+ New Course</button>
                </div>

                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 30px;">
                    <?php foreach($my_courses as $course): ?>
                        <div class="course-card-tutor">
                            <div style="height: 180px; position: relative; overflow: hidden;">
                                <img src="<?php echo htmlspecialchars($course['banner_image']); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                                <div style="position: absolute; top: 15px; right: 15px;">
                                    <?php 
                                        $status_color = $course['status'] == 'approved' ? '#dcfce7' : ($course['status'] == 'rejected' ? '#fee2e2' : '#fef3c7');
                                        $status_text_color = $course['status'] == 'approved' ? '#166534' : ($course['status'] == 'rejected' ? '#991b1b' : '#92400e');
                                    ?>
                                    <span class="status-badge" style="background: <?php echo $status_color; ?>; color: <?php echo $status_text_color; ?>;">
                                        <?php echo ucfirst($course['status']); ?>
                                    </span>
                                </div>
                            </div>
                            <div style="padding: 25px;">
                                <h4 style="font-size: 1.25rem; font-weight: 800; color: var(--primary-dark); margin-bottom: 12px; height: 3em; overflow: hidden;"><?php echo htmlspecialchars($course['title']); ?></h4>
                                <div style="display: flex; align-items: center; justify-content: space-between; border-top: 1px solid #f1f5f9; padding-top: 20px; margin-top: 20px;">
                                    <div style="font-weight: 800; color: var(--primary);">$<?php echo number_format($course['price'], 0); ?></div>
                                    <div style="font-weight: 700; font-size: 0.85rem; color: #94a3b8;"><i class="fas fa-calendar me-1"></i> <?php echo $course['schedule_days']; ?></div>
                                </div>
                            </div>
                            <div style="padding: 0 25px 25px;">
                                <a href="course_details.php?id=<?php echo $course['id']; ?>" class="btn" style="width: 100%; background: #f8fafc; color: var(--primary-dark); font-weight: 700; border: 1px solid #e2e8f0; border-radius: 12px;">Edit Details</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Tab: Add Course -->
            <div id="add-course" class="tab-content" data-aos="fade-up">
                <div style="max-width: 800px;">
                    <h2 style="font-size: 2rem; font-weight: 900; color: var(--primary-dark); margin-bottom: 30px;">Launch New Course</h2>
                    
                    <form method="POST" style="background: white; padding: 40px; border-radius: 30px; border: 1px solid #f1f5f9; box-shadow: 0 10px 40px rgba(0,0,0,0.03);">
                        <input type="hidden" name="add_course" value="1">
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px; margin-bottom: 25px;">
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 10px; font-weight: 700; color: var(--primary-dark);">Course Title</label>
                                <input type="text" name="title" class="form-control" placeholder="e.g. Arabic Grammar Masterclass" required style="width: 100%; padding: 14px; border: 2px solid #f1f5f9; border-radius: 12px; background: #f8fafc;">
                            </div>
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 10px; font-weight: 700; color: var(--primary-dark);">Course Fee ($)</label>
                                <input type="number" name="price" placeholder="49.00" required style="width: 100%; padding: 14px; border: 2px solid #f1f5f9; border-radius: 12px; background: #f8fafc;">
                            </div>
                        </div>

                        <div class="form-group" style="margin-bottom: 25px;">
                            <label style="display: block; margin-bottom: 10px; font-weight: 700; color: var(--primary-dark);">Description</label>
                            <textarea name="description" rows="4" placeholder="Brief overview of what students will learn..." style="width: 100%; padding: 14px; border: 2px solid #f1f5f9; border-radius: 12px; background: #f8fafc; resize: none;"></textarea>
                        </div>

                        <div class="form-group" style="margin-bottom: 25px;">
                            <label style="display: block; margin-bottom: 15px; font-weight: 700; color: var(--primary-dark);">Class Schedule (Days)</label>
                            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                                <?php foreach(['Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $day): ?>
                                    <label style="cursor: pointer;">
                                        <input type="checkbox" name="days[]" value="<?php echo $day; ?>" style="display: none;" class="day-check">
                                        <div class="day-btn" style="padding: 10px 18px; border: 2px solid #f1f5f9; border-radius: 12px; font-weight: 700; color: #94a3b8; transition: 0.2s;"><?php echo $day; ?></div>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px; margin-bottom: 35px;">
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 10px; font-weight: 700; color: var(--primary-dark);">Start Time</label>
                                <input type="time" name="time_start" required style="width: 100%; padding: 14px; border: 2px solid #f1f5f9; border-radius: 12px; background: #f8fafc;">
                            </div>
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 10px; font-weight: 700; color: var(--primary-dark);">End Time</label>
                                <input type="time" name="time_end" required style="width: 100%; padding: 14px; border: 2px solid #f1f5f9; border-radius: 12px; background: #f8fafc;">
                            </div>
                        </div>

                        <button type="submit" class="btn-premium-gold" style="width: 100%; padding: 18px; border: none; font-size: 1.1rem; font-weight: 800; cursor: pointer;">Create & Publish Course</button>
                    </form>
                </div>
            <!-- Tab: Financials -->
            <div id="financials" class="tab-content" data-aos="fade-up">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 35px;">
                    <div>
                        <h2 style="font-size: 2.2rem; font-weight: 900; color: var(--primary-dark); margin-bottom: 5px;">My Financials</h2>
                        <p style="color: #64748b; font-weight: 600;">Track your teaching earnings and monthly payslips</p>
                    </div>
                    <div style="background: #ecfdf5; padding: 15px 25px; border-radius: 15px; border: 1px solid #bbf7d0;">
                        <small style="display: block; color: #059669; font-weight: 800; text-transform: uppercase; font-size: 0.7rem; margin-bottom: 5px;">Total Withdrawn</small>
                        <span style="font-size: 1.4rem; font-weight: 900; color: var(--primary-dark);">$<?php echo number_format($stats['total_earnings'] ?? 0, 0); ?></span>
                    </div>
                </div>

                <div class="card border-0 shadow-sm rounded-4 overflow-hidden" style="background: white; border: 1px solid #f1f5f9 !important;">
                    <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                        <h5 class="mb-0 fw-bold text-dark"><i class="fas fa-clipboard-list me-2 text-primary"></i> Monthly Salary Slips</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead style="background: #f8fafc;">
                                    <tr>
                                        <th class="ps-4 py-3" style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: #64748b; font-weight: 800;">Billing Period</th>
                                        <th class="py-3" style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: #64748b; font-weight: 800;">Hours Taught</th>
                                        <th class="py-3" style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: #64748b; font-weight: 800;">Hourly Rate</th>
                                        <th class="py-3" style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: #64748b; font-weight: 800;">Total Amount</th>
                                        <th class="py-3" style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: #64748b; font-weight: 800;">Status</th>
                                        <th class="text-end pe-4 py-3" style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: #64748b; font-weight: 800;">Statement</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(empty($my_slips)): ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-5 text-muted">
                                                <i class="fas fa-file-invoice-dollar fa-3x mb-3 opacity-25"></i>
                                                <p class="mb-0">No salary slips found yet.</p>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                    <?php foreach($my_slips as $slip): ?>
                                    <tr>
                                        <td class="ps-4" data-label="Billing Period">
                                            <div class="d-flex align-items-center">
                                                <div class="bg-primary-subtle text-primary rounded-pill p-2 me-3 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px; background: #ecfdf5;">
                                                    <i class="fas fa-calendar-check" style="color: #059669;"></i>
                                                </div>
                                                <div>
                                                    <h6 class="mb-0 fw-bold"><?php echo date('F', mktime(0,0,0, $slip['month'], 1)); ?> <?php echo $slip['year']; ?></h6>
                                                    <small class="text-muted">Issued on <?php echo date('M d, Y', strtotime($slip['created_at'])); ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td data-label="Hours Taught"><span class="fw-bold text-dark"><?php echo $slip['total_hours']; ?> hrs</span></td>
                                        <td data-label="Hourly Rate"><span class="text-muted fw-medium">$<?php echo number_format($slip['hourly_rate'], 2); ?>/hr</span></td>
                                        <td data-label="Total Amount"><span class="text-primary fw-black" style="font-size: 1.1rem; color: #0F5132 !important;">$<?php echo number_format($slip['total_salary'], 2); ?></span></td>
                                        <td data-label="Status">
                                            <span class="badge rounded-pill px-3 py-2 <?php echo $slip['status'] == 'paid' ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning'; ?>" style="<?php echo $slip['status'] == 'paid' ? 'background: #dcfce7 !important; color: #15803d !important;' : 'background: #fef3c7 !important; color: #92400e !important;'; ?>">
                                                <i class="fas <?php echo $slip['status'] == 'paid' ? 'fa-check-circle' : 'fa-clock'; ?> me-1"></i>
                                                <?php echo ucfirst($slip['status']); ?>
                                            </span>
                                        </td>
                                        <td class="text-end pe-4" data-label="Action">
                                            <a href="salary_slip_view.php?id=<?php echo $slip['id']; ?>" class="btn btn-sm btn-outline-primary rounded-pill px-4" style="border: 2px solid #0F5132; color: #0F5132; font-weight: 800; transition: 0.3s;" onmouseover="this.style.background='#0F5132'; this.style.color='white'" onmouseout="this.style.background='transparent'; this.style.color='#0F5132'">
                                                <i class="fas fa-file-pdf me-2"></i> View Slip
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<style>
    .day-check:checked + .day-btn { background: var(--primary); color: white; border-color: var(--primary); box-shadow: 0 5px 12px rgba(15, 81, 50, 0.2); }
</style>

<script>
    function switchTab(tabId, el) {
        document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
        document.querySelectorAll('.nav-link-tab').forEach(link => link.classList.remove('nav-item-active'));
        
        document.getElementById(tabId).classList.add('active');
        if(el) el.classList.add('nav-item-active');
        else {
            const allLinks = document.querySelectorAll('.nav-link-tab');
            allLinks.forEach(link => {
                if(link.getAttribute('onclick').includes(tabId)) link.classList.add('nav-item-active');
            });
        }
    }

    // Live Heartbeat for Teacher
    setInterval(updateHeartbeat, 30000); // Every 30 seconds
    function updateHeartbeat() {
        fetch('api/tutor_heartbeat.php').catch(err => console.log('Heartbeat failed'));
    }
</script>

<?php include 'includes/footer.php'; ?>
