<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/email_config.php';

function sendEmail($to, $subject, $body, $isHTML = true) {
    $mail = new PHPMailer(true);
    
    try {
        // Server settings
        $mail->SMTPDebug = 0; // Disable debug output
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        
        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($to);
        
        // Content
        $mail->isHTML($isHTML);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->CharSet = 'UTF-8';
        
        $mail->send();
        return ['success' => true, 'message' => 'Email sent successfully'];
    } catch (Exception $e) {
        $errorMsg = "Email sending failed: " . $mail->ErrorInfo;
        error_log($errorMsg);
        return ['success' => false, 'message' => $errorMsg];
    }
}

function sendOTPEmail($to, $name, $otp) {
    $subject = "Password Reset OTP - Baitul Islam";
    
    $body = "
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: 'Segoe UI', Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { 
                background: linear-gradient(135deg, #0F5132, #167448); 
                color: white; 
                padding: 30px; 
                text-align: center; 
                border-radius: 10px 10px 0 0; 
            }
            .content { 
                background: #f9f9f9; 
                padding: 30px; 
                border-radius: 0 0 10px 10px; 
            }
            .otp-box { 
                background: white; 
                border: 3px dashed #D4AF37; 
                padding: 20px; 
                text-align: center; 
                margin: 20px 0; 
                border-radius: 10px; 
            }
            .otp-code { 
                font-size: 32px; 
                font-weight: bold; 
                color: #0F5132; 
                letter-spacing: 8px; 
                font-family: 'Courier New', monospace; 
            }
            .footer { 
                text-align: center; 
                margin-top: 30px; 
                padding: 20px; 
                background: #f0f0f0; 
                border-radius: 10px; 
                font-size: 0.9rem; 
                color: #666; 
            }
            .footer a { color: #0F5132; text-decoration: none; }
            .warning { 
                background: #fff3cd; 
                border-left: 4px solid #ffc107; 
                padding: 15px; 
                margin: 20px 0; 
                border-radius: 5px; 
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🔐 Password Reset OTP</h1>
                <p>Baitul Islam Global</p>
            </div>
            <div class='content'>
                <p>Assalam-o-Alaikum <strong>" . htmlspecialchars($name) . "</strong>,</p>
                <p>We received a request to reset your password for your Baitul Islam account.</p>
                
                <div class='otp-box'>
                    <p style='margin: 0; color: #666; font-size: 14px;'>Your OTP Code:</p>
                    <div class='otp-code'>" . $otp . "</div>
                    <p style='margin: 10px 0 0 0; color: #666; font-size: 12px;'>Valid for 10 minutes</p>
                </div>
                
                <div class='warning'>
                    <strong>⚠️ Security Notice:</strong>
                    <ul style='margin: 10px 0 0 0; padding-left: 20px;'>
                        <li>This OTP will expire in <strong>10 minutes</strong></li>
                        <li>Do NOT share this code with anyone</li>
                        <li>If you didn't request this, please ignore this email</li>
                    </ul>
                </div>
                
                <p style='margin-top: 20px;'>Enter this OTP on the password reset page to continue.</p>
                <p>JazakAllah Khair,<br><strong>Baitul Islam Team</strong></p>
            </div>
            
            <div class='footer'>
                <p><strong>" . ORG_NAME . "</strong></p>
                <p>📧 Email: <a href='mailto:" . ORG_EMAIL . "'>" . ORG_EMAIL . "</a></p>
                <p>📱 Phone: " . ORG_PHONE . "</p>
                <p>📍 Address: " . ORG_ADDRESS . "</p>
                <p>🌐 Website: <a href='http://" . ORG_WEBSITE . "'>" . ORG_WEBSITE . "</a></p>
                <hr style='border: none; border-top: 1px solid #ddd; margin: 15px 0;'>
                <p style='font-size: 0.85rem; color: #999;'>
                    This is an automated email. Please do not reply to this message.
                </p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    return sendEmail($to, $subject, $body, true);
}
?>
