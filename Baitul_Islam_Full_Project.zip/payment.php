<?php
require 'includes/db.php';
require 'includes/stripe_config.php';
session_start();

if (!isset($_SESSION['user_id']) || !isset($_GET['course_id'])) {
    header("Location: courses.php");
    exit;
}

$course_id = $_GET['course_id'];
$user_id = $_SESSION['user_id'];

// Fetch Course Info
$stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ?");
$stmt->execute([$course_id]);
$course = $stmt->fetch();

if (!$course) die("Course not found.");

include 'includes/header.php';
?>

<div class="container" style="padding: 120px 0;">
    <div style="max-width: 550px; margin: 0 auto; background: white; padding: 50px; border-radius: 24px; box-shadow: 0 30px 60px rgba(0,0,0,0.08); border: 1px solid #f1f5f9;">
        <h2 class="text-center" style="margin-bottom: 40px; color: var(--primary); font-weight: 900; letter-spacing: -1px;">Secure Checkout</h2>
        
        <div style="background: #f8fafc; padding: 25px; border-radius: 16px; margin-bottom: 40px; border-left: 5px solid var(--accent);">
            <p style="margin: 0; font-size: 0.85rem; color: #64748b; text-transform: uppercase; letter-spacing: 1px; font-weight: 700;">Selected Course</p>
            <h4 style="margin: 10px 0 0; color: #1a202c; font-weight: 800;"><?php echo htmlspecialchars($course['title']); ?></h4>
            <div style="text-align: right; font-weight: 900; font-size: 1.5rem; margin-top: 15px; color: var(--primary);">
                $<?php echo number_format($course['price'], 2); ?>
            </div>
        </div>

        <div id="stripe-payment-form">
            <p style="text-align: center; color: #64748b; margin-bottom: 30px;">You will be redirected to Stripe's secure payment portal to complete your enrollment.</p>
            <button id="checkout-button" class="btn btn-primary" style="width: 100%; padding: 18px; font-size: 1.1rem; border-radius: 12px; font-weight: 800; box-shadow: 0 15px 30px rgba(13, 81, 50, 0.2);">
                Complete Secure Payment <i class="fas fa-arrow-right ms-2"></i>
            </button>
        </div>
        
        <div style="text-align: center; margin-top: 30px; display: flex; align-items: center; justify-content: center; gap: 20px;">
            <img src="https://upload.wikimedia.org/wikipedia/commons/b/ba/Stripe_Logo%2C_revised_2016.svg" style="height: 25px; opacity: 0.5;">
            <div style="height: 20px; width: 1px; background: #ddd;"></div>
            <div style="color: #94a3b8; font-size: 0.8rem; font-weight: 600;">
                <i class="fas fa-lock me-1"></i> AES-256 Encryption
            </div>
        </div>
    </div>
</div>

<script src="https://js.stripe.com/v3/"></script>
<script>
const stripe = Stripe('<?php echo STRIPE_PUBLISHABLE_KEY; ?>');
const checkoutButton = document.getElementById('checkout-button');

checkoutButton.addEventListener('click', function() {
    this.innerText = 'Initializing...';
    this.disabled = true;

    fetch('create-checkout-session.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            planName: '<?php echo addslashes($course['title']); ?>',
            price: <?php echo (float)$course['price']; ?>,
            period: 'Course Enrollment',
            course_id: <?php echo $course_id; ?>
        }),
    })
    .then(response => response.json())
    .then(session => {
        if (session.id) {
            return stripe.redirectToCheckout({ sessionId: session.id });
        } else {
            alert('Error: ' + (session.error || 'Failed to create session'));
            this.innerText = 'Complete Secure Payment';
            this.disabled = false;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        this.innerText = 'Complete Secure Payment';
        this.disabled = false;
    });
});
</script>

<?php include 'includes/footer.php'; ?>
